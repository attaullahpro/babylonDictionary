package com.babylon.common;

import android.webkit.JavascriptInterface;
import com.babylon.translate.BabActivity;

public class JavaScriptHandler {
    BabActivity mMainActivity;

    public JavaScriptHandler(BabActivity activity) {
        this.mMainActivity = activity;
    }

    @JavascriptInterface
    public void purchaseFTT() {
        this.mMainActivity.purchaseFTTRequestFromUpgradeBanner();
    }

    public void calcSomething(int x, int y) {
    }
}
