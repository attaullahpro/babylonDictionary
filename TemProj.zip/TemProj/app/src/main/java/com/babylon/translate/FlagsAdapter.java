package com.babylon.translate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.babylon.common.FlagData;
import com.babylon.common.FlagList;
import com.babylon.translator.R;

public class FlagsAdapter extends ArrayAdapter<FlagData> {
    /* access modifiers changed from: private */
    public CheckBox mCheckboxFlag;
    public FlagList mFlagsList;
    private ImageView mImgViewFlag;
    private LayoutInflater mInflater = ((LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE));
    private TextView mTextviewFlag;

    public FlagsAdapter(Context context, int textViewResourceId, FlagList objects) {
        super(context, textViewResourceId, objects);
        this.mFlagsList = objects;
    }

    public int getCount() {
        return this.mFlagsList.size();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        View row = this.mInflater.inflate(R.layout.flag_row, parent, false);
        row.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FlagsAdapter.this.mCheckboxFlag = (CheckBox) v.findViewById(R.id.checkBoxFlag);
                FlagsAdapter.this.mCheckboxFlag.setChecked(!FlagsAdapter.this.mCheckboxFlag.isChecked());
            }
        });
        FlagData flag = getItem(position);
        this.mCheckboxFlag = (CheckBox) row.findViewById(R.id.checkBoxFlag);
        if (flag.mChecked > 0) {
            this.mCheckboxFlag.setChecked(true);
        }
        this.mCheckboxFlag.setTag(Integer.valueOf(position));
        this.mCheckboxFlag.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                FlagsAdapter.this.selectFlag(buttonView, isChecked);
            }
        });
        this.mTextviewFlag = (TextView) row.findViewById(R.id.textFlag);
        this.mTextviewFlag.setText(flag.mLanguage);
        this.mImgViewFlag = (ImageView) row.findViewById(R.id.imageFlag);
        this.mImgViewFlag.setImageResource(flag.mImgFlagId);
        return row;
    }

    /* access modifiers changed from: private */
    public void selectFlag(CompoundButton buttonView, boolean isChecked) {
        BabActivity main = (BabActivity) buttonView.getContext();
        if (main != null) {
            main.OnAddLang(((Integer) buttonView.getTag()).intValue(), isChecked, true);
        }
    }

    public FlagData getItem(int index) {
        return (FlagData) this.mFlagsList.get(index);
    }

    public long getItemId(int position) {
        return (long) position;
    }
}
