package com.babylon.common;

import android.os.Environment;
import java.io.File;

public class Constants {
    public static final String ACTION_ORIENTATION_CHANGE = "babylon.orientation_change";
    public static final String ACTION_TTS_STOP_EVENT = "babylon.tts_stop";
    public static final String APP_DIRECTORY = "TransBabylon";
    public static final String EXTERNAL_APP_DIRECTORY_FULL_PATH = String.format("%s%s%s", new Object[]{Environment.getExternalStorageDirectory(), Character.valueOf(File.separatorChar), APP_DIRECTORY});
    public static final int FTT_CAP = 10;
    public static final String FTT_PURCHASE_FROM_APP_SOURCE = "_FttApp";
    public static final String FTT_PURCHASE_FROM_NOTIFICATION_SOURCE = "_FttNotification";
    public static final String FTT_PURCHASE_FROM_SETTINGS_SOURCE = "_FttSettings";
    public static final String FTT_PURCHASE_FROM_UPGRADE_BANNER_SOURCE = "_Admob";
    public static final String IN_APP_PRODUCT_FTT = "ftt_unlock";
    public static final String IN_APP_PRODUCT_FTT_OFFLINE = "ftt_offline_unlock";
    public static final String IN_APP_PRODUCT_FUTURE = "future_unlock";
    public static final String IN_APP_PRODUCT_OFFLINE = "offline_unlock";
    public static final String PERSISTENT_PREFERENCES_FILE_NAME = "prefs.json";
    public static final int PURCHASE_REQUEST = 10001;
    public static final int UPGRADE_REQUEST = 10002;
}
