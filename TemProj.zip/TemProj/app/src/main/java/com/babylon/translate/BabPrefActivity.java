package com.babylon.translate;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity; 
import android.text.Html;
import android.view.KeyEvent;
import android.view.View;

import androidx.appcompat.widget.Toolbar;

import com.babylon.common.BabPrefs;
import com.babylon.controls.CustomEditText;
import com.babylon.offline.DownloadActivity;
import com.babylon.translator.R;

public class BabPrefActivity extends PreferenceActivity {
    public static int SHOW_UPGRADE = 1;
    private Toolbar _toolbar;
    OnClickListener mDialogClickListener;
    public BabPrefs mPrefs;
    public boolean mSTTLangChanged = false;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.toolbar_pref_activity);
        this._toolbar = (Toolbar) findViewById(R.id.abp__toolbar);
        addPreferencesFromResource(R.xml.preferences);
        this.mPrefs = new BabPrefs(getApplicationContext());
        this.mDialogClickListener = new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        BabPrefActivity.this.mPrefs.putClearHistory(true);
                        return;
                    default:
                        return;
                }
            }
        };
        findPreference(BabPrefs.CLEAR_HISTORY).setOnPreferenceClickListener(new OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                new Builder(preference.getContext()).setMessage("You are about to clear your translated history. Are you sure?").setPositiveButton("Yes", BabPrefActivity.this.mDialogClickListener).setNegativeButton("No", BabPrefActivity.this.mDialogClickListener).show();
                return true;
            }
        });
        ((CheckBoxPreference) findPreference(BabPrefs.ENABLE_COPY_NOTIFY)).setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference arg0, Object arg1) {
                BabPrefActivity.this.mPrefs.putEnableCopy(((Boolean) arg1).booleanValue());
                Intent serviceBabylon = new Intent(BabPrefActivity.this.getApplicationContext(), BabylonService.class);
                BabPrefActivity.this.stopService(serviceBabylon);
                BabPrefActivity.this.startService(serviceBabylon);
                return true;
            }
        });
        ((CheckBoxPreference) findPreference(BabPrefs.ENABLE_SLIDER)).setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference arg0, Object arg1) {
                BabPrefActivity.this.mPrefs.putEnableSlider(((Boolean) arg1).booleanValue());
                return true;
            }
        });
        ((CheckBoxPreference) findPreference(BabPrefs.ENABLE_TERM_AC)).setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference arg0, Object arg1) {
                Boolean bEnable = (Boolean) arg1;
                BabPrefActivity.this.mPrefs.putEnableTermAC(bEnable.booleanValue());
                CustomEditText.SetAutoComplete(bEnable.booleanValue());
                return true;
            }
        });
        ListPreference lpLang = (ListPreference) findPreference(BabPrefs.VOICE_SEARCH);
        String sLang = this.mPrefs.getSTTLang();
        lpLang.setDefaultValue(sLang);
        lpLang.setSummary(lpLang.getEntries()[lpLang.findIndexOfValue(sLang)]);
        lpLang.setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                ListPreference lpPref = (ListPreference) preference;
                lpPref.setSummary(lpPref.getEntries()[lpPref.findIndexOfValue((String) newValue)]);
                BabPrefActivity.this.mPrefs.putSTTLang((String) newValue);
                BabPrefActivity.this.mSTTLangChanged = true;
                return true;
            }
        });
        findPreference(BabPrefs.DOWNLOAD_OFFLINE).setOnPreferenceClickListener(new OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                if (/*IabHelper.getIsProVersionOffline()*/true) {
                    BabPrefActivity.this.startActivity(new Intent(BabPrefActivity.this.getApplicationContext(), DownloadActivity.class));
                } else {
//                    GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_FTT_CAP_UPGRADE_FROM_SETTINGS);
                    BabPrefActivity.this.setResult(BabPrefActivity.SHOW_UPGRADE, new Intent());
                    BabPrefActivity.this.finish();
                }
                return true;
            }
        });
        Preference upgradeFullVersion = findPreference(BabPrefs.UPGRADE_FULL_VERSION);
        if (/*IabHelper.getIsProVersionFuture()*/true) {
            upgradeFullVersion.setEnabled(false);
            upgradeFullVersion.setTitle(Html.fromHtml(String.format("<font color=\"#9EC72D\">%s</font>", new Object[]{(String) getText(R.string.settings_already_pro_title)})));
            upgradeFullVersion.setSummary(R.string.settings_already_pro_summary);
        } else {
            upgradeFullVersion.setOnPreferenceClickListener(new OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                     BabPrefActivity.this.setResult(BabPrefActivity.SHOW_UPGRADE, new Intent());
                    BabPrefActivity.this.finish();
                    return true;
                }
            });
        }
        getListView().setBackgroundColor(-1);
        this._toolbar.setTitle((CharSequence) getString(R.string.bab_menu_settings));
        this._toolbar.setNavigationIcon((int) R.drawable.back);
        this._toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BabPrefActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 4:
                Intent resultIntent = new Intent();
                setReturnResults(resultIntent);
                setResult(-1, resultIntent);
                finish();
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    private void setReturnResults(Intent resultIntent) {
        if (this.mSTTLangChanged) {
            resultIntent.putExtra(BabActivity.STT_LANG_CHANGED_FLAG, true);
        } else {
            resultIntent.putExtra(BabActivity.STT_LANG_CHANGED_FLAG, false);
        }
    }

    public void onStart() {
        super.onStart();
//        GoogleAnalyticsAdapter.startActivity(this);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 10001:
//                if (BabApplication.getBillingHelper() != null) {
//                    BabApplication.getBillingHelper().handleActivityResult(requestCode, resultCode, data);
//                    return;
//                }
                return;
            default:
                return;
        }
    }
}
