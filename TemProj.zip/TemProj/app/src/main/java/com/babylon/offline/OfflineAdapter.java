package com.babylon.offline;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.babylon.common.OfflineData;
import com.babylon.translator.R;

import java.util.ArrayList;

public class OfflineAdapter extends ArrayAdapter<OfflineData> {
    private static String DIM_TEXT_COLOR = "#6B6B6B";
    /* access modifiers changed from: private */
    public int[] mChecked;
    Context mContext;
    private LayoutInflater mInflater;
    ArrayList<OfflineData> mList;

    public OfflineAdapter(Context context, int textViewResourceId, ArrayList<OfflineData> objects, int iChecked) {
        super(context, textViewResourceId, objects);
        this.mContext = context;
        this.mList = objects;
        this.mChecked = new int[objects.size()];
        int i = 0;
        while (i < this.mChecked.length) {
            this.mChecked[i] = i < iChecked ? 1 : -1;
            i++;
        }
        this.mInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.mList.size();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        View row = this.mInflater.inflate(R.layout.offline_row, parent, false);
        CheckBox cbInstalled = (CheckBox) row.findViewById(R.id.checkBoxOffline);
        TextView tvSrc = (TextView) row.findViewById(R.id.textSourceLang);
        TextView tvTarget = (TextView) row.findViewById(R.id.textTargetLang);
        TextView tvSize = (TextView) row.findViewById(R.id.textOfflineSize);
        ImageView recycle = (ImageView) row.findViewById(R.id.imageRecycleBin);
        cbInstalled.setTag(Integer.valueOf(position));
        OfflineData data = getItem(position);
        if (data.mInstalled) {
            tvSrc.setTextColor(Color.parseColor(DIM_TEXT_COLOR));
            tvTarget.setTextColor(Color.parseColor(DIM_TEXT_COLOR));
            ((ImageView) row.findViewById(R.id.imageArrow)).setImageResource(R.drawable.arrow_icn_dim);
            cbInstalled.setChecked(true);
            cbInstalled.setEnabled(false);
            cbInstalled.setCompoundDrawablesWithIntrinsicBounds(R.drawable.cb_dict_disabled, 0, 0, 0);
            recycle.setTag(Integer.valueOf(position));
            recycle.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    ((DownloadActivity) OfflineAdapter.this.mContext).OnDeleteDictionary(((Integer) v.getTag()).intValue());
                }
            });
        } else {
            if (position < this.mChecked.length && this.mChecked[position] != -1) {
                cbInstalled.setChecked(this.mChecked[position] == 1);
            }
            ((ImageView) row.findViewById(R.id.imageRecycleBin)).setVisibility(View.INVISIBLE);
            row.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    CheckBox cbInstalled = (CheckBox) v.findViewById(R.id.checkBoxOffline);
                    cbInstalled.setChecked(!cbInstalled.isChecked());
                }
            });
            cbInstalled.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    Integer intTag = (Integer) buttonView.getTag();
                    OfflineAdapter.this.mChecked[intTag.intValue()] = isChecked ? 1 : 0;
                    if (isChecked) {
                        ((DownloadActivity) OfflineAdapter.this.mContext).OnAddInstall(intTag);
                    } else {
                        ((DownloadActivity) OfflineAdapter.this.mContext).OnRemoveInstall(intTag);
                    }
                }
            });
        }
        tvSrc.setText(data.mSource);
        tvTarget.setText(data.mTarget);
        tvSize.setText(data.mSize + " MB");
        return row;
    }

    public OfflineData getItem(int index) {
        return (OfflineData) this.mList.get(index);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public void updateDictsList(ArrayList<OfflineData> newlist, int iChecked) {
        this.mList = newlist;
        int i = 0;
        while (i < this.mChecked.length) {
            this.mChecked[i] = i < iChecked ? 1 : -1;
            i++;
        }
        notifyDataSetChanged();
    }
}
