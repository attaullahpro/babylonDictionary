package com.babylon.translate;

import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.TextView.BufferType;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

//import com.babylon.analytics.GoogleAnalyticsAdapter;
import com.babylon.translator.R;

public class AboutActivity extends AppCompatActivity {
    private Toolbar _toolbar;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.about);
        this._toolbar = (Toolbar) findViewById(R.id.abp__toolbar);
        TextView tvTouch = (TextView) findViewById(R.id.textBabylonTouch);
        SpannableString text = new SpannableString(getResources().getString(R.string.bab_touch_txt));
        text.setSpan(new URLSpan(getResources().getString(R.string.bab_touch_url)), 10, 23, 0);
        tvTouch.setMovementMethod(LinkMovementMethod.getInstance());
        tvTouch.setText(text, BufferType.SPANNABLE);
        tvTouch.setLinkTextColor(Color.rgb(95, 135, 207));
        this._toolbar.setTitle((CharSequence) getString(R.string.about_title));
        this._toolbar.setNavigationIcon((int) R.drawable.back);
        this._toolbar.setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                AboutActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
//        GoogleAnalyticsAdapter.stopActivity(this);
    }

    public void onStart() {
        super.onStart();
//        GoogleAnalyticsAdapter.startActivity(this);
    }
}
