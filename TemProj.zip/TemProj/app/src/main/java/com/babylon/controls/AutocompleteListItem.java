package com.babylon.controls;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.babylon.controls.AutocompleteAdapter.RowType;
import com.babylon.translator.R;

public class AutocompleteListItem {
    private boolean mHistory;
    public boolean mIcon;
    public final String mText;

    public AutocompleteListItem(String text, boolean history, boolean icon) {
        this.mText = text;
        this.mHistory = history;
        this.mIcon = icon;
    }

    public int getViewType() {
        return RowType.LIST_ITEM.ordinal();
    }

    public View getView(LayoutInflater inflater, View convertView) {
        View view;
        if (convertView == null) {
            view = inflater.inflate(R.layout.autocomplete_item, null);
        } else {
            view = convertView;
        }
        ((TextView) view.findViewById(R.id.list_content1)).setText(this.mText);
        view.setBackgroundResource(this.mHistory ? R.drawable.ac_list_selector_history : R.drawable.ac_list_selector_server);
        ImageView ivIcon = (ImageView) view.findViewById(R.id.imageIcon);
        View viewSeparator = view.findViewById(R.id.list_ac_separator);
        if (this.mIcon) {
            ivIcon.setVisibility(View.VISIBLE);
            if (this.mHistory) {
                ivIcon.setBackgroundResource(R.drawable.ac_history);
            } else {
                ivIcon.setBackgroundResource(R.drawable.ac_glass);
                viewSeparator.setVisibility(View.VISIBLE);
            }
        } else {
            ivIcon.setVisibility(View.INVISIBLE);
            viewSeparator.setVisibility(View.INVISIBLE);
        }
        return view;
    }

    public String toString() {
        return this.mText;
    }
}
