package com.babylon.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.newrelic.agent.android.instrumentation.Trace;
import java.util.ArrayList;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;

public class BabPrefs {
    public static final String AD_SHOW = "AdShow";
    public static final String BAB_PREFS = "babPrefs";
    public static final String CLEAR_HISTORY = "ClearHistory";
    public static final String DOWNLOAD_OFFLINE = "DownloadOffline";
    public static final String ENABLE_COPY_NOTIFY = "EnableCopy";
    public static final String ENABLE_SLIDER = "EnableSlider";
    public static final String ENABLE_TERM_AC = "EnableAutoComplete";
    private static final String FIRST_AD_DISPLAY = "first_ad_display";
    private static final String FIRST_RUN = "firstRun";
    public static final String FTT_LICENSE = "FttLic";
    private static final String FTT_UPGRADE_FIRST_DISPLAY = "ftt_upgrade_first_display";
    public static final String FUTURE_LICENSE = "FutureLic";
    public static final String INTERSTITIAL_ADS_AD_EVENTS_COUNTER = "interstitialAdEventsCounter";
    public static final String INTERSTITIAL_ADS_DISPLAY_COUNTER = "interstitialAdsDisplayCounter";
    public static final String INTERSTITIAL_ADS_FIRST_USAGE_DATE = "interstitialAdFirstUsageDate";
    public static final String INTERSTITIAL_ADS_LAST_UPGRADE_DISPLAY = "interstitialAdsLastUpgradeDisplay";
    public static final String INTERSTITIAL_ADS_TRANSLATE_COUNTER = "interstitialTranslateCounter";
    public static final String INTERSTITIAL_ADS_UPGRADE_COUNTER = "interstitialAdsUpgradeCounter";
    private static final String OFFLINE_DICTS = "offline_dicts";
    public static final String OFFLINE_LICENSE = "OfflineLic";
    private static final String RATE_COUNTER = "RateCounter";
    private static final String RATE_LIMIT = "RateLimit";
    public static final String REFERRER = "referrer";
    private static final String SLOT_LAST_DAY = "slot_last_day";
    private static final String SRC_FTT_LANG = "SrcFttLang";
    private static final String STT_LANG = "SttLang";
    private static final String TARGET_FTT_LANG = "TargetFttLang";
    private static final String TARGET_TAB = "TargetTab";
    public static final String UPGRADE_FULL_VERSION = "UpgradeToFullVersion";
    public static final String USER_ID = "guid";
    private static final String VERSION_CODE = "VersionCode";
    public static final String VOICE_SEARCH = "VoiceSearch";
    private int mInterstitialAdEventsCounter = 0;
    private int mInterstitialAdFirstUsageDate = 0;
    private int mInterstitialAdsDisplayCounter = 0;
    private String mInterstitialAdsLastUpgradeDisplayDate;
    private int mInterstitialAdsTranslateCounter = 0;
    private int mInterstitialAdsUpgradeBannerDisplayCounter = 0;
    SharedPreferences mPrefs;
    private boolean m_AdDisplay;
    private boolean m_FirstAdDisplay;
    private ArrayList<String> m_arrOfflineDicts;
    private boolean m_bEnableCopy;
    private boolean m_bEnableSlider;
    private boolean m_bEnableTermAC;
    private boolean m_bFirstRun;
    private boolean m_fttUpgradeFirstDisplay;
    private int m_iRateCounter;
    private int m_iRateLimit;
    private int m_iSlotLastDay;
    private int m_iSrcFTTLang;
    private int m_iTargetFTTLang;
    private int m_iTargetLangTab;
    private int m_iVersionCode;
    private String m_sReferrer;
    private String m_sUserID;

    public BabPrefs(Context context) {
        this.mPrefs = context.getSharedPreferences(BAB_PREFS, 0);
        this.m_bFirstRun = this.mPrefs.getBoolean(FIRST_RUN, true);
        this.m_fttUpgradeFirstDisplay = this.mPrefs.getBoolean(FTT_UPGRADE_FIRST_DISPLAY, false);
        this.m_FirstAdDisplay = this.mPrefs.getBoolean(FIRST_AD_DISPLAY, false);
        this.m_AdDisplay = this.mPrefs.getBoolean(AD_SHOW, true);
        this.m_iTargetLangTab = this.mPrefs.getInt(TARGET_TAB, 0);
        this.m_iSrcFTTLang = this.mPrefs.getInt(SRC_FTT_LANG, 0);
        this.m_iTargetFTTLang = this.mPrefs.getInt(TARGET_FTT_LANG, 0);
        this.m_bEnableSlider = this.mPrefs.getBoolean(ENABLE_SLIDER, false);
        this.m_bEnableTermAC = this.mPrefs.getBoolean(ENABLE_TERM_AC, true);
        this.m_bEnableCopy = this.mPrefs.getBoolean(ENABLE_COPY_NOTIFY, true);
        this.m_iRateCounter = this.mPrefs.getInt(RATE_COUNTER, 0);
        this.m_iRateLimit = this.mPrefs.getInt(RATE_LIMIT, 5);
        this.m_iSlotLastDay = this.mPrefs.getInt(SLOT_LAST_DAY, 0);
        this.m_arrOfflineDicts = initOfflineDicts();
        this.m_sReferrer = this.mPrefs.getString(REFERRER, Trace.NULL);
        this.m_sUserID = this.mPrefs.getString(USER_ID, Trace.NULL);
        this.m_iVersionCode = this.mPrefs.getInt(VERSION_CODE, 0);
        this.mInterstitialAdsLastUpgradeDisplayDate = this.mPrefs.getString(INTERSTITIAL_ADS_LAST_UPGRADE_DISPLAY, null);
        this.mInterstitialAdsTranslateCounter = this.mPrefs.getInt(INTERSTITIAL_ADS_TRANSLATE_COUNTER, 0);
        this.mInterstitialAdsDisplayCounter = this.mPrefs.getInt(INTERSTITIAL_ADS_DISPLAY_COUNTER, 0);
        this.mInterstitialAdsUpgradeBannerDisplayCounter = this.mPrefs.getInt(INTERSTITIAL_ADS_UPGRADE_COUNTER, 0);
        this.mInterstitialAdEventsCounter = this.mPrefs.getInt(INTERSTITIAL_ADS_AD_EVENTS_COUNTER, 2);
        this.mInterstitialAdFirstUsageDate = this.mPrefs.getInt(INTERSTITIAL_ADS_FIRST_USAGE_DATE, 0);
    }

    private ArrayList<String> initOfflineDicts() {
        String json = this.mPrefs.getString(OFFLINE_DICTS, null);
        ArrayList<String> dicts = new ArrayList<>();
        if (json != null) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    dicts.add(a.optString(i));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return dicts;
    }

    private void saveDicts() {
        Editor editor = this.mPrefs.edit();
        JSONArray a = new JSONArray();
        for (int i = 0; i < this.m_arrOfflineDicts.size(); i++) {
            a.put(this.m_arrOfflineDicts.get(i));
        }
        if (!this.m_arrOfflineDicts.isEmpty()) {
            editor.putString(OFFLINE_DICTS, a.toString());
        } else {
            editor.putString(OFFLINE_DICTS, null);
        }
        editor.commit();
    }

    public ArrayList<String> getOfflineDicts() {
        return this.m_arrOfflineDicts;
    }

    public void UpdateOfflineDicts(String sDict, boolean bAdd) {
        if (!bAdd) {
            int index = this.m_arrOfflineDicts.indexOf(sDict);
            if (index != -1) {
                this.m_arrOfflineDicts.remove(index);
            }
        } else if (!this.m_arrOfflineDicts.contains(sDict)) {
            this.m_arrOfflineDicts.add(sDict);
        }
        saveDicts();
    }

    public void RemoveLangsKeys() {
        Editor editor = this.mPrefs.edit();
        editor.remove(STT_LANG);
        editor.remove(SRC_FTT_LANG);
        editor.remove(TARGET_FTT_LANG);
        editor.remove(TARGET_TAB);
        editor.commit();
    }

    public int getInterstitialsFirstUsageDate() {
        return this.mInterstitialAdFirstUsageDate;
    }

    public void putInterstitialsFirstUsageDate(int date) {
        this.mInterstitialAdFirstUsageDate = date;
        Editor editor = this.mPrefs.edit();
        editor.putInt(INTERSTITIAL_ADS_FIRST_USAGE_DATE, this.mInterstitialAdFirstUsageDate);
        editor.commit();
    }

    public String getInterstitialsLastUpgradeDisplayDate() {
        return this.mInterstitialAdsLastUpgradeDisplayDate;
    }

    public void putInterstitialsLastUpgradeDisplayDate(String date) {
        this.mInterstitialAdsLastUpgradeDisplayDate = date;
        Editor editor = this.mPrefs.edit();
        editor.putString(INTERSTITIAL_ADS_LAST_UPGRADE_DISPLAY, this.mInterstitialAdsLastUpgradeDisplayDate);
        editor.commit();
    }

    public int getInterstitialsTranslateCounter() {
        return this.mInterstitialAdsTranslateCounter;
    }

    public void putInterstitialsTranslateCounter(int count) {
        this.mInterstitialAdsTranslateCounter = count;
        Editor editor = this.mPrefs.edit();
        editor.putInt(INTERSTITIAL_ADS_TRANSLATE_COUNTER, this.mInterstitialAdsTranslateCounter);
        editor.commit();
    }

    public int getInterstitialsAdDisplayCounter() {
        return this.mInterstitialAdsDisplayCounter;
    }

    public void putInterstitialsAdDisplayCounter(int count) {
        this.mInterstitialAdsDisplayCounter = count;
        Editor editor = this.mPrefs.edit();
        editor.putInt(INTERSTITIAL_ADS_DISPLAY_COUNTER, this.mInterstitialAdsDisplayCounter);
        editor.commit();
    }

    public int getInterstitialsUpgradeCounter() {
        return this.mInterstitialAdsUpgradeBannerDisplayCounter;
    }

    public void putInterstitialsUpgradeCounter(int count) {
        this.mInterstitialAdsUpgradeBannerDisplayCounter = count;
        Editor editor = this.mPrefs.edit();
        editor.putInt(INTERSTITIAL_ADS_UPGRADE_COUNTER, this.mInterstitialAdsUpgradeBannerDisplayCounter);
        editor.commit();
    }

    public int getInterstitialsAdEventsCounter() {
        return this.mInterstitialAdEventsCounter;
    }

    public void putInterstitialsAdEventsCounter(int count) {
        this.mInterstitialAdEventsCounter = count;
        Editor editor = this.mPrefs.edit();
        editor.putInt(INTERSTITIAL_ADS_AD_EVENTS_COUNTER, this.mInterstitialAdEventsCounter);
        editor.commit();
    }

    public boolean getFirstRun() {
        return this.m_bFirstRun;
    }

    public void putFirstRun(boolean bFirstRun) {
        this.m_bFirstRun = bFirstRun;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(FIRST_RUN, bFirstRun);
        editor.commit();
    }

    public int getLastVersionCode() {
        return this.m_iVersionCode;
    }

    public void putLastVersionCode(int iVersionCode) {
        this.m_iVersionCode = iVersionCode;
        Editor editor = this.mPrefs.edit();
        editor.putInt(VERSION_CODE, iVersionCode);
        editor.commit();
    }

    public boolean getFttUpgradeFirstDisplay() {
        return this.m_fttUpgradeFirstDisplay;
    }

    public void putFttUpgradeFirstDisplay(boolean firstDisplay) {
        this.m_fttUpgradeFirstDisplay = firstDisplay;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(FTT_UPGRADE_FIRST_DISPLAY, firstDisplay);
        editor.commit();
    }

    public boolean getFirstAdDisplay() {
        return this.m_FirstAdDisplay;
    }

    public void putFirstAdDisplay(boolean firstDisplay) {
        this.m_FirstAdDisplay = firstDisplay;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(FIRST_AD_DISPLAY, firstDisplay);
        editor.commit();
    }

    public boolean getShowAdDisplay() {
        return this.m_AdDisplay;
    }

    public void putShowAdDisplay(boolean adDisplay) {
        this.m_AdDisplay = adDisplay;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(AD_SHOW, adDisplay);
        editor.commit();
    }

    public String getReferrer() {
        return this.m_sReferrer;
    }

    public void putReferrer(String sReferrer) {
        this.m_sReferrer = sReferrer;
        Editor editor = this.mPrefs.edit();
        editor.putString(REFERRER, sReferrer);
        editor.commit();
    }

    public String getUserID() {
        if (this.m_sUserID == Trace.NULL) {
            putUserID(UUID.randomUUID().toString());
        }
        return this.m_sUserID;
    }

    public void putUserID(String sUserID) {
        this.m_sUserID = sUserID;
        Editor editor = this.mPrefs.edit();
        editor.putString(USER_ID, this.m_sUserID);
        editor.commit();
    }

    public int getRateCounter() {
        return this.m_iRateCounter;
    }

    public void putRateCounter(int iCount) {
        this.m_iRateCounter = iCount;
        Editor editor = this.mPrefs.edit();
        editor.putInt(RATE_COUNTER, this.m_iRateCounter);
        editor.commit();
    }

    public int getRateLimit() {
        return this.m_iRateLimit;
    }

    public void putRateLimit(int iLimit) {
        this.m_iRateLimit = iLimit;
        Editor editor = this.mPrefs.edit();
        editor.putInt(RATE_LIMIT, this.m_iRateLimit);
        editor.commit();
    }

    public int getSourceFTTLang() {
        return this.m_iSrcFTTLang;
    }

    public void putSourceFTTLang(int iLang) {
        this.m_iSrcFTTLang = iLang;
        Editor editor = this.mPrefs.edit();
        editor.putInt(SRC_FTT_LANG, this.m_iSrcFTTLang);
        editor.commit();
    }

    public int getTargetFTTLang() {
        return this.m_iTargetFTTLang;
    }

    public void putTargetFTTLang(int iLang) {
        this.m_iTargetFTTLang = iLang;
        Editor editor = this.mPrefs.edit();
        editor.putInt(TARGET_FTT_LANG, this.m_iTargetFTTLang);
        editor.commit();
    }

    public String getSTTLang() {
        return this.mPrefs.getString(STT_LANG, "en-US");
    }

    public void putSTTLang(String sSTTLang) {
        Editor editor = this.mPrefs.edit();
        editor.putString(STT_LANG, sSTTLang);
        editor.commit();
    }

    public int getTargetLangTab() {
        return this.m_iTargetLangTab;
    }

    public void putTargetLangTab(int iLang) {
        this.m_iTargetLangTab = iLang;
        Editor editor = this.mPrefs.edit();
        editor.putInt(TARGET_TAB, this.m_iTargetLangTab);
        editor.commit();
    }

    public int getSlotLastDay() {
        return this.m_iSlotLastDay;
    }

    public void putSlotLastDay(int sSlotLastDay) {
        this.m_iSlotLastDay = sSlotLastDay;
        Editor editor = this.mPrefs.edit();
        editor.putInt(SLOT_LAST_DAY, this.m_iSlotLastDay);
        editor.commit();
    }

    public void putOfflineDicts(int sSlotLastDay) {
        this.m_iSlotLastDay = sSlotLastDay;
        Editor editor = this.mPrefs.edit();
        editor.putInt(SLOT_LAST_DAY, this.m_iSlotLastDay);
        editor.commit();
    }

    public void putClearHistory(boolean bClear) {
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(CLEAR_HISTORY, bClear);
        editor.commit();
    }

    public void putEnableSlider(boolean bEnable) {
        this.m_bEnableSlider = bEnable;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(ENABLE_SLIDER, bEnable);
        editor.commit();
    }

    public boolean getEnableSlider() {
        return this.mPrefs.getBoolean(ENABLE_SLIDER, false);
    }

    public void putEnableTermAC(boolean bEnable) {
        this.m_bEnableTermAC = bEnable;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(ENABLE_TERM_AC, bEnable);
        editor.commit();
    }

    public boolean getEnableTermAC() {
        return this.mPrefs.getBoolean(ENABLE_TERM_AC, true);
    }

    public boolean getEnableCopy() {
        return this.mPrefs.getBoolean(ENABLE_COPY_NOTIFY, true);
    }

    public void putEnableCopy(boolean bEnable) {
        this.m_bEnableCopy = bEnable;
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(ENABLE_COPY_NOTIFY, bEnable);
        editor.commit();
    }

    public boolean getClearHistory() {
        return this.mPrefs.getBoolean(CLEAR_HISTORY, true);
    }

    public boolean getPurchaseStateFtt() {
        return this.mPrefs.getBoolean(FTT_LICENSE, false);
    }

    public void putPurchaseStateFtt(boolean bPurchaseStateFtt) {
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(FTT_LICENSE, bPurchaseStateFtt);
        editor.commit();
    }

    public boolean getPurchaseStateOffline() {
        return this.mPrefs.getBoolean(OFFLINE_LICENSE, false);
    }

    public void putPurchaseStateOffline(boolean bPurchaseStateOffline) {
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(OFFLINE_LICENSE, bPurchaseStateOffline);
        editor.commit();
    }

    public boolean getPurchaseStateFuture() {
        return this.mPrefs.getBoolean(FUTURE_LICENSE, false);
    }

    public void putPurchaseStateFuture(boolean bPurchaseStateFuture) {
        Editor editor = this.mPrefs.edit();
        editor.putBoolean(FUTURE_LICENSE, bPurchaseStateFuture);
        editor.commit();
    }

    public void Commit() {
        Editor editor = this.mPrefs.edit();
        if (this.m_bFirstRun) {
            editor.putBoolean(FIRST_RUN, false);
        }
        editor.putBoolean(ENABLE_SLIDER, this.m_bEnableSlider);
        editor.putBoolean(ENABLE_COPY_NOTIFY, this.m_bEnableCopy);
        editor.putBoolean(ENABLE_TERM_AC, this.m_bEnableTermAC);
        editor.commit();
    }
}
