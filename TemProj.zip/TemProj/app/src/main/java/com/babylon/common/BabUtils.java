package com.babylon.common;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.babylon.translate.BabApplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

public class BabUtils {
    private static final String DELIMS = "[ .,?!]+";
    private static String TAG = "babylon utils";

    public static boolean isOneWord(String definition, int sourceLanguage) {
        if (definition == null) {
            return false;
        }
        String[] words = definition.split(DELIMS);
        return !isAsianSourceLanguage(sourceLanguage) && words.length == 1;
    }

    public static boolean isAsianSourceLanguage(int sourceLanguage) {
        return sourceLanguage == 16 || sourceLanguage == 10 || sourceLanguage == 9 || sourceLanguage == 8;
    }

    public static void debugToast(Context c, String text) {
    }

    public static void checkFirstFttUpgradeDisplay(BabPrefs prefs) {
        if (prefs != null && !prefs.getFttUpgradeFirstDisplay()) {
//            GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_FTT_CAP_LIMIT_FIRST_DISPLAY);
            prefs.putFttUpgradeFirstDisplay(true);
        }
    }

    public static void checkFirsAdDisplay(BabPrefs prefs) {
        if (prefs != null && !prefs.getFirstAdDisplay()) {
//            GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_ADS, AnalyticsConstants.EVENT_ADS_FIRST_DISPLAY);
            prefs.putFirstAdDisplay(true);
        }
    }

    public static synchronized void initPersistentPrefs() {
        synchronized (BabUtils.class) {
            File f = new File(Constants.EXTERNAL_APP_DIRECTORY_FULL_PATH);
            if (!f.exists() && !f.mkdirs()) {
                Log.e(TAG, "Failed creating external app directory");
            }
            try {
                if (BabApplication.getPersistentPrefs() == null) {
                    BabApplication.setPersistentPrefs(new PersistentPrefs(BabApplication.getContext()));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return;
    }

    public static void writeStringAsFile(String fileContents, File f) {
        try {
            FileWriter out = new FileWriter(f);
            out.write(fileContents);
            out.close();
        } catch (IOException e) {
            Log.e(TAG, e.getMessage());
        }
    }

    public static String readFileAsString(File f) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            BufferedReader in = new BufferedReader(new FileReader(f));
            while (true) {
                try {
                    String line = in.readLine();
                    if (line == null) {
                        break;
                    }
                    stringBuilder.append(line);
                } catch (FileNotFoundException e) {
                    e = e;
                    BufferedReader bufferedReader = in;
                } catch (IOException e2) {
                    BufferedReader bufferedReader2 = in;
                    Log.e(TAG, e2.getMessage());
                    return stringBuilder.toString();
                }
            }
            in.close();
            BufferedReader bufferedReader3 = in;
        } catch (FileNotFoundException e3) {
            Log.e(TAG, e3.getMessage());
            return stringBuilder.toString();
        } catch (IOException e4) {
            Log.e(TAG, e4.getMessage());
            return stringBuilder.toString();
        }
        return stringBuilder.toString();
    }

    public static String readFileFromAsset(Context c, String fileName) {
        try {
            InputStream input = c.getAssets().open(fileName);
            byte[] buffer = new byte[input.available()];
            input.read(buffer);
            input.close();
            return new String(buffer);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isDeviceOnline(Context ctx) {
        NetworkInfo ni = ((ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }
}
