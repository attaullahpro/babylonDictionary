package com.babylon.controls;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.AutoCompleteTextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;

import com.babylon.common.ACObject;
import com.babylon.translate.BabActivity;
import com.babylon.translate.BabApplication;
import com.babylon.translator.R;
import com.newrelic.agent.android.instrumentation.Trace;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class CustomEditText extends AppCompatAutoCompleteTextView {
    /* access modifiers changed from: private */
    public static int mTargetLang;
    private static String AUTO_COMPLETE_URL = "http://clientac.babsrv.com/?f=3&n=10&q=%s&l=0&t=0&p=babylon&b=1&callback=acp_new";
    private static boolean mAutocomplete;
    private static HttpParams mHttpParameters;
    /* access modifiers changed from: private */
    public Drawable dClose;
    /* access modifiers changed from: private */
    public Drawable dMicrophone;
    /* access modifiers changed from: private */
    public int mCountBefore = 0;
    public String mLastTermClicked = Trace.NULL;
    /* access modifiers changed from: private */
    public boolean mRecordMode = true;
    /* access modifiers changed from: private */
    public int mSesssionId;
    /* access modifiers changed from: private */
    public String mStringBefore = Trace.NULL;
    ArrayList<OnSearch> SearchObservers = new ArrayList<>();
    AutocompleteAdapter mAdapter;
    List<AutocompleteListItem> mItemsAutocomplete;
    private Drawable dMicrophonePress;
    private Drawable dRight;
    private boolean mRecordExist = true;

    public CustomEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        CreateCustomEditText();
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        CreateCustomEditText();
    }

    public static void SetTargetLang(int iLang) {
        mTargetLang = iLang;
    }

    public static void SetAutoComplete(boolean bEnable) {
        mAutocomplete = bEnable;
    }

    public static String GetAutoCompleteFromServer(String sTerm) {
        try {
            HttpClient client = new DefaultHttpClient(mHttpParameters);
            String sTerm2 = sTerm.replace(' ', '+').replace("\"", "%22");
            InputStream in = client.execute(new HttpGet(String.format(AUTO_COMPLETE_URL, sTerm2))).getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder str = new StringBuilder();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                str.append(line);
            }
            in.close();
            if (str != null) {
                return str.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Trace.NULL;
    }

    public void setOnSearchEvent(OnSearch observer) {
        this.SearchObservers.add(observer);
    }

    private void CreateCustomEditText() {
        mHttpParameters = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(mHttpParameters, 3000);
        HttpConnectionParams.setSoTimeout(mHttpParameters, 5000);
        this.mRecordExist = getContext().getPackageManager().queryIntentActivities(new Intent("android.speech.action.RECOGNIZE_SPEECH"), 0).size() > 0;
        this.mSesssionId = 0;
        this.mItemsAutocomplete = new ArrayList();
        mAutocomplete = BabApplication.getPrefs().getEnableTermAC();
        this.mAdapter = new AutocompleteAdapter(getContext(), this.mItemsAutocomplete);
        this.dMicrophone = getContext().getResources().getDrawable(R.drawable.microphone);
        this.dMicrophonePress = getContext().getResources().getDrawable(R.drawable.microphone_press);
        this.dClose = getContext().getResources().getDrawable(R.drawable.x_button);
        setCompoundDrawablesWithIntrinsicBounds(null, null, this.dMicrophone, null);
        addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                CustomEditText.this.mRecordMode = s.toString().length() == 0;
                CustomEditText.this.setCompoundDrawablesWithIntrinsicBounds(null, null, CustomEditText.this.mRecordMode ? CustomEditText.this.dMicrophone : CustomEditText.this.dClose, null);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                CustomEditText.this.mCountBefore = count;
                CustomEditText.this.mStringBefore = s.toString();
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int iCount = count - CustomEditText.this.mCountBefore;
                if ((iCount == 1 && s.toString().startsWith(CustomEditText.this.mStringBefore)) || (iCount == -1 && CustomEditText.this.mStringBefore.startsWith(s.toString()))) {
                    String sTerm = CustomEditText.this.getText().toString();
                    if (!CustomEditText.this.mLastTermClicked.equals(sTerm)) {
                        CustomEditText.this.UpdateAutoComplete(sTerm);
                    }
                }
            }
        });
        setAdapter(this.mAdapter);
    }

    public void AddTerm() {
        String sTerm = getText().toString();
        if (sTerm.length() > 1) {
            BabApplication.mACDatabase.create(new ACObject(sTerm));
        }
    }

    public void ClearHistory() {
        this.mItemsAutocomplete.clear();
        setAdapter(new AutocompleteAdapter(getContext(), this.mItemsAutocomplete));
        BabApplication.mACDatabase.ClearAll();
    }

    public void setCompoundDrawables(Drawable left, Drawable top, Drawable right, Drawable bottom) {
        if (right != null) {
            this.dRight = right;
        }
        super.setCompoundDrawables(left, top, right, bottom);
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == 1 && ((int) event.getX()) >= getWidth() - this.dRight.getBounds().width()) {
            if (!this.mRecordMode || !this.mRecordExist) {
                event.setAction(3);
                setText(Trace.NULL);
                requestFocus();
            } else {
                setCompoundDrawablesWithIntrinsicBounds(null, null, this.dMicrophonePress, null);
                ((BabActivity) getContext()).recordText(true);
            }
        }
        return super.onTouchEvent(event);
    }

    public void ResetMicrophoneImage() {
        setCompoundDrawablesWithIntrinsicBounds(null, null, this.dMicrophone, null);
    }

    public void ClearAdapter() {
        dismissDropDown();
        setAdapter(null);
    }

    /* access modifiers changed from: private */
    public void UpdateAutoComplete(String sText) {
        if (!mAutocomplete || sText.length() <= 1) {
            setAdapter(null);
            dismissDropDown();
            return;
        }
        this.mSesssionId++;
        try {
            new GetAutoCompleteTask(this.mSesssionId).execute(sText);
        } catch (Exception e) {
        }
    }

    /* access modifiers changed from: protected */
    public void performFiltering(CharSequence text, int keyCode) {
        super.performFiltering(Trace.NULL, keyCode);
    }

    /* access modifiers changed from: protected */
    public void finalize() throws Throwable {
        this.dRight = null;
        super.finalize();
    }

    public interface OnSearch {
        void callback();
    }

    private class GetAutoCompleteTask extends AsyncTask<String, Void, String> {
        private String mTerm;
        private int mySessionId;

        GetAutoCompleteTask(int iSession) {
            this.mySessionId = iSession;
        }

        /* access modifiers changed from: protected */
        public String doInBackground(String... terms) {
            try {
                this.mTerm = terms[0];
                if (CustomEditText.mTargetLang != -1) {
                    return CustomEditText.GetAutoCompleteFromServer(this.mTerm);
                }
                return Trace.NULL;
            } catch (Exception e) {
                return Trace.NULL;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(String result) {
            String[] arrSuggestions;
            try {
                if (CustomEditText.this.mSesssionId == this.mySessionId) {
                    CustomEditText.this.mItemsAutocomplete.clear();
                    ACObject[] arrHistory = BabApplication.mACDatabase.read(this.mTerm, 3);
                    int index = 0;
                    if (arrHistory != null && arrHistory.length > 0) {
                        for (ACObject acObject : arrHistory) {
                            List<AutocompleteListItem> list = CustomEditText.this.mItemsAutocomplete;
                            AutocompleteListItem autocompleteListItem = new AutocompleteListItem(acObject.objectName, true, index == 0);
                            list.add(autocompleteListItem);
                            index++;
                        }
                    }
                    int index1 = 0;
                    if (result.length() > 0) {
                        for (String suggestion : result.split(",")) {
                            boolean bExists = false;
                            for (int i = 0; i < arrHistory.length && !bExists; i++) {
                                if (arrHistory[i].objectName.equals(suggestion)) {
                                    bExists = true;
                                }
                            }
                            if (!bExists) {
                                List<AutocompleteListItem> list2 = CustomEditText.this.mItemsAutocomplete;
                                AutocompleteListItem autocompleteListItem2 = new AutocompleteListItem(suggestion, false, index1 == 0);
                                list2.add(autocompleteListItem2);
                                index1++;
                            }
                        }
                    }
                    if (CustomEditText.this.mSesssionId != this.mySessionId) {
                        return;
                    }
                    if (CustomEditText.this.mLastTermClicked.equals(this.mTerm) || index + index1 <= 0 || CustomEditText.this.getText().length() <= 1) {
                        CustomEditText.this.setAdapter(null);
                        CustomEditText.this.dismissDropDown();
                        return;
                    }
                    CustomEditText.this.setAdapter(new AutocompleteAdapter(CustomEditText.this.getContext(), CustomEditText.this.mItemsAutocomplete));
                    if (CustomEditText.this.hasFocus()) {
                        CustomEditText.this.showDropDown();
                    }
                }
            } catch (Exception e) {
//                Log.m19e(e);
            }
        }
    }
}
