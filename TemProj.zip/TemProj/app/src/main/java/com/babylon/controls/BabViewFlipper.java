package com.babylon.controls;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ViewFlipper;

public class BabViewFlipper extends ViewFlipper {
    public BabViewFlipper(Context context) {
        super(context);
    }

    public BabViewFlipper(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void onDetachedFromWindow() {
        try {
            super.onDetachedFromWindow();
        } catch (Exception e) {
            stopFlipping();
        }
    }
}
