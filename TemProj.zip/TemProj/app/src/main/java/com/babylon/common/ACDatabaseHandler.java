package com.babylon.common;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.newrelic.agent.android.instrumentation.Trace;

public class ACDatabaseHandler extends SQLiteOpenHelper {
    protected static final String DATABASE_NAME = "BabACDatabase";
    private static final int DATABASE_VERSION = 1;
    private static int MAX_DB_ROWS = 5000;
    public static final String TAG = "DatabaseHandler.java";
    public String fieldObjectId = "id";
    public String fieldObjectName = "name";
    public String fieldTime = "time";
    public String tableName = "terms";

    public ACDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(Trace.NULL + "CREATE TABLE " + this.tableName)).append(" ( ").toString())).append(this.fieldObjectId).append(" INTEGER PRIMARY KEY AUTOINCREMENT, ").toString())).append(this.fieldObjectName).append(" TEXT, ").toString())).append(this.fieldTime).append(" INTEGER ").toString())).append(" ) ").toString());
        } catch (Exception e) {
        }
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + this.tableName);
        onCreate(db);
    }

    public boolean create(ACObject myObj) {
        boolean createSuccessful = false;
        try {
            SQLiteDatabase db = getWritableDatabase();
            if (!checkIfExists(myObj.objectName, db)) {
                ContentValues values = new ContentValues();
                values.put(this.fieldObjectName, myObj.objectName);
                values.put(this.fieldTime, Long.valueOf(System.currentTimeMillis()));
                createSuccessful = db.insert(this.tableName, null, values) > 0;
                db.close();
            }
        } catch (Exception e) {
        }
        return createSuccessful;
    }

    private boolean checkIfExists(String objectName, SQLiteDatabase db) {
        String objectName2 = objectName.replaceAll("'", "''");
        boolean recordExists = false;
        Cursor cursor = db.rawQuery("SELECT " + this.fieldObjectId + " FROM " + this.tableName + " WHERE " + this.fieldObjectName + " = '" + objectName2 + "'", null);
        if (cursor != null) {
            if (cursor.getCount() > 0 && cursor.moveToFirst()) {
                ContentValues updateTerm = new ContentValues();
                updateTerm.put(this.fieldObjectName, objectName2);
                updateTerm.put(this.fieldTime, Long.valueOf(System.currentTimeMillis()));
                db.update(this.tableName, updateTerm, this.fieldObjectId + "=" + cursor.getInt(cursor.getColumnIndex(this.fieldObjectId)), null);
                recordExists = true;
            }
            cursor.close();
        }
        return recordExists;
    }

    public ACObject[] read(String searchTerm, int numResults) {
        String sql = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(Trace.NULL + "SELECT * FROM " + this.tableName)).append(" WHERE ").append(this.fieldObjectName).append(" LIKE '").append(searchTerm.replaceAll("'", "''")).append("%'").toString())).append(" ORDER BY ").append(this.fieldTime).append(" DESC").toString())).append(" LIMIT ").append(numResults).toString();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        ACObject[] ObjectItemData = new ACObject[cursor.getCount()];
        int x = 0;
        if (cursor.moveToFirst()) {
            do {
                ObjectItemData[x] = new ACObject(cursor.getString(cursor.getColumnIndex(this.fieldObjectName)));
                x++;
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return ObjectItemData;
    }

    public void ClearAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(this.tableName, null, null);
        db.close();
    }

    public void CheckSize() {
        try {
            String countQuery = new StringBuilder(String.valueOf("SELECT * FROM " + this.tableName)).append(" ORDER BY ").append(this.fieldTime).append(" ASC").toString();
            SQLiteDatabase db = getReadableDatabase();
            Cursor cursor = db.rawQuery(countQuery, null);
            if (cursor.getCount() > MAX_DB_ROWS) {
                int iRemove = MAX_DB_ROWS / 10;
                if (cursor.moveToFirst()) {
                    do {
                        db.delete(this.tableName, this.fieldObjectId + "=" + cursor.getInt(cursor.getColumnIndex(this.fieldObjectId)), null);
                        iRemove--;
                    } while (iRemove > 0);
                }
            }
            cursor.close();
        } catch (Exception e) {
            Log.d("test", e.toString());
        }
    }
}
