package com.babylon.translate;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ViewFlipper;
//import com.babylon.analytics.GoogleAnalyticsAdapter;
import com.babylon.translator.R;

public class HowToActivity extends Activity {
    private float lastX;
    private ViewFlipper mViewFlipper;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.how_to_layout);
        this.mViewFlipper = (ViewFlipper) findViewById(R.id.view_flipper);
    }

    public void closeFunc(View v) {
        finish();
    }

    public boolean onTouchEvent(MotionEvent touchevent) {
        switch (touchevent.getAction()) {
            case 0:
                this.lastX = touchevent.getX();
                break;
            case 1:
                float currentX = touchevent.getX();
                int iDisplayChild = this.mViewFlipper.getDisplayedChild();
                if (iDisplayChild == 2 && this.lastX == currentX) {
                    finish();
                }
                if (this.lastX < currentX) {
                    if (iDisplayChild != 0) {
                        this.mViewFlipper.setInAnimation(this, R.anim.in_from_left);
                        this.mViewFlipper.setOutAnimation(this, R.anim.out_to_right);
                        this.mViewFlipper.showPrevious();
                    }
                }
                if (this.lastX > currentX && iDisplayChild != 2) {
                    this.mViewFlipper.setInAnimation(this, R.anim.in_from_right);
                    this.mViewFlipper.setOutAnimation(this, R.anim.out_to_left);
                    this.mViewFlipper.showNext();
                    break;
                }
                break;
        }
        return false;
    }

    public void onStop() {
        super.onStop();
    }

    public void onStart() {
        super.onStart();

    }
}
