package com.babylon.common;

import android.content.Context;
import java.io.File;
import java.io.IOException;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class PersistentPrefs {
    /* access modifiers changed from: private */
    public static PrefsObject mPrefs;
    String LOAD_PREFS_FAILURE_PREFIX = "load persistence Prefs failed -";
    private Context mContext;
    private ObjectMapper mMapper;
    /* access modifiers changed from: private */
    public String mPersistentPrefsPath = String.format("%s%s%s", new Object[]{Constants.EXTERNAL_APP_DIRECTORY_FULL_PATH, File.separator, Constants.PERSISTENT_PREFERENCES_FILE_NAME});

    public PersistentPrefs(Context c) throws IOException {
        this.mContext = c;
        File f = new File(this.mPersistentPrefsPath);
        if (f.exists()) {
//            mPrefs = loadPrefs();
            return;
        }
        f.createNewFile();
        mPrefs = new PrefsObject();
        savePrefs();
    }

    public int getFtt() {
        if (mPrefs != null) {
            return mPrefs.getFtt();
        }
        return -1;
    }

    public boolean fttCapReached() {
        if (mPrefs != null && getFtt() >= 10) {
            return true;
        }
        return false;
    }

    public void incrementFtt() {
        if (mPrefs != null) {
            mPrefs.incrementFtt();
            savePrefs();
            BabUtils.debugToast(this.mContext, "Current FTT counter=" + mPrefs.getFtt());
        }
    }

    public void setFtt(int count) {
        if (mPrefs != null) {
            mPrefs.setFtt(count);
            savePrefs();
        }
    }

    /* access modifiers changed from: private */
    public ObjectMapper getMapper() {
        if (this.mMapper == null) {
            this.mMapper = new ObjectMapper();
        }
        return this.mMapper;
    }

    private void savePrefs() {
        new Thread() {
            public void run() {
                try {
                    PersistentPrefs.this.getMapper().writeValue(new File(PersistentPrefs.this.mPersistentPrefsPath), (Object) PersistentPrefs.mPrefs);
                } catch (JsonGenerationException e) {
                    e.printStackTrace();
                } catch (JsonMappingException e2) {
                    e2.printStackTrace();
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
            }
        }.start();
    }

    private PrefsObject loadPrefs() {
        try {
            return (PrefsObject) getMapper().readValue(new File(this.mPersistentPrefsPath), PrefsObject.class);
        } catch (JsonParseException e) {
//            BugSenseHandler.sendEvent(String.format("%s - %s", new Object[]{this.LOAD_PREFS_FAILURE_PREFIX, e.getMessage()}));
            e.printStackTrace();
        } catch (JsonMappingException e2) {
//            BugSenseHandler.sendEvent(String.format("%s - %s", new Object[]{this.LOAD_PREFS_FAILURE_PREFIX, e2.getMessage()}));
            e2.printStackTrace();
        } catch (IOException e3) {
//            BugSenseHandler.sendEvent(String.format("%s - %s", new Object[]{this.LOAD_PREFS_FAILURE_PREFIX, e3.getMessage()}));
            e3.printStackTrace();
        }
        return null;
    }
}
