package com.babylon.common;

import android.content.Context;
import android.util.Log;

import com.babylon.translator.R;
import com.newrelic.agent.android.instrumentation.Trace;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

public class BabLangs {
    private final String FILENAME = "langs";
    private final Map<String, Integer> mLangMap = new HashMap();
    ArrayList<Integer> mSelectedLangs;

    public BabLangs() {
        this.mLangMap.put("Albanian", Integer.valueOf(38));
        this.mLangMap.put("Arabic", Integer.valueOf(15));
        this.mLangMap.put("Basque", Integer.valueOf(52));
        this.mLangMap.put("Bengali", Integer.valueOf(70));
        this.mLangMap.put("Bulgarian", Integer.valueOf(42));
        this.mLangMap.put("Catalan", Integer.valueOf(34));
        this.mLangMap.put("Chinese (Simplified)", Integer.valueOf(10));
        this.mLangMap.put("Chinese (Traditional)", Integer.valueOf(9));
        this.mLangMap.put("Croatian", Integer.valueOf(35));
        this.mLangMap.put("Czech", Integer.valueOf(31));
        this.mLangMap.put("Danish", Integer.valueOf(43));
        this.mLangMap.put("Dari", Integer.valueOf(83));
        this.mLangMap.put("Dutch", Integer.valueOf(4));
        this.mLangMap.put("English", Integer.valueOf(0));
        this.mLangMap.put("Estonian", Integer.valueOf(41));
        this.mLangMap.put("Farsi", Integer.valueOf(51));
        this.mLangMap.put("Filipino", Integer.valueOf(68));
        this.mLangMap.put("Finnish", Integer.valueOf(44));
        this.mLangMap.put("French", Integer.valueOf(1));
        this.mLangMap.put("German", Integer.valueOf(6));
        this.mLangMap.put("Greek", Integer.valueOf(11));
        this.mLangMap.put("Hausa", Integer.valueOf(65));
        this.mLangMap.put("Hebrew", Integer.valueOf(14));
        this.mLangMap.put("Hindi", Integer.valueOf(60));
        this.mLangMap.put("Hungarian", Integer.valueOf(30));
        this.mLangMap.put("Icelandic", Integer.valueOf(45));
        this.mLangMap.put("Indonesian", Integer.valueOf(62));
        this.mLangMap.put("Italian", Integer.valueOf(2));
        this.mLangMap.put("Japanese", Integer.valueOf(8));
        this.mLangMap.put("Korean", Integer.valueOf(12));
        this.mLangMap.put("Latin", Integer.valueOf(56));
        this.mLangMap.put("Latvian", Integer.valueOf(33));
        this.mLangMap.put("Lithuanian", Integer.valueOf(32));
        this.mLangMap.put("Macedonian", Integer.valueOf(53));
        this.mLangMap.put("Malay", Integer.valueOf(67));
        this.mLangMap.put("Mongolian", Integer.valueOf(64));
        this.mLangMap.put("Norwegian", Integer.valueOf(46));
        this.mLangMap.put("Pashto", Integer.valueOf(66));
        this.mLangMap.put("Polish", Integer.valueOf(29));
        this.mLangMap.put("Portuguese", Integer.valueOf(5));
        this.mLangMap.put("Romanian", Integer.valueOf(47));
        this.mLangMap.put("Russian", Integer.valueOf(7));
        this.mLangMap.put("Serbian", Integer.valueOf(36));
        this.mLangMap.put("Slovak", Integer.valueOf(37));
        this.mLangMap.put("Slovenian", Integer.valueOf(40));
        this.mLangMap.put("Somali", Integer.valueOf(61));
        this.mLangMap.put("Spanish", Integer.valueOf(3));
        this.mLangMap.put("Swedish", Integer.valueOf(48));
        this.mLangMap.put("Thai", Integer.valueOf(16));
        this.mLangMap.put("Turkish", Integer.valueOf(13));
        this.mLangMap.put("Ukrainian", Integer.valueOf(49));
        this.mLangMap.put("Urdu", Integer.valueOf(39));
        this.mLangMap.put("Vietnamese", Integer.valueOf(63));
        this.mLangMap.put("Other", Integer.valueOf(17));
    }

    public String GetISOFromInternalLangID(int langID) {
        if (langID == 0) {
            return "en";
        }
        if (langID == 15) {
            return "ar";
        }
        if (langID == 42) {
            return "bg";
        }
        if (langID == 10 || langID == 9) {
            return "zh";
        }
        if (langID == 31) {
            return "cs";
        }
        if (langID == 43) {
            return "da";
        }
        if (langID == 4) {
            return "nl";
        }
        if (langID == 51) {
            return "fa";
        }
        if (langID == 44) {
            return "fi";
        }
        if (langID == 1) {
            return "fr";
        }
        if (langID == 6) {
            return "de";
        }
        if (langID == 11) {
            return "el";
        }
        if (langID == 14) {
            return "he";
        }
        if (langID == 60) {
            return "hi";
        }
        if (langID == 30) {
            return "hu";
        }
        if (langID == 2) {
            return "it";
        }
        if (langID == 8) {
            return "ja";
        }
        if (langID == 12) {
            return "ko";
        }
        if (langID == 46) {
            return "no";
        }
        if (langID == 66) {
            return "ps";
        }
        if (langID == 29) {
            return "pl";
        }
        if (langID == 5) {
            return "pt";
        }
        if (langID == 47) {
            return "ro";
        }
        if (langID == 7) {
            return "ru";
        }
        if (langID == 36) {
            return "sr";
        }
        if (langID == 3) {
            return "es";
        }
        if (langID == 48) {
            return "sv";
        }
        if (langID == 16) {
            return "th";
        }
        if (langID == 13) {
            return "tr";
        }
        if (langID == 49) {
            return "uk";
        }
        if (langID == 39) {
            return "ur";
        }
        return "en";
    }

    public Integer GetLangNum(String sLang) {
        Integer iLang = (Integer) this.mLangMap.get(sLang);
        if (iLang == null) {
            return (Integer) this.mLangMap.get("English");
        }
        return iLang;
    }

    public String GetLangFromNum(int iLang) {
        for (Entry<String, Integer> entry : this.mLangMap.entrySet()) {
            if (((Integer) entry.getValue()).intValue() == iLang) {
                return (String) entry.getKey();
            }
        }
        return Trace.NULL;
    }

    public FlagList GetFlagsList(Context ctx) {
        FlagList list = new FlagList();
        list.add(new FlagData(0, "Albanian", R.drawable.flag_albanian_big));
        list.add(new FlagData(0, "Arabic", R.drawable.flag_arabic_big));
        list.add(new FlagData(0, "Basque", R.drawable.flag_basque_big));
        list.add(new FlagData(0, "Bulgarian", R.drawable.flag_bulgarian_big));
        list.add(new FlagData(0, "Catalan", R.drawable.flag_catalan_big));
        list.add(new FlagData(0, "Chinese (Simplified)", R.drawable.flag_chinas_big));
        list.add(new FlagData(0, "Chinese (Traditional)", R.drawable.flag_chinat_big));
        list.add(new FlagData(0, "Croatian", R.drawable.flag_croatian_big));
        list.add(new FlagData(0, "Czech", R.drawable.flag_czech_big));
        list.add(new FlagData(0, "Danish", R.drawable.flag_danish_big));
        list.add(new FlagData(0, "Dutch", R.drawable.flag_dutch_big));
        list.add(new FlagData(0, "English", R.drawable.flag_us_big));
        list.add(new FlagData(0, "Estonian", R.drawable.flag_estonian_big));
        list.add(new FlagData(0, "Farsi", R.drawable.flag_farsi_big));
        list.add(new FlagData(0, "Filipino", R.drawable.flag_filipino_big));
        list.add(new FlagData(0, "Finnish", R.drawable.flag_finnish_big));
        list.add(new FlagData(0, "French", R.drawable.flag_french_big));
        list.add(new FlagData(0, "German", R.drawable.flag_german_big));
        list.add(new FlagData(0, "Greek", R.drawable.flag_greek_big));
        list.add(new FlagData(0, "Hausa", R.drawable.flag_hausa_big));
        list.add(new FlagData(0, "Hebrew", R.drawable.flag_hebrew_big));
        list.add(new FlagData(0, "Hindi", R.drawable.flag_hindi_big));
        list.add(new FlagData(0, "Hungarian", R.drawable.flag_hungary_big));
        list.add(new FlagData(0, "Icelandic", R.drawable.flag_icelandic_big));
        list.add(new FlagData(0, "Indonesian", R.drawable.flag_indonesian_big));
        list.add(new FlagData(0, "Italian", R.drawable.flag_italic_big));
        list.add(new FlagData(0, "Japanese", R.drawable.flag_japan_big));
        list.add(new FlagData(0, "Korean", R.drawable.flag_korean_big));
        list.add(new FlagData(0, "Latin", R.drawable.flag_latin_big));
        list.add(new FlagData(0, "Latvian", R.drawable.flag_latvian_big));
        list.add(new FlagData(0, "Lithuanian", R.drawable.flag_lithuanian_big));
        list.add(new FlagData(0, "Macedonian", R.drawable.flag_macedonian_big));
        list.add(new FlagData(0, "Malay", R.drawable.flag_malay_big));
        list.add(new FlagData(0, "Mongolian", R.drawable.flag_mongolian_big));
        list.add(new FlagData(0, "Norwegian", R.drawable.flag_norway_big));
        list.add(new FlagData(0, "Pashto", R.drawable.flag_pashto_big));
        list.add(new FlagData(0, "Polish", R.drawable.flag_polish_big));
        list.add(new FlagData(0, "Portuguese", R.drawable.flag_brazil_big));
        list.add(new FlagData(0, "Romanian", R.drawable.flag_romanian_big));
        list.add(new FlagData(0, "Russian", R.drawable.flag_russian_big));
        list.add(new FlagData(0, "Serbian", R.drawable.flag_serbian_big));
        list.add(new FlagData(0, "Slovak", R.drawable.flag_slovak_big));
        list.add(new FlagData(0, "Slovenian", R.drawable.flag_slovanian_big));
        list.add(new FlagData(0, "Spanish", R.drawable.flag_spanish_big));
        list.add(new FlagData(0, "Swedish", R.drawable.flag_swedish_big));
        list.add(new FlagData(0, "Thai", R.drawable.flag_thai_big));
        list.add(new FlagData(0, "Turkish", R.drawable.flag_turkish_big));
        list.add(new FlagData(0, "Ukrainian", R.drawable.flag_ukranian_big));
        list.add(new FlagData(0, "Urdu", R.drawable.flag_urdu_big));
        list.add(new FlagData(0, "Vietnamese", R.drawable.flag_vietnamese_big));
        list.add(new FlagData(0, "Other", R.drawable.flag_other_big));
        this.mSelectedLangs = new ArrayList<>();
        try {
            DataInputStream in = new DataInputStream(ctx.openFileInput("langs"));
            while (true) {
                try {
                    int iIndex = in.readInt();
                    if (iIndex < list.size()) {
                        this.mSelectedLangs.add(Integer.valueOf(iIndex));
                        ((FlagData) list.get(iIndex)).mChecked = 1;
                    }
                } catch (Exception e) {
                    in.close();
                    if (this.mSelectedLangs.size() == 0) {
                        this.mSelectedLangs.add(Integer.valueOf(11));
                        ((FlagData) list.get(11)).mChecked = 1;
                    }
                    return list;
                }
            }
        } catch (Exception e2) {
            return list;
        }
    }
    public FlagList GetFttFlagsList() {
        FlagList list = new FlagList();
        list.add(new FlagData(0, "Arabic", R.drawable.flag_arabic_big));
        list.add(new FlagData(0, "Bengali", R.drawable.flag_bengali_big));
        list.add(new FlagData(0, "Bulgarian", R.drawable.flag_bulgarian_big));
        list.add(new FlagData(0, "Chinese (Simplified)", R.drawable.flag_chinas_big));
        list.add(new FlagData(0, "Chinese (Traditional)", R.drawable.flag_chinat_big));
        list.add(new FlagData(0, "Czech", R.drawable.flag_czech_big));
        list.add(new FlagData(0, "Danish", R.drawable.flag_danish_big));
        list.add(new FlagData(0, "Dari", R.drawable.flag_dari_big));
        list.add(new FlagData(0, "Dutch", R.drawable.flag_dutch_big));
        list.add(new FlagData(0, "English", R.drawable.flag_us_big));
        list.add(new FlagData(0, "Farsi", R.drawable.flag_farsi_big));
        list.add(new FlagData(0, "Finnish", R.drawable.flag_finnish_big));
        list.add(new FlagData(0, "French", R.drawable.flag_french_big));
        list.add(new FlagData(0, "German", R.drawable.flag_german_big));
        list.add(new FlagData(0, "Greek", R.drawable.flag_greek_big));
        list.add(new FlagData(0, "Hebrew", R.drawable.flag_hebrew_big));
        list.add(new FlagData(0, "Hindi", R.drawable.flag_hindi_big));
        list.add(new FlagData(0, "Hungarian", R.drawable.flag_hungary_big));
        list.add(new FlagData(0, "Italian", R.drawable.flag_italic_big));
        list.add(new FlagData(0, "Japanese", R.drawable.flag_japan_big));
        list.add(new FlagData(0, "Korean", R.drawable.flag_korean_big));
        list.add(new FlagData(0, "Norwegian", R.drawable.flag_norway_big));
        list.add(new FlagData(0, "Pashto", R.drawable.flag_pashto_big));
        list.add(new FlagData(0, "Polish", R.drawable.flag_polish_big));
        list.add(new FlagData(0, "Portuguese", R.drawable.flag_brazil_big));
        list.add(new FlagData(0, "Romanian", R.drawable.flag_romanian_big));
        list.add(new FlagData(0, "Russian", R.drawable.flag_russian_big));
        list.add(new FlagData(0, "Serbian", R.drawable.flag_serbian_big));
        list.add(new FlagData(0, "Spanish", R.drawable.flag_spanish_big));
        list.add(new FlagData(0, "Swedish", R.drawable.flag_swedish_big));
        list.add(new FlagData(0, "Thai", R.drawable.flag_thai_big));
        list.add(new FlagData(0, "Turkish", R.drawable.flag_turkish_big));
        list.add(new FlagData(0, "Ukrainian", R.drawable.flag_ukranian_big));
        list.add(new FlagData(0, "Urdu", R.drawable.flag_urdu_big));
        return list;
    }

    public void SaveSelectedLangs(Context ctx, List<Integer> list) {
        try {
            DataOutputStream out = new DataOutputStream(ctx.openFileOutput("langs", 0));
            int length = list.size();
            for (int i = 0; i < length; i++) {
                out.writeInt(((Integer) list.get(i)).intValue());
            }
            out.close();
        } catch (Exception e) {
        }
    }

    public ArrayList<Integer> GetSelectedLangs() {
        return this.mSelectedLangs;
    }

    public String GetLangNumFromISO(String sISO) {
        if (sISO.equals("en")) {
            return "English";
        }
        if (sISO.equals("sq")) {
            return "Albanian";
        }
        if (sISO.equals("ar")) {
            return "Arabic";
        }
        if (sISO.equals("bg")) {
            return "Bulgarian";
        }
        if (sISO.equals("ca")) {
            return "Catalan";
        }
        if (sISO.equals("zh")) {
            return "Chinese (Simplified)";
        }
        if (sISO.equals("cs")) {
            return "Chinese (Traditional)";
        }
        if (sISO.equals("hr")) {
            return "Croatian";
        }
        if (sISO.equals("da")) {
            return "Danish";
        }
        if (sISO.equals("nl")) {
            return "Dutch";
        }
        if (sISO.equals("et")) {
            return "Estonian";
        }
        if (sISO.equals("fa")) {
            return "Farsi";
        }
        if (sISO.equals("fi")) {
            return "Finnish";
        }
        if (sISO.equals("fr")) {
            return "French";
        }
        if (sISO.equals("de")) {
            return "German";
        }
        if (sISO.equals("el")) {
            return "Greek";
        }
        if (sISO.equals("he")) {
            return "Hebrew";
        }
        if (sISO.equals("hi")) {
            return "Hindi";
        }
        if (sISO.equals("hu")) {
            return "Hungarian";
        }
        if (sISO.equals("id")) {
            return "Indonesian";
        }
        if (sISO.equals("is")) {
            return "Icelandic";
        }
        if (sISO.equals("it")) {
            return "Italian";
        }
        if (sISO.equals("ja")) {
            return "Japanese";
        }
        if (sISO.equals("ko")) {
            return "Korean";
        }
        if (sISO.equals("lv")) {
            return "Latvian";
        }
        if (sISO.equals("lt")) {
            return "Lithuanian";
        }
        if (sISO.equals("mk")) {
            return "Macedonian";
        }
        if (sISO.equals("ms")) {
            return "Malay";
        }
        if (sISO.equals("mn")) {
            return "Mongolian";
        }
        if (sISO.equals("no")) {
            return "Norwegian";
        }
        if (sISO.equals("ps")) {
            return "Pashto";
        }
        if (sISO.equals("pl")) {
            return "Polish";
        }
        if (sISO.equals("pt")) {
            return "Portuguese";
        }
        if (sISO.equals("ro")) {
            return "Romanian";
        }
        if (sISO.equals("ru")) {
            return "Russian";
        }
        if (sISO.equals("sr")) {
            return "Serbian";
        }
        if (sISO.equals("sk")) {
            return "Slovak";
        }
        if (sISO.equals("sl")) {
            return "Slovenian";
        }
        if (sISO.equals("es")) {
            return "Spanish";
        }
        if (sISO.equals("sv")) {
            return "Swedish";
        }
        if (sISO.equals("th")) {
            return "Thai";
        }
        if (sISO.equals("tr")) {
            return "Turkish";
        }
        if (sISO.equals("uk")) {
            return "Ukrainian";
        }
        if (sISO.equals("ur")) {
            return "Urdu";
        }
        if (sISO.equals("vi")) {
            return "Vietnamese";
        }
        return null;
    }

    public Locale GetLocaleFromISO(String sISO) {
        if (sISO.equals("en")) {
            return Locale.US;
        }
        if (sISO.equals("ar")) {
            return new Locale("ar_EG");
        }
        if (sISO.equals("bg")) {
            return new Locale("bg_BG");
        }
        if (sISO.startsWith("zh")) {
            return new Locale("zh_CN");
        }
        if (sISO.equals("cs")) {
            return new Locale("cs_CZ");
        }
        if (sISO.equals("da")) {
            return new Locale("da_DK");
        }
        if (sISO.equals("nl")) {
            return new Locale("nl_NL");
        }
        if (sISO.equals("fa")) {
            return new Locale("fa_IR");
        }
        if (sISO.equals("fi")) {
            return new Locale("fi_FI");
        }
        if (sISO.equals("fr")) {
            return new Locale("fr_FR");
        }
        if (sISO.equals("de")) {
            return new Locale("de_DE");
        }
        if (sISO.equals("el")) {
            return new Locale("el_GR");
        }
        if (sISO.equals("he")) {
            return new Locale("he_IL");
        }
        if (sISO.equals("hi")) {
            return new Locale("hi_IN");
        }
        if (sISO.equals("hu")) {
            return new Locale("hu_HU");
        }
        if (sISO.equals("it")) {
            return new Locale("it_IT");
        }
        if (sISO.equals("ja")) {
            return new Locale("ja_JP");
        }
        if (sISO.equals("ko")) {
            return new Locale("ko_KR");
        }
        if (sISO.equals("no")) {
            return new Locale("nb_NO");
        }
        if (sISO.equals("ps")) {
            return new Locale("ps_AF");
        }
        if (sISO.equals("pl")) {
            return new Locale("pl_PL");
        }
        if (sISO.equals("pt")) {
            return new Locale("pt_BR");
        }
        if (sISO.equals("ro")) {
            return new Locale("ro_RO");
        }
        if (sISO.equals("ru")) {
            return new Locale("ru_RU");
        }
        if (sISO.equals("sr")) {
            return new Locale("sr_RS");
        }
        if (sISO.equals("es")) {
            return new Locale("es_ES");
        }
        if (sISO.equals("sv")) {
            return new Locale("sv_SE");
        }
        if (sISO.equals("th")) {
            return new Locale("th_TH");
        }
        if (sISO.equals("tr")) {
            return new Locale("tr_TR");
        }
        if (sISO.equals("uk")) {
            return new Locale("uk_UA");
        }
        if (sISO.equals("ur")) {
            return new Locale("ur_PK");
        }
        Log.v("babylon TextToSpeech", String.format("couldn't find iso language: %s", new Object[]{sISO}));
        return null;
    }

    public String GetSTTLangFromLocale(String sLocale) {
        if (sLocale.equals("en_US")) {
            return "en-US";
        }
        if (sLocale.equals("de_DE") || sLocale.equals("de_AT") || sLocale.equals("de_CH") || sLocale.equals("de_LI")) {
            return "de-DE";
        }
        if (sLocale.equals("zh_CN")) {
            return "cmn-Hans-CN";
        }
        if (sLocale.equals("zh_TW")) {
            return "cmn-Hant-TW";
        }
        if (sLocale.equals("cs_CZ")) {
            return "cs-CZ";
        }
        if (sLocale.equals("es_ES")) {
            return "es-ES";
        }
        if (sLocale.equals("nl_BE") || sLocale.equals("nl_NL")) {
            return "nl-NL";
        }
        if (sLocale.equals("en_AU")) {
            return "en-AU";
        }
        if (sLocale.equals("en_GB")) {
            return "en-GB";
        }
        if (sLocale.equals("en_CA")) {
            return "en-CA";
        }
        if (sLocale.equals("en_NZ")) {
            return "en-NZ";
        }
        if (sLocale.equals("fr_FR") || sLocale.equals("fr_CA") || sLocale.equals("fr_BE") || sLocale.equals("fr_CH")) {
            return "fr-FR";
        }
        if (sLocale.equals("it_IT") || sLocale.equals("it_CH")) {
            return "it-IT";
        }
        if (sLocale.equals("ja_JP")) {
            return "ja-JP";
        }
        if (sLocale.equals("ko_KR")) {
            return "ko-KR";
        }
        if (sLocale.equals("pl_PL")) {
            return "pl-PL";
        }
        if (sLocale.equals("ru_RU")) {
            return "ru-RU";
        }
        if (sLocale.equals("ar_EG")) {
            return "ar-EG";
        }
        if (sLocale.equals("ar_IL")) {
            return "ar-IL";
        }
        if (sLocale.equals("bg_BG")) {
            return "bg-BG";
        }
        if (sLocale.equals("ca_ES")) {
            return "ca-ES";
        }
        if (sLocale.equals("en_IN")) {
            return "en-IN";
        }
        if (sLocale.equals("en_ZA")) {
            return "en-ZA";
        }
        if (sLocale.equals("fi_FI")) {
            return "fi-FI";
        }
        if (sLocale.equals("iw_IL") || sLocale.equals("he_IL")) {
            return "he-IL";
        }
        if (sLocale.equals("hu_HU")) {
            return "hu-HU";
        }
        if (sLocale.equals("nb_NO")) {
            return "nb-NO";
        }
        if (sLocale.equals("pt_BR")) {
            return "pt-BR";
        }
        if (sLocale.equals("pt_PT")) {
            return "pt-PT";
        }
        if (sLocale.equals("ro_RO")) {
            return "ro-RO";
        }
        if (sLocale.equals("sr_RS")) {
            return "sr-RS";
        }
        if (sLocale.equals("es_US")) {
            return "es-US";
        }
        if (sLocale.equals("sv_SE")) {
            return "sv-SE";
        }
        if (sLocale.equals("tr_TR")) {
            return "tr-TR";
        }
        if (sLocale.equals("uk_UA")) {
            return "uk-UA";
        }
        return "en-US";
    }

    public String GetLangNumFromIP(String sISO) {
        if (sISO.equals("ES") || sISO.equals("AR") || sISO.equals("CO") || sISO.equals("CL") || sISO.equals("CR") || sISO.equals("MX") || sISO.equals("PY") || sISO.equals("PE") || sISO.equals("UY") || sISO.equals("VE") || sISO.equals("GT") || sISO.equals("EC") || sISO.equals("PA") || sISO.equals("PR") || sISO.equals("NI")) {
            return "Spanish";
        }
        if (sISO.equals("DZ") || sISO.equals("EG") || sISO.equals("IQ") || sISO.equals("JO") || sISO.equals("KW") || sISO.equals("LB") || sISO.equals("MA") || sISO.equals("QA") || sISO.equals("SA") || sISO.equals("SD") || sISO.equals("AE")) {
            return "Arabic";
        }
        if (sISO.equals("BG")) {
            return "Bulgarian";
        }
        if (sISO.equals("CN") || sISO.equals("HK")) {
            return "Chinese (Simplified)";
        }
        if (sISO.equals("CZ")) {
            return "Czech";
        }
        if (sISO.equals("DK")) {
            return "Danish";
        }
        if (sISO.equals("NL") || sISO.equals("AN")) {
            return "Dutch";
        }
        if (sISO.equals("IR")) {
            return "Farsi";
        }
        if (sISO.equals("FI")) {
            return "Finnish";
        }
        if (sISO.equals("FR") || sISO.equals("CA") || sISO.equals("LU")) {
            return "French";
        }
        if (sISO.equals("DE") || sISO.equals("AT") || sISO.equals("CH")) {
            return "German";
        }
        if (sISO.equals("GR")) {
            return "Greek";
        }
        if (sISO.equals("IL")) {
            return "Hebrew";
        }
        if (sISO.equals("IN")) {
            return "Hindi";
        }
        if (sISO.equals("HU")) {
            return "Hungarian";
        }
        if (sISO.equals("IT")) {
            return "Italian";
        }
        if (sISO.equals("JP")) {
            return "Japanese";
        }
        if (sISO.equals("KR") || sISO.equals("KP")) {
            return "Korean";
        }
        if (sISO.equals("NO")) {
            return "Norwegian";
        }
        if (sISO.equals("AF")) {
            return "Pashto";
        }
        if (sISO.equals("PL")) {
            return "Polish";
        }
        if (sISO.equals("BR") || sISO.equals("PT") || sISO.equals("AO")) {
            return "Portuguese";
        }
        if (sISO.equals("RO")) {
            return "Romanian";
        }
        if (sISO.equals("RU") || sISO.equals("BY") || sISO.equals("KZ")) {
            return "Russian";
        }
        if (sISO.equals("RS")) {
            return "Serbian";
        }
        if (sISO.equals("SE")) {
            return "Swedish";
        }
        if (sISO.equals("TH")) {
            return "Thai";
        }
        if (sISO.equals("TR")) {
            return "Turkish";
        }
        if (sISO.equals("UA")) {
            return "Ukrainian";
        }
        if (sISO.equals("PK")) {
            return "Urdu";
        }
        if (sISO.equals("AL")) {
            return "Albanian";
        }
        if (sISO.equals("HR")) {
            return "Croatian";
        }
        if (sISO.equals("EE")) {
            return "Estonian";
        }
        if (sISO.equals("IS")) {
            return "Icelandic";
        }
        if (sISO.equals("ID")) {
            return "Indonesian";
        }
        if (sISO.equals("LV")) {
            return "Latvian";
        }
        if (sISO.equals("LT")) {
            return "Lithuanian";
        }
        if (sISO.equals("MK")) {
            return "Macedonian";
        }
        if (sISO.equals("SK")) {
            return "Slovak";
        }
        if (sISO.equals("SL")) {
            return "Slovenian";
        }
        if (sISO.equals("MN")) {
            return "Mongolian";
        }
        return null;
    }
}
