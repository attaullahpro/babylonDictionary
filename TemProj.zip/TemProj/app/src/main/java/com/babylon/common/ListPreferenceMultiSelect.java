package com.babylon.common;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.preference.ListPreference;
import android.util.AttributeSet;
import android.widget.ListView;

import com.babylon.translator.R;
import com.newrelic.agent.android.instrumentation.Trace;

import java.util.ArrayList;
import java.util.Iterator;

public class ListPreferenceMultiSelect extends ListPreference {
    private static final String DEFAULT_SEPARATOR = ",";
    private String checkAllKey;
    public boolean[] mClickedDialogEntryIndices;
    private Context mContext;
    private BabLangs mLangs;
    private ArrayList<Integer> mSelectedLangs;
    private String separator;

    public ListPreferenceMultiSelect(Context context, AttributeSet attrs) {
        super(context, attrs);
        int i = 0;
        this.checkAllKey = null;
        this.mContext = context;
//        TypedArray a = context.obtainStyledAttributes(context, attrs,  R.styleable.ListPreferenceMultiSelect);
//        this.checkAllKey = a.getString(0);
//        String s = a.getString(1);
//        if (s != null) {
//            this.separator = s;
//        } else {
            this.separator = DEFAULT_SEPARATOR;
//        }
        CharSequence[] entries = getEntries();
        if (entries != null) {
            i = entries.length;
        }
        this.mClickedDialogEntryIndices = new boolean[i];
        this.mLangs = new BabLangs();
        this.mLangs.GetFlagsList(context);
        this.mSelectedLangs = this.mLangs.GetSelectedLangs();
//        a.recycle();
    }

    public void setEntries(CharSequence[] entries) {
        super.setEntries(entries);
        this.mClickedDialogEntryIndices = new boolean[entries.length];
    }

    public ListPreferenceMultiSelect(Context context) {
        this(context, null);
    }

    /* access modifiers changed from: protected */
    public void onPrepareDialogBuilder(Builder builder) {
        CharSequence[] entries = getEntries();
        CharSequence[] entryValues = getEntryValues();
        if (entries == null || entryValues == null || entries.length != entryValues.length) {
            throw new IllegalStateException("ListPreference requires an entries array and an entryValues array which are both the same length");
        }
        restoreCheckedEntries();
        builder.setMultiChoiceItems(entries, this.mClickedDialogEntryIndices, new DialogInterface.OnMultiChoiceClickListener() {
            public void onClick(DialogInterface dialog, int which, boolean val) {
                if (ListPreferenceMultiSelect.this.isCheckAllValue(which)) {
                    ListPreferenceMultiSelect.this.checkAll(dialog, val);
                }
                ListPreferenceMultiSelect.this.mClickedDialogEntryIndices[which] = val;
            }
        });
    }

    /* access modifiers changed from: private */
    public boolean isCheckAllValue(int which) {
        CharSequence[] entryValues = getEntryValues();
        if (this.checkAllKey != null) {
            return entryValues[which].equals(this.checkAllKey);
        }
        return false;
    }

    /* access modifiers changed from: private */
    public void checkAll(DialogInterface dialog, boolean val) {
        ListView lv = ((AlertDialog) dialog).getListView();
        int size = lv.getCount();
        for (int i = 0; i < size; i++) {
            lv.setItemChecked(i, val);
            this.mClickedDialogEntryIndices[i] = val;
        }
    }

    public String[] parseStoredValue(CharSequence val) {
        if (Trace.NULL.equals(val)) {
            return null;
        }
        return ((String) val).split(this.separator);
    }

    private void restoreCheckedEntries() {
        int iSize = this.mSelectedLangs.size();
        for (int i = 0; i < iSize; i++) {
            this.mClickedDialogEntryIndices[((Integer) this.mSelectedLangs.get(i)).intValue()] = true;
        }
    }

    /* access modifiers changed from: protected */
    public void onDialogClosed(boolean positiveResult) {
        ArrayList<String> values = new ArrayList<>();
        CharSequence[] entryValues = getEntryValues();
        if (positiveResult && entryValues != null) {
            for (int i = 0; i < entryValues.length; i++) {
                if (this.mClickedDialogEntryIndices[i]) {
                    String val = (String) entryValues[i];
                    if (this.checkAllKey == null || !val.equals(this.checkAllKey)) {
                        values.add(val);
                    }
                }
            }
            if (callChangeListener(values)) {
                setValue(join(values, this.separator));
            }
        }
        this.mSelectedLangs.clear();
        for (int i2 = 0; i2 < this.mClickedDialogEntryIndices.length; i2++) {
            if (this.mClickedDialogEntryIndices[i2]) {
                this.mSelectedLangs.add(Integer.valueOf(i2));
            }
        }
        this.mLangs.SaveSelectedLangs(this.mContext, this.mSelectedLangs);
    }

    protected static String join(Iterable<? extends Object> pColl, String separator2) {
        if (pColl != null) {
            Iterator<? extends Object> oIter = pColl.iterator();
            if (oIter.hasNext()) {
                StringBuilder oBuilder = new StringBuilder(String.valueOf(oIter.next()));
                while (oIter.hasNext()) {
                    oBuilder.append(separator2).append(oIter.next());
                }
                return oBuilder.toString();
            }
        }
        return Trace.NULL;
    }

    public static boolean contains(String straw, String haystack, String separator2) {
        if (separator2 == null) {
            separator2 = DEFAULT_SEPARATOR;
        }
        String[] vals = haystack.split(separator2);
        for (String equals : vals) {
            if (equals.equals(straw)) {
                return true;
            }
        }
        return false;
    }
}
