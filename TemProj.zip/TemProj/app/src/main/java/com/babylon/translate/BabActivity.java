package com.babylon.translate;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.RemoteViews;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.babylon.ads.BabylonAdsProviderInterstitials;
import com.babylon.ads.BabylonAdsProviderInterstitials.enInterstitialsTriggerSource;
import com.babylon.common.BabLangs;
import com.babylon.common.BabLocation;
import com.babylon.common.BabPrefs;
import com.babylon.common.BabUtils;
import com.babylon.common.Constants;
import com.babylon.common.FlagData;
import com.babylon.common.FlagList;
import com.babylon.common.JavaScriptHandler;
import com.babylon.controls.BabViewFlipper;
import com.babylon.controls.CustomEditText;
import com.babylon.controls.CustomEditText.OnSearch;
import com.babylon.controls.NavAdapter;
import com.babylon.controls.NavDrawerItem;
import com.babylon.network.ServerComm;
import com.babylon.network.URLUTF8Encoder;
import com.babylon.offline.DownloadActivity;
import com.babylon.offline.OfflineManager;
import com.babylon.translator.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

@SuppressLint({"NewApi"})
public class BabActivity extends AppCompatActivity {
    public static final String STT_LANG_CHANGED_FLAG = "STTlang.changed";
    public static final BabLangs mLangs = new BabLangs();
    private static final String BABYLON_IP_LOCALE_RESOLVER_SERVICE = "http://utils.babylon.com/country/";
    private static final int CONNECTION_TIMEOUT = 10000;
    private static final int FTT_SPEECH_ACTIVITY = 4;
    private static final int MSG_CANCEL_LOADING = 2;
    private static final int PLUS_TAB_ID = 500;
    private static final int PREF_ACTIVITY = 1;
    private static final int RATE_ACTIVITY = 2;
    private static final int TERM_SPEECH_ACTIVITY = 3;

    public static String TAG = "babylon main activity";
    public static FlagList mFlagList;
    public static FlagList mFttFlagList;
    private static String mBillingPayload;

    public final MsgInnerHandler msgHandler = new MsgInnerHandler(this);
    private final String OLD_TRANSLATOR_PACKAGE_NAME = "com.babylon.translate";

    public ImageView mBtnSwitchLangs;

    public CustomEditText mCustomEditText;

    public DrawerLayout mDrawerLayout;

    public ListView mDrawerList;

    public ProgressDialog mLoadingDlg;

    public BabPrefs mPrefs;

    public Runnable mScrollTask = new Runnable() {
        public void run() {
            ((HorizontalScrollView) BabActivity.this.findViewById(R.id.scrollFlags)).fullScroll(66);
        }
    };

    public Spinner mSpinSrcLang;
    public Spinner mSpinTrgtLang; 
    public WebView mWebResFTT;
    public WebView mWebResult;
    public boolean m_bShowSlot = true;
    public RelativeLayout m_layoutSlot;
    public OfflineManager m_offlineManager;
    private ServerComm comunication = null;
    private int mActionBarHeight = 0;
    private RelativeLayout mBtnFullText;
    private ImageView mBtnOfflineState;
    private ImageView mBtnSpeakFttSource;
    private ImageView mBtnSpeakFttTarget;
    private RelativeLayout mBtnTerm;
    private ImageView mBtnTransFTT;
    private boolean mCheckRate = true;
    private int mCurrentTab = 0;
    private ActionBarDrawerToggle mDrawerToggle;
    private EditText mEditTextFT;
    private boolean mFirstPopulate = true;
    private FlagsAdapter mFlagsAdapter;
    private List<Integer> mListLangs;
    private ListView mListViewFlags;
    private Timer mLoadingTimer;
    private ArrayList<NavDrawerItem> mNavDrawerItems;
    private NotificationManager mNotificationManager;
    private FTFlagsAdapter mSrcFlagsAdapter;
    private boolean mStartLoading = false;
    private FTFlagsAdapter mTargetFlagsAdapter;
    private Toolbar mToolbar;
    private TextView mTvOfflineState;
    private BabViewFlipper mViewFlipper;
    private boolean m_bAdVisible = false;
    private boolean m_bCurrentLangOffline;
    private boolean m_bTermMode = true;
    private ImageView m_imageSlotX;
    private String m_sLastTerm;
    private String m_sLastText;
    private String m_sLastTypedText;
    private String m_sTempSTT;
    private TextView m_tvOffline;

    public static boolean isFttUpgradeCondition(String textToTranslate, int sourceLanguage) {
        if (BabApplication.getPersistentPrefs() == null) {
            BabUtils.initPersistentPrefs();
            return false;
        } else if (textToTranslate == null) {
            return BabApplication.fttCapReached() /*&& !IabHelper.getIsProVersionFtt()*/;
        } else
            return !BabUtils.isOneWord(textToTranslate, sourceLanguage) && BabApplication.fttCapReached() /*&& !IabHelper.getIsProVersionFtt()*/;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        boolean z;
        initMonitoringTools();
        BabUtils.initPersistentPrefs();
        BabApplication.InitDatabase();
        initPrefs();
        this.m_offlineManager = OfflineManager.getInstance();
        InstallOfflineFiles();
        this.mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        this.mCurrentTab = this.mPrefs.getTargetLangTab();
        mFlagList = mLangs.GetFlagsList(this);
        mFttFlagList = mLangs.GetFttFlagsList();
        this.mListLangs = mLangs.GetSelectedLangs();
        z = this.mPrefs.getSlotLastDay() != Calendar.getInstance().get(6);
        this.m_bShowSlot = z;
        this.mNavDrawerItems = new ArrayList<>();
        String[] navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);
        TypedArray navMenuIcons = getResources().obtainTypedArray(R.array.nav_drawer_icons);
        for (int i = 0; i < 7; i++) {
            this.mNavDrawerItems.add(new NavDrawerItem(navMenuTitles[i], navMenuIcons.getResourceId(i, -1)));
        }
        TypedValue tv = new TypedValue();
        if (getTheme().resolveAttribute(R.attr.actionBarSize, tv, true)) {
            this.mActionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        InitControls(this.mPrefs.getFirstRun());
        ParseBundle(getIntent().getExtras());
        startService(new Intent(this, BabylonService.class));
        uninstallOldTranslatorApp();
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(Color.parseColor("#35363E"));
        }
    }

    private void InitNavDrawer() {
        this.mDrawerLayout = findViewById(R.id.drawer_layout);
        this.mToolbar = findViewById(R.id.toolbar);
        this.mDrawerList = findViewById(R.id.left_drawer);
        this.mDrawerList.setAdapter(new NavAdapter(this, this.mNavDrawerItems));
        if (this.mToolbar != null) {
            setSupportActionBar(this.mToolbar);
        }
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this.mDrawerToggle = new ActionBarDrawerToggle(this, this.mDrawerLayout, this.mToolbar, R.string.drawer_open, R.string.drawer_close) {
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                BabActivity.this.supportInvalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                BabActivity.this.supportInvalidateOptionsMenu();
            }
        };
        this.mDrawerLayout.setDrawerListener(this.mDrawerToggle);
        this.mDrawerList.setOnItemClickListener(new SlideMenuClickListener(this, null));
//        if (this.mActionBarHeight > 0) {
//            this.mBtnTerm.setLayoutParams(new  LayoutParams(this.mActionBarHeight * 2, this.mActionBarHeight));
//            this.mBtnFullText.setLayoutParams(new  LayoutParams(this.mActionBarHeight * 2, this.mActionBarHeight));
//        }
    }


    public void displayMenu(int position) {
        switch (position + 1) {
            case 1:
                if (/*!IabHelper.getIsProVersionOffline()*/false) {
                    ShowUpgradeDialog();
                    break;
                } else {
                    startActivity(new Intent(getApplicationContext(), DownloadActivity.class));
                    break;
                }
            case 2:
                startActivity(new Intent(this, HowToActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, FaqActivity.class));
                break;
            case 4:
                ShowUpgradeDialog();
                break;
            case 5:
                OpenRateURL();
                break;
            case 6:
                this.mPrefs.putClearHistory(false);
                loadSTTLangFromPrefs();
                startActivityForResult(new Intent(this, BabPrefActivity.class), 1);
                break;
            case 7:
                startActivity(new Intent(this, AboutActivity.class));
                break;
        }
        this.mDrawerLayout.closeDrawer(this.mDrawerList);
    }

    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(this.mDrawerList)) {
            this.mDrawerLayout.closeDrawer(this.mDrawerList);
        } else {
            finish();
        }
    }

    private void initMonitoringTools() {
//        BugSenseHandler.initAndStartSession(this, "c19e824d");
    }

    private void initPrefs() {
        this.mPrefs = BabApplication.getPrefs();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != 82) {
            return super.onKeyDown(keyCode, event);
        }
        if (!this.mDrawerLayout.isDrawerOpen(this.mDrawerList)) {
            this.mDrawerLayout.openDrawer(this.mDrawerList);
        } else if (this.mDrawerLayout.isDrawerOpen(this.mDrawerList)) {
            this.mDrawerLayout.closeDrawer(this.mDrawerList);
        }
        return true;
    }

    public void purchaseInApp(String sku, Activity act, String Source) {
        mBillingPayload = UUID.randomUUID().toString();
        mBillingPayload += Source;
        Log.v(TAG, "purchase payload: " + mBillingPayload);
        try {
//            if (BabApplication.getBillingHelper() != null) {
//                BabApplication.getBillingHelper().flagEndAsync();
//                BabApplication.getBillingHelper().launchPurchaseFlow(act, sku, 10001, this.mPurchaseFinishedListener, mBillingPayload);
//                return;
//            }
            Toast.makeText(act, R.string.user_billing_purchase_not_available, Toast.LENGTH_LONG).show();
//            BugSenseHandler.sendEvent(new StringBuilder(String.valueOf(sku)).append(" purchaseInApp() - billing helper not initiated. display toast to user, re-initiating it").toString());
//            BabApplication.initBillingService();
        } catch (IllegalStateException ex) {
            Toast.makeText(act, R.string.user_billing_purchase_not_available, Toast.LENGTH_LONG).show();
//            BugSenseHandler.sendEvent("purchaseInApp() exception: " + ex.getMessage());
        }
    }

    private void uninstallOldTranslatorApp() {
        if (packageExists("com.babylon.translate")) {
            Builder alertDialogBuilder = new Builder(this);
            alertDialogBuilder.setTitle(R.string.bab_uninstall_old_translator_title);
            alertDialogBuilder.setMessage(R.string.bab_uninstall_old_translator).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Intent intent = null;
                    try {
                        intent = new Intent("android.intent.action.DELETE", Uri.fromParts("package", BabActivity.this.getPackageManager().getPackageInfo("com.babylon.translate", 0).packageName, null));
                    } catch (NameNotFoundException e) {
                        e.printStackTrace();
                    }
                    BabActivity.this.startActivity(intent);
                }
            });
            alertDialogBuilder.create().show();
        }
    }

    private boolean packageExists(String targetPackage) {
        try {
            for (ApplicationInfo packageInfo : getPackageManager().getInstalledApplications(0)) {
                if (packageInfo.packageName.equals(targetPackage)) {
                    return true;
                }
            }
            return false;
        } catch (RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void ParseBundle(Bundle extras) {
        if (extras != null) {
            String data = extras.getString(getString(R.string.data_param));
            if (BabUtils.isOneWord(data, this.mPrefs.getSourceFTTLang())) {
                 new BabylonAdsProviderInterstitials(this, enInterstitialsTriggerSource.openAppFromTermNotification).evaluate(this);
            } else if (BabApplication.fttCapReached() && /* !IabHelper.getIsProVersionFtt()*/ false) {
                ShowUpgradeDialog();
                Log.v(TAG, "Redirect to purchase from notification");
             }
            if (data == null) {
                return;
            }
            if (data.equals(getString(R.string.empty_param))) {
                ChangeTransMode(true);
                this.mCustomEditText.requestFocus();
                ShowKeyboard(true, true);
                return;
            }
            InitText(data, true, false);
            return;
        }
        ChangeTransMode(true);
    }

    @JavascriptInterface
    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void InitWebViews() {
        this.mWebResult = findViewById(R.id.webResult);
        this.mWebResult.clearCache(true);
        WebSettings settings = this.mWebResult.getSettings();
        settings.setJavaScriptEnabled(true);
        this.mWebResult.addJavascriptInterface(new JavaScriptHandler(this), "FTTWebViewJSHandler");
//        this.mTTSTerm = new TextToSpeechController(this, this.mWebResult, null, mLangs);
        settings.setAppCacheMaxSize(1048576);
        settings.setAppCachePath(getApplicationContext().getCacheDir().getAbsolutePath());
        settings.setAllowFileAccess(true);
        settings.setAppCacheEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        this.mWebResult.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                BabActivity.this.FinishLoading();
            }

            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    BabActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                } catch (Exception e) {
                }
                return true;
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                BabActivity.this.mWebResult.loadUrl("file:///android_asset/errorpage.html");
            }
        });
        this.mWebResult.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        this.mWebResFTT = findViewById(R.id.webViewResFTT);
        this.mWebResFTT.clearCache(true);

        WebSettings settings2 = this.mWebResFTT.getSettings();
        settings2.setJavaScriptEnabled(true);
        settings2.setAppCacheEnabled(true);
        this.mWebResFTT.addJavascriptInterface(new JavaScriptHandler(this), "FTTWebViewJSHandler");
        settings2.setAppCacheMaxSize(1048576);
        settings2.setAppCachePath(getApplicationContext().getCacheDir().getAbsolutePath());
        settings2.setAllowFileAccess(true);
        settings2.setAppCacheEnabled(true);
        settings2.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        this.mWebResFTT.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                BabActivity.this.FinishLoading();
                BabActivity.this.mWebResFTT.loadUrl("javascript:window.textToSpeechJSHandler.showText(document.getElementsByTagName('html')[0].innerText);");
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                BabActivity.this.mWebResFTT.loadUrl("file:///android_asset/errorpage.html");
            }
        });
    }

    private void InitFTTLangs() {
        PopulateFTTLangs();
    }

    public void purchaseFTTRequestFromUpgradeBanner() {
        Log.v(TAG, "Redirect to purchase from app");
        ShowUpgradeDialog();
    }


    public void InitTabControl() {
        LinearLayout ll = findViewById(R.id.layoutFlags);
        ll.removeAllViews();
        int iSize = this.mListLangs.size();
        int iMaxLangs = mFlagList.size();
        int i = 0;
        while (i <= iSize && i <= iMaxLangs) {
            RelativeLayout relativeLayout = new RelativeLayout(this);
            relativeLayout.setPadding(0, 5, 0, 0);
            ImageView viewFlag = new ImageView(this);
            if (i == iSize) {
                viewFlag.setImageResource(R.drawable.plus_btn_normal);
                viewFlag.setId(500);
            } else {
                viewFlag.setImageResource(mFlagList.get(this.mListLangs.get(i).intValue()).mImgFlagId);
            }
//            RelativeLayout.LayoutParams flagParams = new RelativeLayout.LayoutParams(-2, -2);
//            flagParams.addRule(13);
//            viewFlag.setAdjustViewBounds(true);
//            viewFlag.setLayoutParams(flagParams);
            relativeLayout.addView(viewFlag);
            relativeLayout.setTag(Integer.valueOf(i));
            relativeLayout.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    BabActivity.this.OnFlag((Integer) v.getTag());
                }
            });
            ll.addView(relativeLayout);
            i++;
        }
        OnFlag(Integer.valueOf(this.mCurrentTab));
    }

    private void InitListViewFlags() {
        this.mFlagsAdapter = new FlagsAdapter(this, R.layout.flag_row, mFlagList);
        this.mListViewFlags.setAdapter(this.mFlagsAdapter);
    }

    /* access modifiers changed from: 0000 */
    public void OnFlag(Integer i) {
        if (this.mCurrentTab > this.mListLangs.size() || this.mCurrentTab < 0) {
            this.mCurrentTab = 0;
        }
        if (i.intValue() > this.mListLangs.size() || i.intValue() < 0) {
            i = Integer.valueOf(11);
        }
        LinearLayout ll = findViewById(R.id.layoutFlags);
        View currentFlag = ll.getChildAt(this.mCurrentTab);
        if (currentFlag != null) {
            currentFlag.setBackgroundColor(0);
        }
        View selectedFlag = ll.getChildAt(i.intValue());
        if (selectedFlag != null && i.intValue() < this.mListLangs.size()) {
            selectedFlag.setBackgroundColor(-1);
        }
        View layoutFlags = findViewById(R.id.layoutFlagList);
        ImageView imagePlus = findViewById(500);
        this.mCurrentTab = i.intValue();
        if (i.intValue() == this.mListLangs.size()) {
            this.mWebResult.setVisibility(View.INVISIBLE);
            imagePlus.setImageResource(R.drawable.plus_btn_high);
            if (layoutFlags != null) {
                layoutFlags.setVisibility(View.VISIBLE);
            }
            this.m_layoutSlot.setVisibility(View.GONE);
            UpdateOfflineVisibile(false);
            this.mListViewFlags.requestFocus();
            return;
        }
        if (layoutFlags != null) {
            layoutFlags.setVisibility(View.INVISIBLE);
        }
        if (imagePlus != null) {
            imagePlus.setImageResource(R.drawable.plus_btn_normal);
        }
        this.mWebResult.setVisibility(View.VISIBLE);
        ShowKeyboard(false, true);
        this.mWebResult.requestFocus();
        ShowTermTranslation(null);
        this.mPrefs.putTargetLangTab(this.mCurrentTab);
        try {
            String sLang = mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage;
            CustomEditText.SetTargetLang(this.m_offlineManager.isOffline(sLang) ? -1 : mLangs.GetLangNum(sLang).intValue());
        } catch (Exception e) {
            CustomEditText.SetTargetLang(mLangs.GetLangNum("English").intValue());
        }
        SetOfflineStatus();
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        BabUtils.initPersistentPrefs();
        ParseBundle(intent.getExtras());
        super.onNewIntent(intent);
    }

    private void ShowTermTranslation(BabylonAdsProviderInterstitials adProvider) {
        if (this.mCurrentTab == this.mListLangs.size()) {
            OnFlag(Integer.valueOf(this.mCurrentTab - 1));
            return;
        }
        Editable edit = this.mCustomEditText.getText();
        if (edit != null) {
            this.m_sLastTerm = edit.toString().trim();
            if (this.m_sLastTerm == null || this.m_sLastTerm.length() <= 0) {
                this.mWebResult.loadUrl("about:blank");
            } else if (this.m_sLastTerm.equals("9988776655")) {
                Toast.makeText(this, "Debug alert - pro version is consumed", Toast.LENGTH_SHORT).show();
            } else if (this.m_sLastTerm.equals("9988776611")) {
                Toast.makeText(this, "Debug alert - ftt version is consumed", Toast.LENGTH_SHORT).show();
            } else if (this.m_sLastTerm.equals("9988776622")) {
                Toast.makeText(this, "Debug alert - offline version is consumed", Toast.LENGTH_SHORT).show();
            } else if (this.m_sLastTerm.equals("9988776633")) {
                Toast.makeText(this, "Debug alert - ftt+ offline version is consumed", Toast.LENGTH_SHORT).show();
            } else if (this.m_sLastTerm.equals("9988776644")) {
                Toast.makeText(this, "Debug alert - future version is consumed", Toast.LENGTH_SHORT).show();
            } else {
                if (adProvider == null) {
                    adProvider = new BabylonAdsProviderInterstitials(this, enInterstitialsTriggerSource.termTranslation);
                }
                adProvider.evaluate(this);
                String sLang = mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage;
                if (this.m_offlineManager.isOffline(sLang)) {
                    TranslateTermOffline(this.m_sLastTerm, sLang);
                } else {
                    StartLoading();
                    this.mWebResult.loadUrl(URLUTF8Encoder.GetUrl(this.m_sLastTerm, false, -1, mLangs.GetLangNum(sLang).intValue(), true));
                }
                this.mCustomEditText.AddTerm();
                this.mCustomEditText.ClearAdapter();
//                GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_TRANSLATE, AnalyticsConstants.EVENT_TERM_FROM_APP);
            }
        } else {
            this.mWebResult.loadUrl("about:blank");
        }
    }

    public boolean OnAddLang(int iLang, boolean bAdd, boolean bRepaint) {
        Integer intLang = Integer.valueOf(iLang);
        FlagData flag = null;
        if (this.mFlagsAdapter != null) {
            flag = this.mFlagsAdapter.mFlagsList.get(iLang);
        }
        if (bAdd) {
            if (this.mListLangs.indexOf(intLang) != -1) {
                return false;
            }
            this.mListLangs.add(intLang);
            this.mCurrentTab++;
            if (flag != null) {
                flag.mChecked = 1;
            }
        } else if (this.mListLangs.indexOf(intLang) == -1 || this.mListLangs.size() == 1) {
            return false;
        } else {
            int index = this.mListLangs.indexOf(intLang);
            if (index != -1) {
                this.mListLangs.remove(index);
            }
            this.mCurrentTab--;
            if (flag != null) {
                flag.mChecked = 0;
            }
        }
        if (bRepaint) {
            InitTabControl();
            this.msgHandler.postDelayed(this.mScrollTask, 100);
        }
        mLangs.SaveSelectedLangs(this, this.mListLangs);
        this.mPrefs.putTargetLangTab(this.mCurrentTab);
        return true;
    }

    private void InitCustomEditText() {
        this.mCustomEditText = findViewById(R.id.txtsearch);
        this.mCustomEditText.getBackground().setColorFilter(new PorterDuffColorFilter(Color.parseColor("#737373"), Mode.SRC_IN));
        this.mCustomEditText.setDropDownVerticalOffset(2);
        CustomEditText.SetAutoComplete(this.mPrefs.getEnableTermAC());
        this.mCustomEditText.setOnSearchEvent(new OnSearch() {
            public void callback() {
                BabActivity.this.OnTermTranslateEvent();
            }
        });
        this.mCustomEditText.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId != 3) {
                    return false;
                }
                ((BabActivity) v.getContext()).OnTermTranslateEvent();
                return true;
            }
        });
        this.mCustomEditText.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == 0) {
                    switch (keyCode) {
                        case 23:
                        case 66:
                            ((BabActivity) v.getContext()).OnTermTranslateEvent();
                            return true;
                    }
                }
                return false;
            }
        });
        this.mCustomEditText.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
                if (adapter != null) {
                    BabActivity.this.ShowKeyboard(false, true);
                    RelativeLayout layoutItem = (RelativeLayout) view;
                    if (layoutItem != null) {
                        TextView tvList = layoutItem.findViewById(R.id.list_content1);
                        if (tvList != null) {
                            String sTerm = tvList.getText().toString();
                            BabActivity.this.mCustomEditText.mLastTermClicked = sTerm;
                            BabActivity.this.InitText(sTerm, false, false);
                        }
                    }
                }
            }
        });
    }

    private void InitFTTEditText() {
        this.mEditTextFT = findViewById(R.id.editTextFT);

        this.mEditTextFT.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId != 3) {
                    return false;
                }
                ((BabActivity) v.getContext()).OnFTTBtn();
                return true;
            }
        });
        this.mEditTextFT.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == 0) {
                    switch (keyCode) {
                        case 23:
                        case 66:
                            ((BabActivity) v.getContext()).OnFTTBtn();
                            return true;
                    }
                }
                return false;
            }
        });
    }


    public void ShowKeyboard(boolean bShow, boolean bTerm) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) {
            return;
        }
        if (bShow) {
            imm.toggleSoftInput(2, 0);
        } else if (bTerm) {
            imm.hideSoftInputFromWindow(this.mCustomEditText.getWindowToken(), 0);
        } else {
            imm.hideSoftInputFromWindow(this.mEditTextFT.getWindowToken(), 0);
        }
    }

    public void OnTermTranslateEvent() {
        notifyTTSToStop();
        ShowKeyboard(false, true);
        this.mWebResult.requestFocus();
        BabylonAdsProviderInterstitials adProvider = new BabylonAdsProviderInterstitials(this, enInterstitialsTriggerSource.termTranslation);
        ShowTermTranslation(adProvider);
        this.mBtnTerm.requestFocus();
        if (adProvider.wasAdOrUpgradeDisplayed()) {
            setRateToLater();
        } else {
            CheckShowRate();
        }
    }


    public void OnFTTBtn() {
        notifyTTSToStop();
        ShowKeyboard(false, false);
        this.m_sLastText = this.mEditTextFT.getText().toString().trim();
        if (this.m_sLastText.length() > 0) {
            int iSrc = this.mPrefs.getSourceFTTLang();
            int iTarget = this.mPrefs.getTargetFTTLang();
            if (iSrc == iTarget) {
                Toast.makeText(this, "Source and target languages need to be different", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isFttUpgradeCondition(this.m_sLastText, this.mPrefs.getSourceFTTLang())) {
                displayUpgradeBannerInApp();
            } else {
                StartLoading();
                  this.mWebResFTT.loadUrl(URLUTF8Encoder.GetUrl(this.m_sLastText, false, iSrc, iTarget, false));
                if (BabUtils.isOneWord(this.m_sLastText, this.mPrefs.getSourceFTTLang())) {

                } else {
                }
                if (!BabUtils.isOneWord(this.m_sLastText, this.mPrefs.getSourceFTTLang())) {
                    BabApplication.incrementFtt();
                }
            }
            CheckShowRate();
            setTargetTTSLocale();
        }
    }

    private void displayUpgradeBannerInApp() {
        BabUtils.checkFirstFttUpgradeDisplay(this.mPrefs);
        this.mWebResFTT.loadDataWithBaseURL("file:///android_asset/", URLUTF8Encoder.GetFttUpgradeHTMLForApp(), "text/html", "utf-8", null);
        this.mBtnTransFTT.setImageResource(R.drawable.translate_btn_disabled);
//        GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_FTT_CAP_LIMIT_DISPLAYED_IN_APP);
    }


    public void OnTermBtn() {
        ChangeTransMode(true);
    }


    public void OnTextBtn() {
        ChangeTransMode(false);
    }

    private void ChangeTransMode(boolean bTermMode) {
        notifyTTSToStop();
        if (!this.m_bTermMode && bTermMode) {
            new BabylonAdsProviderInterstitials(this, enInterstitialsTriggerSource.changeTextToTermMode).evaluate(this);
        }
        this.m_bTermMode = bTermMode;
        int iOrientation = getResources().getConfiguration().orientation;
        if (bTermMode) {
            this.mBtnTerm.setBackgroundResource(R.drawable.ab_selected);
            this.mBtnFullText.setBackgroundResource(R.drawable.ab_unselected);
            UpdateOfflineVisibile(true);
            this.mViewFlipper.setDisplayedChild(0);
            if (iOrientation == 2) {
                this.mCustomEditText.setVisibility(View.VISIBLE);
            }
            if (this.m_bAdVisible) {
                return;
            }
            return;
        }
        setSourceTTSLocale();
        UpdateOfflineVisibile(false);
        if (isFttUpgradeCondition(null, this.mPrefs.getSourceFTTLang())) {
            displayUpgradeBannerInApp();
        } else {
            this.mBtnTransFTT.setImageResource(R.drawable.translate_btn);
        }
        this.mBtnTerm.setBackgroundResource(R.drawable.ab_unselected);
        this.mBtnFullText.setBackgroundResource(R.drawable.ab_selected);
        this.mViewFlipper.setDisplayedChild(1);
        if (iOrientation == 2) {
            this.mCustomEditText.setVisibility(View.INVISIBLE);
        }
    }

    public void onFirstRun() {
        if (this.comunication == null) {
            this.comunication = new ServerComm();
            this.comunication.sendFirstRunMessage(getPackageName(), this.mPrefs.getReferrer(), this.mPrefs.getUserID());
        }
        new DetectLangsTask(this, null).execute(BABYLON_IP_LOCALE_RESOLVER_SERVICE);
        startActivity(new Intent(this, HowToActivity.class));
        this.mPrefs.putFirstRun(false);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (this.mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                if (this.mPrefs.getClearHistory()) {
                    this.mCustomEditText.ClearHistory();
                }
                boolean sttLangChanged = false;
                if (data != null) {
                    sttLangChanged = data.getBooleanExtra(STT_LANG_CHANGED_FLAG, false);
                    this.mPrefs.putEnableSlider(this.mPrefs.getEnableSlider());
                    this.mPrefs.putEnableCopy(this.mPrefs.getEnableCopy());
                }
                String sTempSTT = this.mPrefs.getSTTLang();
                if (sttLangChanged) {
                    if (sTempSTT.substring(0, 2).equals("cm")) {
                        String sISO = "zh";
                    }
                    this.mSpinSrcLang.setSelection(mFlagList.getLangIndex(mLangs.GetLangNumFromISO(sTempSTT.substring(0, 2))));
                }
                if (resultCode == BabPrefActivity.SHOW_UPGRADE) {
                    ShowUpgradeDialog();
                    return;
                }
                return;
            case 2:
                switch (resultCode) {
                    case 1:
                        this.mPrefs.putRateLimit(-1);
                        this.mCheckRate = false;
                        OpenRateURL();
                        return;
                    case 2:
                        setRateToLater();
                        return;
                    case 3:
                        this.mPrefs.putRateLimit(-1);
                        this.mCheckRate = false;
                        return;
                    default:
                        return;
                }
            case 3:
                this.mCustomEditText.ResetMicrophoneImage();
                if (resultCode == -1) {
                    ArrayList<String> matches = data.getStringArrayListExtra("android.speech.extra.RESULTS");
                    if (matches.size() > 0) {
                        InitText(matches.get(0), false, false);
                        return;
                    }
                    return;
                }
                return;
            case 4:
                if (resultCode == -1) {
                    ArrayList<String> matches2 = data.getStringArrayListExtra("android.speech.extra.RESULTS");
                    if (matches2.size() > 0) {
                        InitText(matches2.get(0), true, false);
                        return;
                    }
                    return;
                }
                return;
            case 10001:
                /*if (BabApplication.getBillingHelper() != null) {
                    BabApplication.getBillingHelper().handleActivityResult(requestCode, resultCode, data);
                    return;
                }*/
                return;
            case 10002:
                if (resultCode == -1 && data != null) {
                    String result = data.getStringExtra("result");
                    if (result != null) {
                        purchaseInApp(result, this, Constants.FTT_PURCHASE_FROM_UPGRADE_BANNER_SOURCE);
                        return;
                    }
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void setRateToLater() {
        if (this.mCheckRate) {
            int iLimit = this.mPrefs.getRateLimit();
            if (iLimit != -1) {
                this.mPrefs.putRateLimit(iLimit * 2);
//                Log.v(BabylonAdsProviderInterstitials.TAG, String.format("Suppress 'Rate us' to later. current counter: %s, New limit: %s", Integer.valueOf(this.mPrefs.getRateCounter()), Integer.valueOf(iLimit)));
            }
        }
    }

    private void loadSTTLangFromPrefs() {
        if (this.m_sTempSTT == null) {
            this.m_sTempSTT = this.mPrefs.getSTTLang();
        }
    }


    public void InitText(String sText, boolean bCheckOneWord, boolean calledDueToConfigurationChange) {
        if (sText == null || sText.length() == 0) {
            ChangeTransMode(this.m_bTermMode);
            return;
        }
        if (bCheckOneWord) {
            ChangeTransMode(BabUtils.isOneWord(sText, this.mPrefs.getSourceFTTLang()));
        }
        if (this.m_bTermMode) {
            this.mCustomEditText.setText(sText);
            ShowTermTranslation(null);
            this.mBtnTerm.requestFocus();
            if (getResources().getConfiguration().orientation == 2) {
                this.mCustomEditText.setVisibility(View.VISIBLE);
            }
        } else {
            this.mEditTextFT.setText(sText);
            StartLoading();
            if (!BabApplication.fttCapReached() || /*IabHelper.getIsProVersionFtt()*/ true) {
                this.mWebResFTT.loadUrl(URLUTF8Encoder.GetUrl(sText, false, this.mPrefs.getSourceFTTLang(), this.mPrefs.getTargetFTTLang(), false));
//                GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_TRANSLATE, AnalyticsConstants.EVENT_TEXT_FROM_APP);
                if (!BabUtils.isOneWord(sText, this.mPrefs.getSourceFTTLang()) && !calledDueToConfigurationChange) {
                    BabApplication.incrementFtt();
                }
                this.mBtnFullText.requestFocus();
            }
            setTargetTTSLocale();
        }
        this.mCustomEditText.invalidate();
    }

    private void StartLoading() {
        this.mStartLoading = true;
        if (this.mLoadingTimer != null) {
            this.mLoadingTimer.cancel();
        }
        this.mLoadingTimer = new Timer();
        this.mLoadingTimer.schedule(new TimerTask() {
            public void run() {
                Message msg = BabActivity.this.msgHandler.obtainMessage();
                msg.what = 2;
                BabActivity.this.msgHandler.sendMessage(msg);
            }
        }, 10000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                BabActivity.this.mLoadingDlg = ProgressDialog.show(BabActivity.this, BabActivity.this.getString(R.string.loading_title), BabActivity.this.getString(R.string.loading_text), true, true);
            }
        }, 400);
    }


    public void FinishLoading() {
        if (this.mLoadingTimer != null) {
            this.mLoadingTimer.cancel();
            this.mLoadingTimer = null;
        }
        this.mStartLoading = false;
        if (this.mLoadingDlg != null) {
            try {
                this.mLoadingDlg.cancel();
            } catch (Exception e) {
            }
        }
    }

    private void PopulateFTTLangs() {
        this.mSpinSrcLang = findViewById(R.id.spinnerFromLang);
        this.mSpinTrgtLang = findViewById(R.id.spinnerToLang);
        this.mSrcFlagsAdapter = new FTFlagsAdapter(this, R.layout.spinner_item_lang, mFttFlagList);
        this.mSpinSrcLang.setAdapter(this.mSrcFlagsAdapter);
        this.mSpinSrcLang.setSelection(mFttFlagList.getLangIndex(mLangs.GetLangFromNum(this.mPrefs.getSourceFTTLang())));
        this.mSpinSrcLang.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ((FTFlagsAdapter) BabActivity.this.mSpinSrcLang.getAdapter()).setSelected(l);
                BabActivity.this.OnSrcLangChanged();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.mTargetFlagsAdapter = new FTFlagsAdapter(this, R.layout.spinner_item_lang, mFttFlagList);
        this.mSpinTrgtLang.setAdapter(this.mTargetFlagsAdapter);
        this.mSpinTrgtLang.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ((FTFlagsAdapter) BabActivity.this.mSpinTrgtLang.getAdapter()).setSelected(l);
                BabActivity.this.OnTargetLangChanged();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }


    public void HandleConnectionTimeout() {
        if (this.mLoadingTimer != null) {
            this.mLoadingTimer.cancel();
            this.mLoadingTimer = null;
        }
        if (this.mStartLoading) {
            this.mStartLoading = false;
            if (this.mLoadingDlg != null) {
                try {
                    this.mLoadingDlg.cancel();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                }
            }
            Toast.makeText(this, "No Connection", Toast.LENGTH_SHORT).show();
        }
    }


    public void OnSrcLangChanged() {
        int iLang = this.mSpinSrcLang.getSelectedItemPosition();
        if (iLang >= this.mSrcFlagsAdapter.mFlagsList.size()) {
            iLang = this.mSrcFlagsAdapter.mFlagsList.getLangIndex("English");
        }
        String strSpinnerLang = this.mSrcFlagsAdapter.mFlagsList.get(iLang).mLanguage;
        if (this.mFirstPopulate) {
            this.mFirstPopulate = false;
            this.mSpinTrgtLang.setSelection(this.mTargetFlagsAdapter.mFlagsList.getLangIndex(mLangs.GetLangFromNum(this.mPrefs.getTargetFTTLang())));
        } else if (iLang == this.mSpinTrgtLang.getSelectedItemPosition()) {
            this.mSpinTrgtLang.setSelection(this.mSrcFlagsAdapter.mFlagsList.getLangIndex(mLangs.GetLangFromNum(this.mPrefs.getSourceFTTLang())));
        }
        this.mPrefs.putSourceFTTLang(mLangs.GetLangNum(strSpinnerLang).intValue());
        setSourceTTSLocale();
    }

    private void setSourceTTSLocale() {
          }


    public void OnTargetLangChanged() {
        int iLang = this.mSpinTrgtLang.getSelectedItemPosition();
        if (iLang > this.mTargetFlagsAdapter.mFlagsList.size()) {
            iLang = this.mTargetFlagsAdapter.mFlagsList.getLangIndex("English");
        }
        String strTargetLang = this.mTargetFlagsAdapter.mFlagsList.get(iLang).mLanguage;
        if (iLang == this.mSpinSrcLang.getSelectedItemPosition()) {
            this.mSpinSrcLang.setSelection(this.mTargetFlagsAdapter.mFlagsList.getLangIndex(mLangs.GetLangFromNum(this.mPrefs.getTargetFTTLang())));
        }
        this.mPrefs.putTargetFTTLang(mLangs.GetLangNum(strTargetLang).intValue());
    }

    private void setTargetTTSLocale() {
        }


    public void OnSwitchLangs() {
        this.mSpinTrgtLang.setSelection(this.mSpinSrcLang.getSelectedItemPosition());
    }

    public void OnClearHistory() {
        this.mCustomEditText.ClearHistory();
    }

    private void ClearTTSObjects() {
//        if (this.mTTSFttSource != null) {
//            this.mTTSFttSource.dispose();
//        }
//        if (this.mTTSFttTarget != null) {
//            this.mTTSFttTarget.dispose();
//        }
//        if (this.mTTSTerm != null) {
//            this.mTTSTerm.dispose();
//        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        this.mPrefs.Commit();
        unbindBillingService();
        ClearTTSObjects();
        this.mWebResult.getSettings().setJavaScriptEnabled(false);
        this.mWebResFTT.getSettings().setJavaScriptEnabled(false);
        super.onDestroy();
    }

    private void unbindBillingService() {
//        if (BabApplication.getBillingHelper() != null) {
//            BabApplication.getBillingHelper().dispose();
//        }
//        BabApplication.setBillingHelper(null);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
//        GoogleAnalyticsAdapter.stopActivity(this);
    }

    public void onStart() {
        super.onStart();
//        GoogleAnalyticsAdapter.startActivity(this);
    }

    private void CheckShowRate() {
        if (this.mCheckRate) {
            int iLimit = this.mPrefs.getRateLimit();
            if (iLimit != -1) {
                int iCounter = this.mPrefs.getRateCounter() + 1;
                if (iCounter >= iLimit) {
                    startActivityForResult(new Intent(this, BabRateActivity.class), 2);
                }
                this.mPrefs.putRateCounter(iCounter);
                return;
            }
            this.mCheckRate = false;
        }
    }

    private void OpenRateURL() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(getResources().getString(R.string.market_url)));
        startActivity(intent);
    }

    public void recordText(boolean bTerm) {
        try {
            Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
            intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
            intent.putExtra("android.speech.extra.PROMPT", "Babylon Voice Recognition");
            intent.putExtra("android.speech.extra.LANGUAGE", this.mPrefs.getSTTLang());
            startActivityForResult(intent, bTerm ? 3 : 4);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://market.android.com/details?id=APP_PACKAGE_NAME")));
        }
    }

    private void ShowDefaultnofitication() {
        if (this.mNotificationManager != null) {
            Notification nt = new Notification(R.drawable.logo_notification, "", System.currentTimeMillis());
            nt.flags |= 32;
            nt.contentView = new RemoteViews(getPackageName(), R.layout.default_notification);
            Intent notificationIntent = new Intent(getApplicationContext(), BabActivity.class);
            notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);//603979776
            nt.contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
            this.mNotificationManager.notify(BabylonService.BABYLON_ID, nt);
        }
    }

    private void CancelDefaultNotification() {
        if (this.mNotificationManager != null && !this.mPrefs.getEnableSlider()) {
            this.mNotificationManager.cancel(BabylonService.BABYLON_ID);
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        CancelDefaultNotification();
        notifyTTSToStop();
        if (this.m_offlineManager == null) {
            this.m_offlineManager = OfflineManager.getInstance();
        }
        if (this.m_offlineManager != null && this.mListLangs.size() > this.mCurrentTab) {
            this.m_bCurrentLangOffline = this.m_offlineManager.isOffline(mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage);
        }
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        ShowDefaultnofitication();
        if (this.m_offlineManager == null) {
            this.m_offlineManager = OfflineManager.getInstance();
        }
        if (this.m_offlineManager != null && this.mListLangs.size() > this.mCurrentTab) {
            SetOfflineStatus();
            if (this.m_bCurrentLangOffline != this.m_offlineManager.isOffline(mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage) && this.m_bTermMode) {
                OnTermTranslateEvent();
            }
        }
        super.onResume();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        String sText;
        FinishLoading();
        if (this.m_bTermMode) {
            sText = this.m_sLastTerm;
            this.m_sLastTypedText = this.mCustomEditText.getText().toString().trim();
        } else {
            sText = this.m_sLastText;
            this.m_sLastTypedText = this.mEditTextFT.getText().toString().trim();
        }
        super.onConfigurationChanged(newConfig);
        setContentView(R.layout.main);
        this.mFirstPopulate = true;
        InitControls(false);
        if (!this.m_bTermMode) {
            this.m_bTermMode = true;
            ChangeTransMode(false);
        }
        InitText(sText, false, true);
        if (this.m_bTermMode) {
            this.mCustomEditText.setText(this.m_sLastTypedText);
        } else {
            this.mEditTextFT.setText(this.m_sLastTypedText);
            if (isFttUpgradeCondition(this.m_sLastTypedText, this.mPrefs.getSourceFTTLang())) {
                displayUpgradeBannerInApp();
            } else {
            }
        }
        notifyOrientationChange();
        this.mDrawerToggle.onConfigurationChanged(newConfig);
    }

    private void notifyOrientationChange() {
        Intent intent = new Intent();
        intent.setAction(Constants.ACTION_ORIENTATION_CHANGE);
        sendBroadcast(intent);
    }

    private void notifyTTSToStop() {
        Intent intent = new Intent();
        intent.setAction(Constants.ACTION_TTS_STOP_EVENT);
        sendBroadcast(intent);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void InitControls(boolean bFirstRun) {
        ClearTTSObjects();
        this.mBtnSpeakFttTarget = findViewById(R.id.btnSpeakFttTarget);
        this.mBtnSpeakFttSource = findViewById(R.id.btnSpeakFttSource);
        InitWebViews();
        this.mViewFlipper = findViewById(R.id.viewFlipper);
        this.mListViewFlags = findViewById(R.id.listviewFlags);
        InitCustomEditText();
        findViewById(R.id.scrollFlags).setHorizontalScrollBarEnabled(false);
        InitFTTLangs();
        this.mBtnTerm = findViewById(R.id.imageTerm);
        this.mBtnTerm.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (BabActivity.this.mDrawerLayout.isDrawerOpen(BabActivity.this.mDrawerList)) {
                    BabActivity.this.mDrawerLayout.closeDrawer(BabActivity.this.mDrawerList);
                }
                BabActivity.this.OnTermBtn();
            }
        });
        this.mBtnFullText = findViewById(R.id.imageText);
        this.mBtnFullText.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (BabActivity.this.mDrawerLayout.isDrawerOpen(BabActivity.this.mDrawerList)) {
                    BabActivity.this.mDrawerLayout.closeDrawer(BabActivity.this.mDrawerList);
                }
                BabActivity.this.OnTextBtn();
            }
        });
        this.m_tvOffline = findViewById(R.id.textOffline);
        this.m_layoutSlot = findViewById(R.id.layoutSlot);
        this.m_imageSlotX = findViewById(R.id.closeSlot);
        this.mBtnTransFTT = findViewById(R.id.btnTransFTT);
        this.mBtnTransFTT.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabActivity.this.OnFTTBtn();
            }
        });
        this.mBtnSwitchLangs = findViewById(R.id.switchLangs);
        this.mBtnSwitchLangs.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        BabActivity.this.mBtnSwitchLangs.setImageResource(R.drawable.change_lang_selected);
                        break;
                    case 1:
                        BabActivity.this.mBtnSwitchLangs.setImageResource(R.drawable.change_lang);
                        break;
                }
                BabActivity.this.mBtnSwitchLangs.invalidate();
                return false;
            }
        });
        this.mBtnSwitchLangs.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabActivity.this.OnSwitchLangs();
            }
        });
        this.mBtnOfflineState = findViewById(R.id.onlinestate);
        this.mBtnOfflineState.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabActivity.this.OnSwitchOffline();
            }
        });
        this.mTvOfflineState = findViewById(R.id.onlinestatetext);
        this.mTvOfflineState.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabActivity.this.OnSwitchOffline();
            }
        });
        if (bFirstRun) {
            onFirstRun();
        } else {
            CheckUpgrade();
            InitTabControl();
        }
        InitListViewFlags();
        InitFTTEditText();
        InitNavDrawer();
    }

    private void CheckUpgrade() {
        try {
            int iCurrentCode = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_META_DATA).versionCode;
            int iLastVersion = this.mPrefs.getLastVersionCode();
            if (iLastVersion < iCurrentCode) {
                if (iLastVersion < 54) {
                    this.mCurrentTab = 0;
                    this.mListLangs.clear();
                    mLangs.SaveSelectedLangs(this, this.mListLangs);
                    this.mPrefs.RemoveLangsKeys();
                    this.mPrefs.putSourceFTTLang(0);
                    mFlagList = mLangs.GetFlagsList(this);
                    this.mListLangs = mLangs.GetSelectedLangs();
                    InitFTTLangs();
                    new DetectLangsTask(this, null).execute(BABYLON_IP_LOCALE_RESOLVER_SERVICE);
                }
                this.mPrefs.putLastVersionCode(iCurrentCode);
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: protected */
    public void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        this.mDrawerToggle.syncState();
    }

    public void openOptionsMenu() {
        Configuration config = getResources().getConfiguration();
        if ((config.screenLayout & 15) > 3) {
            int originalScreenLayout = config.screenLayout;
            config.screenLayout = 3;
            super.openOptionsMenu();
            config.screenLayout = originalScreenLayout;
            return;
        }
        super.openOptionsMenu();
    }

    public void SetOfflineStatus() {
        int i;
        this.m_layoutSlot.setVisibility(View.GONE);
        boolean bOfflineLic = false;//IabHelper.getIsProVersionOffline();
        if (!bOfflineLic && this.m_bShowSlot) {
            if (/*IabHelper.getIsProVersionFtt()*/true) {
                i = R.string.offline_slot_pro_no_offline;
            } else {
                i = R.string.offline_slot_freemium;
            }
            String sSlotText = getString(i);
            if (sSlotText.length() > 0) {
                SpannableString content = new SpannableString(sSlotText);
                content.setSpan(new UnderlineSpan(), 0, sSlotText.length(), 0);
                this.m_tvOffline.setText(content);
                this.m_tvOffline.setOnClickListener(new OnClickListener() {
                    public void onClick(View v) {
                        BabActivity.this.ShowUpgradeDialog();
                    }
                });
            }
            this.m_imageSlotX.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    BabActivity.this.m_bShowSlot = false;
                    BabActivity.this.m_layoutSlot.setVisibility(View.GONE);
                    BabActivity.this.mPrefs.putSlotLastDay(Calendar.getInstance().get(6));
                }
            });
            this.m_layoutSlot.setVisibility(View.VISIBLE);
        }
        if (this.mListLangs.size() > this.mCurrentTab) {
            String sLang = mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage;
            if (this.m_offlineManager == null || !this.m_offlineManager.IsDictSupported(sLang)) {
                UpdateOfflineVisibile(false);
                return;
            }
            UpdateOfflineVisibile(true);
            if (!bOfflineLic) {
                UpdateOfflineUI(false);
                OnClickListener listener = new OnClickListener() {
                    public void onClick(View v) {
                        BabActivity.this.ShowUpgradeDialog();
                    }
                };
                this.mBtnOfflineState.setOnClickListener(listener);
                this.mTvOfflineState.setOnClickListener(listener);
            } else if (this.m_offlineManager.IsDictInstalled(sLang)) {
                UpdateOfflineUI(this.m_offlineManager.isOffline(sLang));
                this.mBtnOfflineState.setTag(sLang);
                OnClickListener listener2 = new OnClickListener() {
                    public void onClick(View v) {
                        String sLang = (String) v.getTag();
                        boolean bIsOffline = !BabActivity.this.m_offlineManager.isOffline(sLang);
                        BabActivity.this.m_offlineManager.ChangeOfflineStatus(sLang, bIsOffline);
                        BabActivity.this.UpdateOfflineUI(bIsOffline);
                        CustomEditText.SetTargetLang(bIsOffline ? -1 : BabActivity.mLangs.GetLangNum(sLang).intValue());
                        BabActivity.this.OnTermTranslateEvent();
                    }
                };
                this.mBtnOfflineState.setOnClickListener(listener2);
                this.mTvOfflineState.setOnClickListener(listener2);
            } else {
                UpdateOfflineUI(false);
                OnClickListener listener3 = new OnClickListener() {
                    public void onClick(View v) {
                        BabActivity.this.startActivity(new Intent(BabActivity.this.getApplicationContext(), DownloadActivity.class));
                    }
                };
                this.mBtnOfflineState.setOnClickListener(listener3);
                this.mTvOfflineState.setOnClickListener(listener3);
            }
        }
    }


    public void OnSwitchOffline() {
        if (/*IabHelper.getIsProVersionOffline()*/true) {
            startActivity(new Intent(getApplicationContext(), DownloadActivity.class));
            if (this.mCurrentTab < this.mListLangs.size() && this.mListLangs.get(this.mCurrentTab).intValue() < mFlagList.size()) {
                String sLang = mFlagList.get(this.mListLangs.get(this.mCurrentTab).intValue()).mLanguage;
                boolean bOffline = this.m_offlineManager.isOffline(sLang);
                this.m_offlineManager.ChangeOfflineStatus(sLang, !bOffline);
                this.mBtnOfflineState.setImageResource(this.m_offlineManager.isOffline(sLang) ? R.drawable.offline_state : R.drawable.online_state);
                OnTermTranslateEvent();
                CustomEditText.SetTargetLang(bOffline ? -1 : mLangs.GetLangNum(sLang).intValue());
                return;
            }
            return;
        }
        ShowUpgradeDialog();
    }

    public void ShowUpgradeDialog() {
        runOnUiThread(new Runnable() {
            public void run() {
                new BabylonAdsProviderInterstitials(BabActivity.this, enInterstitialsTriggerSource.termTranslation).showUpgradeNow(BabActivity.this);
            }
        });
    }

    private void InstallOfflineFiles() {
        new Thread() {
            public void run() {
                String[] strArr;
                if (BabActivity.this.m_offlineManager != null && BabActivity.this.m_offlineManager.GetDictsPath() != null) {
                    AssetManager assetManager = BabActivity.this.getAssets();
                    for (String filename : OfflineManager.mOfflineFiles) {
                        try {
                            InputStream in = assetManager.open(filename);
                            File outFile = new File(BabActivity.this.m_offlineManager.GetDictsPath(), filename);
                            if (!outFile.exists()) {
                                FileOutputStream fileOutputStream = new FileOutputStream(outFile);
                                try {
                                    BabActivity.this.copyFile(in, fileOutputStream);
                                    in.close();
                                    fileOutputStream.flush();
                                    fileOutputStream.close();
                                } catch (IOException e) {
                                    FileOutputStream fileOutputStream2 = fileOutputStream;
                                    Log.e("tag", "Failed to copy asset file: " + filename, e);
                                }
                            }
                        } catch (IOException e2) {
                            Log.e("tag", "Failed to copy asset file: " + filename + e2.getMessage());
                        }
                    }
                }
            }
        }.start();
    }


    public void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        while (true) {
            int read = in.read(buffer);
            if (read != -1) {
                out.write(buffer, 0, read);
            } else {
                return;
            }
        }
    }

    private void TranslateTermOffline(String sTerm, String sTargetLang) {
        this.mWebResult.loadDataWithBaseURL("file:///android_asset/", "<link rel=\"stylesheet\" type=\"text/css\" href=\"format.css\" />" + this.m_offlineManager.translateTerm(sTerm, sTargetLang, this, false), "text/html", "UTF-8", null);
        this.mWebResult.requestFocus();
    }


    public void UpdateOfflineUI(boolean bIsOffline) {
        if (this.mBtnOfflineState != null) {
            this.mBtnOfflineState.setImageResource(bIsOffline ? R.drawable.offline_state : R.drawable.online_state);
        }
        if (this.mTvOfflineState != null) {
            this.mTvOfflineState.setText(bIsOffline ? "Offline" : "Online");
        }
    }

    private void UpdateOfflineVisibile(boolean bShow) {
        int i;
        int i2 = 0;
        ImageView imageView = this.mBtnOfflineState;
        if (bShow) {
            i = 0;
        } else {
            i = 8;
        }
        imageView.setVisibility(i);
        TextView textView = this.mTvOfflineState;
        if (!bShow) {
            i2 = 8;
        }
        textView.setVisibility(i2);
    }

    static class MsgInnerHandler extends Handler {
        WeakReference<BabActivity> mBabActivity;

        MsgInnerHandler(BabActivity babActivity) {
            this.mBabActivity = new WeakReference<>(babActivity);
        }

        public void handleMessage(Message message) {
            BabActivity babActivity = this.mBabActivity.get();
            switch (message.what) {
                case 2:
                    babActivity.HandleConnectionTimeout();
                    return;
                default:
                    return;
            }
        }
    }

    private class DetectLangsTask extends AsyncTask<String, Void, String> {
        private DetectLangsTask() {
        }

        /* synthetic */ DetectLangsTask(BabActivity babActivity, DetectLangsTask detectLangsTask) {
            this();
        }

        /* access modifiers changed from: protected */
        public String doInBackground(String... urls) {
            try {
                return BabLocation.GetLocationByUrl(urls[0]);
            } catch (Exception e) {
                return "";
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(String result) {
            Locale mainLocale = Locale.getDefault();
            BabActivity.this.mPrefs.putSTTLang(BabActivity.mLangs.GetSTTLangFromLocale(mainLocale.toString()));
            String sLangLocale = BabActivity.mLangs.GetLangNumFromISO(mainLocale.getLanguage());
            if (sLangLocale != null) {
                int iLang = BabActivity.mFlagList.getLangIndex(sLangLocale);
                if (iLang != -1) {
                    BabActivity.this.OnAddLang(iLang, true, false);
                }
            }
            String sLangIP = null;
            if (!result.equals("")) {
                sLangIP = BabActivity.mLangs.GetLangNumFromIP(result);
                if (!(sLangIP == null || sLangLocale == sLangIP)) {
                    int iLang2 = BabActivity.mFlagList.getLangIndex(sLangIP);
                    if (iLang2 != -1) {
                        BabActivity.this.OnAddLang(iLang2, true, false);
                    }
                }
            }

            int iLangFttTarget = -1;
            if (sLangLocale != "English") {
                iLangFttTarget = BabActivity.mFttFlagList.getLangIndex(sLangLocale);
            } else if (sLangIP != "English") {
                iLangFttTarget = BabActivity.mFttFlagList.getLangIndex(sLangIP);
            }
            if (iLangFttTarget == -1) {
                iLangFttTarget = BabActivity.mFttFlagList.getLangIndex("Spanish");
            }
            BabActivity.this.InitTabControl();
            BabActivity.this.msgHandler.postDelayed(BabActivity.this.mScrollTask, 100);
            BabActivity.this.OnFlag(Integer.valueOf(0));
            if (iLangFttTarget != -1) {
                BabActivity.this.mSpinTrgtLang.setSelection(iLangFttTarget);
                BabActivity.this.OnTargetLangChanged();
            }
        }
    }

    private class SlideMenuClickListener implements OnItemClickListener {
        private SlideMenuClickListener() {
        }

        /* synthetic */ SlideMenuClickListener(BabActivity babActivity, SlideMenuClickListener slideMenuClickListener) {
            this();
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            BabActivity.this.displayMenu(position);
        }
    }
}
