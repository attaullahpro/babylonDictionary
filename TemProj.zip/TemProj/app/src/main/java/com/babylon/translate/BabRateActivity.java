package com.babylon.translate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
//import com.babylon.analytics.GoogleAnalyticsAdapter;
import com.babylon.translator.R;

public class BabRateActivity extends Activity {
    public static final int RATE_LATER = 2;
    public static final int RATE_NEVER = 3;
    public static final int RATE_SHOW = 1;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rate_us);
        ((Button) findViewById(R.id.btnRate1)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabRateActivity.this.setResult(1, new Intent());
                BabRateActivity.this.finish();
            }
        });
        ((Button) findViewById(R.id.btnRate2)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabRateActivity.this.setResult(2, new Intent());
                BabRateActivity.this.finish();
            }
        });
        TextView btnNeverShow = (TextView) findViewById(R.id.btnRate3);
        btnNeverShow.setPaintFlags(btnNeverShow.getPaintFlags() | 8);
        btnNeverShow.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                BabRateActivity.this.setResult(3, new Intent());
                BabRateActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }

    public void onStart() {
        super.onStart();
    }
}
