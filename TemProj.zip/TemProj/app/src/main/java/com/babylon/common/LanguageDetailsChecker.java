package com.babylon.common;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import java.util.List;

public class LanguageDetailsChecker extends BroadcastReceiver {
    private String languagePreference;
    private List<String> supportedLanguages;

    public void onReceive(Context context, Intent intent) {
        Bundle results = getResultExtras(true);
        if (results.containsKey("android.speech.extra.LANGUAGE_PREFERENCE")) {
            this.languagePreference = results.getString("android.speech.extra.LANGUAGE_PREFERENCE");
        }
        if (results.containsKey("android.speech.extra.SUPPORTED_LANGUAGES")) {
            this.supportedLanguages = results.getStringArrayList("android.speech.extra.SUPPORTED_LANGUAGES");
        }
    }
}
