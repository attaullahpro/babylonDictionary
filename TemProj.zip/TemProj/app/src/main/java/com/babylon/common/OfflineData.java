package com.babylon.common;

public class OfflineData {
    public boolean mInstalled;
    public float mSize;
    public String mSource;
    public String mTarget;
    public String mZipFileName;

    public OfflineData(String sSrc, String sTarget, float iSize, String sZip, boolean bInstalled) {
        this.mSource = sSrc;
        this.mTarget = sTarget;
        this.mSize = iSize;
        this.mZipFileName = sZip;
        this.mInstalled = bInstalled;
    }
}
