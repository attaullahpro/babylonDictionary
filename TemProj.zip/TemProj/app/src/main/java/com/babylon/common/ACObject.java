package com.babylon.common;

public class ACObject {
    public String objectName;

    public ACObject(String objectName2) {
        this.objectName = objectName2;
    }
}
