package com.babylon.translate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.babylon.common.FlagData;
import com.babylon.common.FlagList;
import com.babylon.translator.R;

public class FTFlagsAdapter extends ArrayAdapter<FlagData> {
    public FlagList mFlagsList;
    private ImageView mImgViewFlag;
    private LayoutInflater mInflater = ((LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE));
    private long mSelected = -1;
    private TextView mTextviewFlag;

    public FTFlagsAdapter(Context context, int textViewResourceId, FlagList objects) {
        super(context, textViewResourceId, objects);
        this.mFlagsList = objects;
    }

    public int getCount() {
        return this.mFlagsList.size();
    }

    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        View row = this.mInflater.inflate(R.layout.flag_row_fulltext, parent, false);
        FlagData flag = getItem(position);
        this.mTextviewFlag = (TextView) row.findViewById(R.id.textFlag);
        this.mTextviewFlag.setText(flag.mLanguage);
        this.mImgViewFlag = (ImageView) row.findViewById(R.id.imageFlag);
        this.mImgViewFlag.setImageResource(flag.mImgFlagId);
        if (((long) position) == this.mSelected) {
            row.setBackgroundColor(getContext().getResources().getColor(R.color.selectedFlag));
        }
        return row;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        View row = this.mInflater.inflate(R.layout.spinner_selected_lang, parent, false);
        FlagData flag = getItem(position);
        this.mTextviewFlag = (TextView) row.findViewById(R.id.textFlag);
        this.mTextviewFlag.setText(flag.mLanguage);
        this.mImgViewFlag = (ImageView) row.findViewById(R.id.imageFlag);
        this.mImgViewFlag.setImageResource(flag.mImgFlagId);
        return row;
    }

    public FlagData getItem(int index) {
        int size = this.mFlagsList.size();
        if (index < size) {
            return (FlagData) this.mFlagsList.get(index);
        }
        return (FlagData) this.mFlagsList.get(size - 1);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public void setSelected(long iSelected) {
        this.mSelected = iSelected;
    }
}
