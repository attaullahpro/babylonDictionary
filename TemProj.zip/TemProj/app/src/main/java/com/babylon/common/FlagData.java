package com.babylon.common;

import com.newrelic.agent.android.instrumentation.Trace;

public class FlagData {
    public int mChecked;
    public int mImgFlagId;
    public String mLanguage;

    public FlagData() {
        this.mChecked = 0;
        this.mLanguage = new String(Trace.NULL);
        this.mImgFlagId = 0;
    }

    public FlagData(int iChecked, String sLang, int iFlagId) {
        this.mChecked = iChecked;
        this.mLanguage = sLang;
        this.mImgFlagId = iFlagId;
    }
}
