package com.babylon.common;

public class PrefsObject {
    private int mFtt = 0;

    public int getFtt() {
        return this.mFtt;
    }

    public void incrementFtt() {
        this.mFtt++;
    }

    public void setFtt(int count) {
        this.mFtt = count;
    }
}
