﻿$(document).ready(function() {
	  
 var lang_list = $(".term").map(function(){return $(this).attr("srclang")}).get();
 
 $.each(lang_list , function(i, val) { 
 alert(lang_list[i]);
	
	 if (window.textToSpeechJSHandler.checkEvailableVoiceByID(lang_list[i]))
	 {
	  $(img[srclang='en']).css('visibility', 'visible');
	 }
	 else
	 {
	  $('.term').children('.spkr_img').css('visibility', 'hidden');
	 }
	 
	});
 
  
});

/*
 $(document).ready(function() {
	  
 //var lang_list = $(".spkr_img").map(function(){return $(this).attr("srcLang")}).get();
 
 $('.spkr_img').each(function(index, value){
	//alert($(this).attr('srcLang'));
	if (window.textToSpeechJSHandler.checkEvailableVoiceByID($(this).attr('srcLang'))
	 {
	 $(this).css('visibility', 'visible');
	 }
	 else
	 {
	  $(this).css('visibility', 'hidden');
	 }
	
 });
			 
 
});

*/