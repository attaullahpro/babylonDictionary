package com.babylon.translate;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.babylon.translator.R;

public class FaqActivity extends AppCompatActivity {
    private Toolbar _toolbar;
    private WebView mWebview;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.faq);
        this._toolbar = findViewById(R.id.abp__toolbar);
        this.mWebview = findViewById(R.id.webViewFaq);
        this.mWebview.getSettings().setJavaScriptEnabled(true);
        this.mWebview.setWebViewClient(new WebViewClient());
        this.mWebview.loadUrl("http://www.babylon-software.com/mobile/babylon_translator/FAQ");
        this._toolbar.setTitle(getString(R.string.settings_summary6));
        this._toolbar.setNavigationIcon(R.drawable.back);
        this._toolbar.setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FaqActivity.this.finish();
            }
        });
    }
}
