package com.babylon.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.babylon.common.BabPrefs;
import org.codehaus.jackson.util.MinimalPrettyPrinter;

public class UrlReceiver extends BroadcastReceiver {
    ServerComm comunication = new ServerComm();

    public void onReceive(Context context, Intent intent) {
        BabPrefs prefs = new BabPrefs(context);
        String sReferrer = intent.getStringExtra(BabPrefs.REFERRER);
        if (sReferrer == null) {
            sReferrer = MinimalPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
        }
        prefs.putReferrer(sReferrer);
        this.comunication.sendInstallMessage(context.getPackageName(), sReferrer, prefs.getUserID());
    }
}
