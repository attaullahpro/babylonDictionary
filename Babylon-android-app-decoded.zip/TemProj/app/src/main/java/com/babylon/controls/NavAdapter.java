package com.babylon.controls;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.babylon.translator.R;

import java.util.ArrayList;

public class NavAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<NavDrawerItem> navDrawerItems;

    public NavAdapter(Context context2, ArrayList<NavDrawerItem> navDrawerItems2) {
        this.context = context2;
        this.navDrawerItems = navDrawerItems2;
    }

    public int getCount() {
        return this.navDrawerItems.size();
    }

    public Object getItem(int position) {
        return this.navDrawerItems.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.drawer_list_item, null);
        }
        TextView txtName = convertView.findViewById(R.id.navDrawerTextView);
        //((ImageView) convertView.findViewById(R.id.navDrawerImageView)).setImageResource(this.navDrawerItems.get(position).icon);
        txtName.setText(this.navDrawerItems.get(position).name);
        if (position == 1 || position == 5) {
            convertView.findViewById(R.id.list_ac_separator).setVisibility(View.VISIBLE);
        }
        return convertView;
    }
}
