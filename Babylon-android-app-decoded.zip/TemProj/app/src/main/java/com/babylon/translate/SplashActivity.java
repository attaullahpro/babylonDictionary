package com.babylon.translate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.babylon.translator.R;

public class SplashActivity extends Activity {
    private static final String TEXT_PARAM = "text";
    private static final int _splashTime = 1000;
    String _data = null;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.splash);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            this._data = extras.getString(TEXT_PARAM);
        }
        new Handler().postDelayed(new Runnable() {
            public void run() {
                Intent intent = new Intent(SplashActivity.this, BabActivity.class);
                if (SplashActivity.this._data != null) {
                    intent.putExtra(SplashActivity.TEXT_PARAM, SplashActivity.this._data);
                }
                SplashActivity.this.startActivity(intent);
                SplashActivity.this.finish();
            }
        }, 1000);
    }

    public void onStop() {
        super.onStop();
    }

    public void onStart() {
        super.onStart();
    }
}
