package com.babylon.common;

import com.newrelic.agent.android.instrumentation.Trace;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class BabLocation {
    public static String GetLocationByUrl(String url) {
        try {
            HttpParams httpParameters = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpParameters, 3000);
            HttpConnectionParams.setSoTimeout(httpParameters, 5000);
            InputStream in = new DefaultHttpClient(httpParameters).execute(new HttpGet(url)).getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder str = new StringBuilder();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                str.append(line);
            }
            in.close();
            if (str != null) {
                return str.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Trace.NULL;
    }
}
