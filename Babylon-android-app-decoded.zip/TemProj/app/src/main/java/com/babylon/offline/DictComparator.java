package com.babylon.offline;

import com.babylon.common.OfflineData;
import java.util.Comparator;

public class DictComparator implements Comparator<OfflineData> {
    public int compare(OfflineData o1, OfflineData o2) {
        return (o1.mSource + o1.mTarget).compareTo(o2.mSource + o2.mTarget);
    }
}
