package com.babylon.common;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;

public class FlagList extends ArrayList<FlagData> implements Parcelable {
    public static final Creator<FlagList> CREATOR = new Creator<FlagList>() {
        public FlagList createFromParcel(Parcel in) {
            return new FlagList(in);
        }

        public FlagList[] newArray(int arg0) {
            return null;
        }
    };
    public static final String mParcelStr = "flags";
    private static final long serialVersionUID = 611129476549878046L;

    public FlagList() {
    }

    public FlagList(Parcel in) {
        readFromParcel(in);
    }

    private void readFromParcel(Parcel in) {
        clear();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            FlagData flag = new FlagData();
            flag.mChecked = in.readInt();
            flag.mLanguage = in.readString();
            flag.mImgFlagId = in.readInt();
            add(flag);
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        int size = size();
        dest.writeInt(size);
        for (int i = 0; i < size; i++) {
            FlagData flag = (FlagData) get(i);
            dest.writeInt(flag.mChecked);
            dest.writeString(flag.mLanguage);
            dest.writeInt(flag.mImgFlagId);
        }
    }

    public int getLangIndex(String sLang) {
        int size = size();
        for (int i = 0; i < size; i++) {
            if (((FlagData) get(i)).mLanguage.equals(sLang)) {
                return i;
            }
        }
        return -1;
    }
}
