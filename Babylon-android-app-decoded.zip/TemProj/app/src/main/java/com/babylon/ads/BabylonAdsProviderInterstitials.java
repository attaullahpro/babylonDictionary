package com.babylon.ads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build.VERSION;
import android.util.Log;
import com.babylon.common.BabPrefs;
import com.babylon.common.BabUtils;
import com.babylon.controls.BabUpgradeActivity;
import com.babylon.translate.BabApplication;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class BabylonAdsProviderInterstitials extends BabylonAdsProviderBase {
    private static int[] f8xe442c91f = null;
    private static int[] f9x97191681 = null;
    private static final int AD_DISPLAY_LIMIT = 3;
    public static final int BUFFER_BETWEEN_AD_DISPLAY = 2;
    private static final int SHOW_UPGRADE_LIMIT = 8;
    public static String TAG = "Babylon interstitials provider";
    private static final int TERM_TRANSLATION_LIMIT = 1;
    private enInterstitialsTriggerSource mActionSource;
    private Activity mActivity;
    private BabPrefs mPrefs = null;
    private enInterstitialsState mState;
    private boolean mWasAdOrUpgradeDisplayed = false;

    private enum enInterstitialsState {
        begin,
        checkSecondDay,
        termTranslation,
        incrementAdEventsCounter,
        showInterstitialAd,
        showUpgradeBanner,
        end
    }

    public enum enInterstitialsTriggerSource {
        termTranslation,
        changeTextToTermMode,
        openAppFromTermNotification,
        slotTranslation,
        prefActivity,
        settingsUpgrade
    }

    static int[] m12xe442c91f() {
        int[] iArr = f8xe442c91f;
        if (iArr == null) {
            iArr = new int[enInterstitialsState.values().length];
            try {
                iArr[enInterstitialsState.begin.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[enInterstitialsState.checkSecondDay.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[enInterstitialsState.end.ordinal()] = 7;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[enInterstitialsState.incrementAdEventsCounter.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[enInterstitialsState.showInterstitialAd.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[enInterstitialsState.showUpgradeBanner.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr[enInterstitialsState.termTranslation.ordinal()] = 3;
            } catch (NoSuchFieldError e7) {
            }
            f8xe442c91f = iArr;
        }
        return iArr;
    }

    /* renamed from: $SWITCH_TABLE$com$babylon$ads$BabylonAdsProviderInterstitials$enInterstitialsTriggerSource */
    static /* synthetic */ int[] m13x97191681() {
        int[] iArr = f9x97191681;
        if (iArr == null) {
            iArr = new int[enInterstitialsTriggerSource.values().length];
            try {
                iArr[enInterstitialsTriggerSource.changeTextToTermMode.ordinal()] = 2;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[enInterstitialsTriggerSource.openAppFromTermNotification.ordinal()] = 3;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[enInterstitialsTriggerSource.prefActivity.ordinal()] = 5;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[enInterstitialsTriggerSource.settingsUpgrade.ordinal()] = 6;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[enInterstitialsTriggerSource.slotTranslation.ordinal()] = 4;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[enInterstitialsTriggerSource.termTranslation.ordinal()] = 1;
            } catch (NoSuchFieldError e6) {
            }
            f9x97191681 = iArr;
        }
        return iArr;
    }

    public BabylonAdsProviderInterstitials(Activity activity, enInterstitialsTriggerSource source) {
        if (VERSION.SDK_INT > 8) {
            Log.v(TAG, String.format("Interstitial ads initiated from :%s", new Object[]{source}));
            this.mActivity = activity;
            this.mActionSource = source;
            this.mState = enInterstitialsState.begin;
            this.mPrefs = BabApplication.getPrefs();
            preloadAds();
        }
    }

    private void preloadAds() {
        Log.v(TAG, "Preload ads");

    }

    public boolean wasAdOrUpgradeDisplayed() {
        return this.mWasAdOrUpgradeDisplayed;
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"SimpleDateFormat"})
    public boolean nextState(Activity parent) {
        if (VERSION.SDK_INT <= 8) {
            return false;
        }
        boolean continueToNextState = isContinueToNextState();
        switch (m12xe442c91f()[this.mState.ordinal()]) {
            case 1:
                Log.v(TAG, "State: begin");
                beginStateEvaluation();
                return continueToNextState;
            case 2:
                Log.v(TAG, "State: check second day");
                checkSecondDayStateEvaluation();
                return continueToNextState;
            case 3:
                Log.v(TAG, "State: term translation");
                termTranslationStateEvaluation();
                return continueToNextState;
            case 4:
                Log.v(TAG, "State: increment ad event counter");
                incrementAdEventsCounterStateEvaluation();
                return continueToNextState;
            case 5:
                Log.v(TAG, "State: show ad");
                showAdStateEvaluation(false);
                return continueToNextState;
            case 6:
                Log.v(TAG, "State: show upgrade banner");
                showUpgradeStateEvaluation(parent);
                return continueToNextState;
            case 7:
                Log.v(TAG, "State: end");
                return continueToNextState;
            default:
                return continueToNextState;
        }
    }

    private void beginStateEvaluation() {
        if (/*IabHelper.getIsProVersionNoAds()*/true) {
            Log.v(TAG, "Pro version = true");
            this.mState = enInterstitialsState.end;
            return;
        }
        this.mState = enInterstitialsState.checkSecondDay;
    }

    private void checkSecondDayStateEvaluation() {
        if (isSecondDay()) {
            Log.v(TAG, "second day = true");
            if (this.mActionSource == enInterstitialsTriggerSource.termTranslation) {
                this.mState = enInterstitialsState.termTranslation;
            } else {
                this.mState = enInterstitialsState.incrementAdEventsCounter;
            }
        } else {
            Log.v(TAG, "second day = false");
            this.mState = enInterstitialsState.end;
        }
    }

    private void termTranslationStateEvaluation() {
        this.mPrefs.putInterstitialsTranslateCounter(this.mPrefs.getInterstitialsTranslateCounter() + 1);
        if (this.mPrefs.getInterstitialsTranslateCounter() < 1) {
            this.mState = enInterstitialsState.end;
        } else {
            this.mState = enInterstitialsState.incrementAdEventsCounter;
            this.mPrefs.putInterstitialsTranslateCounter(0);
        }
        Log.v(TAG, String.format("translation counter %s of %s", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsTranslateCounter()), Integer.valueOf(1)}));
    }

    private void incrementAdEventsCounterStateEvaluation() {
        this.mPrefs.putInterstitialsAdEventsCounter(this.mPrefs.getInterstitialsAdEventsCounter() + 1);
        Log.v(TAG, String.format("ad events counter = %s", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsAdEventsCounter())}));
        if (this.mPrefs.getInterstitialsAdDisplayCounter() < 3) {
            this.mState = enInterstitialsState.showInterstitialAd;
        } else {
            this.mState = enInterstitialsState.showUpgradeBanner;
        }
    }

    private void showUpgradeStateEvaluation(Activity parent) {
        if (this.mPrefs.getInterstitialsAdEventsCounter() >= 2) {
            Log.v(TAG, String.format("upgrade banner counter %s of %s", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsUpgradeCounter()), Integer.valueOf(8)}));
            this.mPrefs.putInterstitialsAdDisplayCounter(0);
            this.mPrefs.putInterstitialsAdEventsCounter(0);
            showUpgrade(parent);
            return;
        }
        Log.v(TAG, String.format("No upgrade display. reason: too close to last ad display. (events since last ad display=%s, limit=%s)", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsAdEventsCounter()), Integer.valueOf(2)}));
        this.mState = enInterstitialsState.end;
    }

    private void showAdStateEvaluation(boolean forceAdDisplay) {
        if (forceAdDisplay || this.mPrefs.getInterstitialsAdEventsCounter() >= 2) {
            Log.v(TAG, "showing an advertisement ");
            this.mPrefs.putInterstitialsAdEventsCounter(0);
            this.mState = enInterstitialsState.end;
            showAd();
            this.mPrefs.putInterstitialsAdDisplayCounter(this.mPrefs.getInterstitialsAdDisplayCounter() + 1);
            Log.v(TAG, String.format("ad display counter %s of %s", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsAdDisplayCounter()), Integer.valueOf(3)}));
            return;
        }
        Log.v(TAG, String.format("No Ad display. reason: too close to last ad display. (events since last ad display=%s, limit=%s)", new Object[]{Integer.valueOf(this.mPrefs.getInterstitialsAdEventsCounter()), Integer.valueOf(2)}));
        this.mState = enInterstitialsState.end;
    }

    @SuppressLint({"SimpleDateFormat"})
    private void showUpgrade(Activity parent) {
        String today = new SimpleDateFormat("yyyyMMdd").format(new Date(System.currentTimeMillis()));
        Log.v(TAG, String.format("upgrade last display date is: %s", new Object[]{this.mPrefs.getInterstitialsLastUpgradeDisplayDate()}));
        if (this.mPrefs.getInterstitialsLastUpgradeDisplayDate() != null && this.mPrefs.getInterstitialsLastUpgradeDisplayDate().equals(today)) {
            Log.v(TAG, "upgrade banner already displayed today -> show ad instead");
            showAdStateEvaluation(true);
        } else if (this.mPrefs.getInterstitialsUpgradeCounter() < 8) {
            this.mPrefs.putInterstitialsUpgradeCounter(this.mPrefs.getInterstitialsUpgradeCounter() + 1);
            Log.v(TAG, "show upgrade banner");
            showUpgradeNow(parent);
            this.mState = enInterstitialsState.end;
        } else {
            Log.v(TAG, String.format("upgrade banner displayed beyond limit of %s -> show ad instead", new Object[]{Integer.valueOf(8)}));
            showAdStateEvaluation(true);
        }
    }

    public void showUpgradeNow(Activity parent) {
        this.mWasAdOrUpgradeDisplayed = true;
        this.mPrefs.putInterstitialsLastUpgradeDisplayDate(new SimpleDateFormat("yyyyMMdd").format(new Date(System.currentTimeMillis())));
        parent.startActivityForResult(new Intent(BabApplication.getContext(), BabUpgradeActivity.class), 10002);
    }

    private void showAd() {
        BabUtils.checkFirsAdDisplay(this.mPrefs);
        switch (m13x97191681()[this.mActionSource.ordinal()]) {
            case 1:
                  break;
            case 2:
                break;
            case 3:
                 break;
        }
        this.mWasAdOrUpgradeDisplayed = true;
    }

    @SuppressLint({"SimpleDateFormat"})
    private boolean isSecondDay() {
        int today = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(new Date(System.currentTimeMillis())));
        int firstUsageDate = this.mPrefs.getInterstitialsFirstUsageDate();
        Log.v(TAG, String.format("First day of usage is: %s", new Object[]{Integer.valueOf(firstUsageDate)}));
        if (firstUsageDate == 0) {
            this.mPrefs.putInterstitialsFirstUsageDate(today);
            return false;
        } else if (today - firstUsageDate > 0) {
            return true;
        } else {
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean isContinueToNextState() {
        switch (m12xe442c91f()[this.mState.ordinal()]) {
            case 1:
                return true;
            case 2:
                return true;
            case 3:
                return true;
            case 4:
                return true;
            case 5:
                return true;
            case 6:
                return true;
            case 7:
                return false;
            default:
                return true;
        }
    }
}
