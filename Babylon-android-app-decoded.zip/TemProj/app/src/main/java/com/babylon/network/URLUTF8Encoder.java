package com.babylon.network;

import androidx.core.view.MotionEventCompat;

import com.babylon.common.BabUtils;
import java.io.UnsupportedEncodingException;

public class URLUTF8Encoder {
    private static final String ANDROID_APP_QUERY = "&Ci=0&tid=and_app_new0314&lv=";
    private static final String ANDROID_NOTIFY_QUERY = "&Ci=0&tid=and_notif_new&lv=";
    private static final String BASE_URL = "http://bis.babylon.com?rt=inside&query=";
    private static final int[] aIn = {37, 38};
    private static final String[] aOut = {"%25", "%26"};
    private static final int[] crc_table;
    private static final byte[] szBase64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".getBytes();

    static {
        int[] iArr = new int[256];
        iArr[1] = 1996959894;
        iArr[2] = -301047508;
        iArr[3] = -1727442502;
        iArr[4] = 124634137;
        iArr[5] = 1886057615;
        iArr[6] = -379345611;
        iArr[7] = -1637575261;
        iArr[8] = 249268274;
        iArr[9] = 2044508324;
        iArr[10] = -522852066;
        iArr[11] = -1747789432;
        iArr[12] = 162941995;
        iArr[13] = 2125561021;
        iArr[14] = -407360249;
        iArr[15] = -1866523247;
        iArr[16] = 498536548;
        iArr[17] = 1789927666;
        iArr[18] = -205950648;
        iArr[19] = -2067906082;
        iArr[20] = 450548861;
        iArr[21] = 1843258603;
        iArr[22] = -187386543;
        iArr[23] = -2083289657;
        iArr[24] = 325883990;
        iArr[25] = 1684777152;
        iArr[26] = -43845254;
        iArr[27] = -1973040660;
        iArr[28] = 335633487;
        iArr[29] = 1661365465;
        iArr[30] = -99664541;
        iArr[31] = -1928851979;
        iArr[32] = 997073096;
        iArr[33] = 1281953886;
        iArr[34] = -715111964;
        iArr[35] = -1570279054;
        iArr[36] = 1006888145;
        iArr[37] = 1258607687;
        iArr[38] = -770865667;
        iArr[39] = -1526024853;
        iArr[40] = 901097722;
        iArr[41] = 1119000684;
        iArr[42] = -608450090;
        iArr[43] = -1396901568;
        iArr[44] = 853044451;
        iArr[45] = 1172266101;
        iArr[46] = -589951537;
        iArr[47] = -1412350631;
        iArr[48] = 651767980;
        iArr[49] = 1373503546;
        iArr[50] = -925412992;
        iArr[51] = -1076862698;
        iArr[52] = 565507253;
        iArr[53] = 1454621731;
        iArr[54] = -809855591;
        iArr[55] = -1195530993;
        iArr[56] = 671266974;
        iArr[57] = 1594198024;
        iArr[58] = -972236366;
        iArr[59] = -1324619484;
        iArr[60] = 795835527;
        iArr[61] = 1483230225;
        iArr[62] = -1050600021;
        iArr[63] = -1234817731;
        iArr[64] = 1994146192;
        iArr[65] = 31158534;
        iArr[66] = -1731059524;
        iArr[67] = -271249366;
        iArr[68] = 1907459465;
        iArr[69] = 112637215;
        iArr[70] = -1614814043;
        iArr[71] = -390540237;
        iArr[72] = 2013776290;
        iArr[73] = 251722036;
        iArr[74] = -1777751922;
        iArr[75] = -519137256;
        iArr[76] = 2137656763;
        iArr[77] = 141376813;
        iArr[78] = -1855689577;
        iArr[79] = -429695999;
        iArr[80] = 1802195444;
        iArr[81] = 476864866;
        iArr[82] = -2056965928;
        iArr[83] = -228458418;
        iArr[84] = 1812370925;
        iArr[85] = 453092731;
        iArr[86] = -2113342271;
        iArr[87] = -183516073;
        iArr[88] = 1706088902;
        iArr[89] = 314042704;
        iArr[90] = -1950435094;
        iArr[91] = -54949764;
        iArr[92] = 1658658271;
        iArr[93] = 366619977;
        iArr[94] = -1932296973;
        iArr[95] = -69972891;
        iArr[96] = 1303535960;
        iArr[97] = 984961486;
        iArr[98] = -1547960204;
        iArr[99] = -725929758;
        iArr[100] = 1256170817;
        iArr[101] = 1037604311;
        iArr[102] = -1529756563;
        iArr[103] = -740887301;
        iArr[104] = 1131014506;
        iArr[105] = 879679996;
        iArr[106] = -1385723834;
        iArr[107] = -631195440;
        iArr[108] = 1141124467;
        iArr[109] = 855842277;
        iArr[110] = -1442165665;
        iArr[111] = -586318647;
        iArr[112] = 1342533948;
        iArr[113] = 654459306;
        iArr[114] = -1106571248;
        iArr[115] = -921952122;
        iArr[116] = 1466479909;
        iArr[117] = 544179635;
        iArr[118] = -1184443383;
        iArr[119] = -832445281;
        iArr[120] = 1591671054;
        iArr[121] = 702138776;
        iArr[122] = -1328506846;
        iArr[123] = -942167884;
        iArr[124] = 1504918807;
        iArr[125] = 783551873;
        iArr[126] = -1212326853;
        iArr[127] = -1061524307;
        iArr[128] = -306674912;
        iArr[129] = -1698712650;
        iArr[130] = 62317068;
        iArr[131] = 1957810842;
        iArr[132] = -355121351;
        iArr[133] = -1647151185;
        iArr[134] = 81470997;
        iArr[135] = 1943803523;
        iArr[136] = -480048366;
        iArr[137] = -1805370492;
        iArr[138] = 225274430;
        iArr[139] = 2053790376;
        iArr[140] = -468791541;
        iArr[141] = -1828061283;
        iArr[142] = 167816743;
        iArr[143] = 2097651377;
        iArr[144] = -267414716;
        iArr[145] = -2029476910;
        iArr[146] = 503444072;
        iArr[147] = 1762050814;
        iArr[148] = -144550051;
        iArr[149] = -2140837941;
        iArr[150] = 426522225;
        iArr[151] = 1852507879;
        iArr[152] = -19653770;
        iArr[153] = -1982649376;
        iArr[154] = 282753626;
        iArr[155] = 1742555852;
        iArr[156] = -105259153;
        iArr[157] = -1900089351;
        iArr[158] = 397917763;
        iArr[159] = 1622183637;
        iArr[160] = -690576408;
        iArr[161] = -1580100738;
        iArr[162] = 953729732;
        iArr[163] = 1340076626;
        iArr[164] = -776247311;
        iArr[165] = -1497606297;
        iArr[166] = 1068828381;
        iArr[167] = 1219638859;
        iArr[168] = -670225446;
        iArr[169] = -1358292148;
        iArr[170] = 906185462;
        iArr[171] = 1090812512;
        iArr[172] = -547295293;
        iArr[173] = -1469587627;
        iArr[174] = 829329135;
        iArr[175] = 1181335161;
        iArr[176] = -882789492;
        iArr[177] = -1134132454;
        iArr[178] = 628085408;
        iArr[179] = 1382605366;
        iArr[180] = -871598187;
        iArr[181] = -1156888829;
        iArr[182] = 570562233;
        iArr[183] = 1426400815;
        iArr[184] = -977650754;
        iArr[185] = -1296233688;
        iArr[186] = 733239954;
        iArr[187] = 1555261956;
        iArr[188] = -1026031705;
        iArr[189] = -1244606671;
        iArr[190] = 752459403;
        iArr[191] = 1541320221;
        iArr[192] = -1687895376;
        iArr[193] = -328994266;
        iArr[194] = 1969922972;
        iArr[195] = 40735498;
        iArr[196] = -1677130071;
        iArr[197] = -351390145;
        iArr[198] = 1913087877;
        iArr[199] = 83908371;
        iArr[200] = -1782625662;
        iArr[201] = -491226604;
        iArr[202] = 2075208622;
        iArr[203] = 213261112;
        iArr[204] = -1831694693;
        iArr[205] = -438977011;
        iArr[206] = 2094854071;
        iArr[207] = 198958881;
        iArr[208] = -2032938284;
        iArr[209] = -237706686;
        iArr[210] = 1759359992;
        iArr[211] = 534414190;
        iArr[212] = -2118248755;
        iArr[213] = -155638181;
        iArr[214] = 1873836001;
        iArr[215] = 414664567;
        iArr[216] = -2012718362;
        iArr[217] = -15766928;
        iArr[218] = 1711684554;
        iArr[219] = 285281116;
        iArr[220] = -1889165569;
        iArr[221] = -127750551;
        iArr[222] = 1634467795;
        iArr[223] = 376229701;
        iArr[224] = -1609899400;
        iArr[225] = -686959890;
        iArr[226] = 1308918612;
        iArr[227] = 956543938;
        iArr[228] = -1486412191;
        iArr[229] = -799009033;
        iArr[230] = 1231636301;
        iArr[231] = 1047427035;
        iArr[232] = -1362007478;
        iArr[233] = -640263460;
        iArr[234] = 1088359270;
        iArr[235] = 936918000;
        iArr[236] = -1447252397;
        iArr[237] = -558129467;
        iArr[238] = 1202900863;
        iArr[239] = 817233897;
        iArr[240] = -1111625188;
        iArr[241] = -893730166;
        iArr[242] = 1404277552;
        iArr[243] = 615818150;
        iArr[244] = -1160759803;
        iArr[245] = -841546093;
        iArr[246] = 1423857449;
        iArr[247] = 601450431;
        iArr[248] = -1285129682;
        iArr[249] = -1000256840;
        iArr[250] = 1567103746;
        iArr[251] = 711928724;
        iArr[252] = -1274298825;
        iArr[253] = -1022587231;
        iArr[254] = 1510334235;
        iArr[255] = 755167117;
        crc_table = iArr;
    }

    private static byte[] toUTF8(String s, boolean bEsc) {
        if (bEsc) {
            for (int j = 0; j < 2; j++) {
                int iPos = s.indexOf(aIn[j]);
                while (iPos != -1) {
                    s = s.substring(0, iPos) + aOut[j] + s.substring(iPos + 1);
                    iPos = s.indexOf(aIn[j], iPos + 1);
                }
            }
        }
        try {
            return s.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    private static byte[] append(byte[] b1, byte[] b2, byte[] b3) {
        byte[] by = new byte[(b1.length + b2.length + b3.length)];
        System.arraycopy(b1, 0, by, 0, b1.length);
        System.arraycopy(b2, 0, by, b1.length, b2.length);
        System.arraycopy(b3, 0, by, b1.length + b2.length, b3.length);
        return by;
    }

    static String decode(String s) {
        int b;
        int lowerCase;
        int lowerCase2;
        StringBuffer sbuf = new StringBuffer();
        int l = s.length();
        int sumb = 0;
        int i = 0;
        int more = -1;
        while (i < l) {
            int ch = s.charAt(i);
            switch (ch) {
                case 37:
                    int i2 = i + 1;
                    int ch2 = s.charAt(i2);
                    if (Character.isDigit((char) ch2)) {
                        lowerCase = ch2 - 48;
                    } else {
                        lowerCase = (Character.toLowerCase((char) ch2) + 10) - 97;
                    }
                    int hb = lowerCase & 15;
                    i = i2 + 1;
                    int ch3 = s.charAt(i);
                    if (Character.isDigit((char) ch3)) {
                        lowerCase2 = ch3 - 48;
                    } else {
                        lowerCase2 = (Character.toLowerCase((char) ch3) + 10) - 97;
                    }
                    b = (hb << 4) | (lowerCase2 & 15);
                    break;
                case 43:
                    b = 32;
                    break;
                default:
                    b = ch;
                    break;
            }
            if ((b & 192) == 128) {
                sumb = (sumb << 6) | (b & 63);
                more--;
                if (more == 0) {
                    sbuf.append((char) sumb);
                }
            } else if ((b & 128) == 0) {
                sbuf.append((char) b);
            } else if ((b & 224) == 192) {
                sumb = b & 31;
                more = 1;
            } else if ((b & 240) == 224) {
                sumb = b & 15;
                more = 2;
            } else if ((b & 248) == 240) {
                sumb = b & 7;
                more = 3;
            } else if ((b & 252) == 248) {
                sumb = b & 3;
                more = 4;
            } else {
                sumb = b & 1;
                more = 5;
            }
            i++;
        }
        return sbuf.toString();
    }

    private static String encodeBas64(byte[] btIn) {
        int j;
        int iLen = btIn.length;
        byte[] btOrig3 = new byte[3];
        byte[] btBase64 = new byte[4];
        StringBuffer sb = new StringBuffer(((iLen * 4) / 3) + 3);
        int iPad = 0;
        int i = 0;
        int j2 = 0;
        while (true) {
            if (i >= iLen && j2 == 0) {
                return sb.toString();
            }
            if (i < iLen) {
                j = j2 + 1;
                btOrig3[j2] = btIn[i];
            } else {
                j = j2 + 1;
                btOrig3[j2] = 0;
                iPad++;
            }
            if (j == 3) {
                btBase64[0] = (byte) ((btOrig3[0] & 252) >> 2);
                btBase64[1] = (byte) (((btOrig3[0] & 3) << 4) + ((btOrig3[1] & 240) >> 4));
                btBase64[2] = (byte) (((btOrig3[1] & 15) << 2) + ((btOrig3[2] & 192) >> 6));
                btBase64[3] = (byte) (btOrig3[2] & 63);
                for (int j3 = 0; j3 < 4 - iPad; j3++) {
                    sb.append((char) szBase64Chars[btBase64[j3]]);
                }
                for (int j4 = 0; j4 < iPad; j4++) {
                    sb.append('=');
                }
                j = 0;
            }
            i++;
            j2 = j;
        }
    }

    private static int crc32(int crc, byte[] buf) {
        if (buf == null) {
            return 0;
        }
        int crc2 = crc ^ -1;
        for (byte b : buf) {
            crc2 = crc_table[(b ^ crc2) & MotionEventCompat.ACTION_MASK] ^ (crc2 >>> 8);
        }
        return (crc_table[(crc2 ^ 0) & MotionEventCompat.ACTION_MASK] ^ (crc2 >>> 8)) ^ -1;
    }

    public static String GetUrl(String sText, boolean bNotify, int iSrcLang, int iTargetLang, boolean isTermMode) {
        StringBuilder sBaseQuery;
        StringBuilder sb = new StringBuilder(BASE_URL);
        int iCRC = crc32(0, toUTF8(sText, false));
        byte[] byTerm = toUTF8(sText, true);
        if (bNotify) {
            sBaseQuery = new StringBuilder(new StringBuilder(ANDROID_NOTIFY_QUERY).append(iCRC).toString());
        } else {
            sBaseQuery = new StringBuilder(new StringBuilder(ANDROID_APP_QUERY).append(iCRC).toString());
        }
        if (iTargetLang == -1 || BabUtils.isOneWord(sText, iSrcLang) || isTermMode) {
            sBaseQuery.append("&ftt=0&tlngs=" + iTargetLang);
        } else {
            sBaseQuery.append("&ftt=translate&fttl=6000&sftt=" + iSrcLang + "&tftt=" + iTargetLang);
        }
        return sb.append(encodeBas64(append("Line=".getBytes(), byTerm, sBaseQuery.toString().getBytes()))).toString();
    }

    public static String GetFttUpgradeHTMLForApp() {
        return "<body><img src=\"upgrade_ad.png\" onclick=\"window.FTTWebViewJSHandler.purchaseFTT();\" width=\"100%\" height=\"auto\"\"/></body>";
    }
}
