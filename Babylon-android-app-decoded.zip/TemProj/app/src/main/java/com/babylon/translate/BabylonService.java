package com.babylon.translate;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.ClipboardManager;
import android.content.ClipboardManager.OnPrimaryClipChangedListener;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.text.Html;
import android.util.Log;
import android.widget.RemoteViews;

import com.babylon.common.BabLangs;
import com.babylon.common.BabPrefs;
import com.babylon.common.BabUtils;
import com.babylon.common.FlagList;
import com.babylon.network.URLUTF8Encoder;
import com.babylon.offline.OfflineManager;
import com.babylon.translator.R;
import com.newrelic.agent.android.instrumentation.Trace;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.codehaus.jackson.util.MinimalPrettyPrinter;

public class BabylonService extends Service {
    public static final int BABYLON_ID = 24375;
    private static final int ANIM_MAX = 16;
    private static final int CHECK_RUNNING_PROCESS_INTERVAL = 1000;
    private static final long CLEAR_DATA_INTERVAL = 60000;
    private static final int CONNECTION_TIMEOUT = 10000;
    private static final int MSG_ANIMATE = 101;
    private static final int MSG_CLEAR_NOTIFY = 102;
    private static final int MSG_NOTIFY = 100;
    public static String mLastClipboardText;
    public final BabLangs mLangs = new BabLangs();
    public final MsgInnerHandler msgHandler = new MsgInnerHandler(this);
    public String TAG = "babylon service";
    public Context mAppContext;
    public ClipboardManager mClipboardManagerNew;
    public android.text.ClipboardManager mClipboardMgr;
    public Notification mCustomTranslation;
    public NotificationManager mNotificationManager;
    public boolean mOneWord = true;
    public String mPackageName;
    public String mSavedClipBoardTxt;
    public String mTerm;
    public OfflineManager m_offlineManager;
    HttpClient mHttpClient;
    HttpContext mLocalContext;
    BabPrefs mPrefs;
    private Timer mClipBoardCheckTimer;
    private OnPrimaryClipChangedListener mClipboardChangeListener = null;
    private Notification mDataNotification;
    private Notification mDefaultNotification;
    private boolean mEnableCopy = true;
    private boolean mEnableSlider = true;
    private Notification mNotification;
    private boolean mStopped = false;

    @SuppressLint({"NewApi", "ServiceCast"})
    public void onCreate() {
        this.mAppContext = getApplicationContext();
        this.mPackageName = getPackageName();
        this.mPrefs = BabApplication.getPrefs();
        PrepareHttpParams();
        this.mEnableCopy = this.mPrefs.getEnableCopy();
        this.mEnableSlider = this.mPrefs.getEnableSlider();
        this.mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        PrepareNotifications();
        if (this.mEnableSlider) {
            ShowDefaultNotification();
        }
        if (!this.mEnableCopy) {
            return;
        }
        if (VERSION.SDK_INT >= 11) {
            this.mClipboardManagerNew = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            this.mClipboardChangeListener = new OnPrimaryClipChangedListener() {
                public void onPrimaryClipChanged() {
                    ClipData clipData = BabylonService.this.mClipboardManagerNew.getPrimaryClip();
                    if (clipData != null) {
                        Item item = clipData.getItemAt(0);
                        if (item != null && item.getText() != null) {
                            String sText = item.getText().toString().trim();
                            if (!sText.equals(BabylonService.this.mSavedClipBoardTxt)) {
                                BabylonService.this.msgHandler.removeMessages(102);
                                BabylonService.this.mSavedClipBoardTxt = sText;
                                Message msg = BabylonService.this.msgHandler.obtainMessage();
                                msg.what = 100;
                                BabylonService.this.msgHandler.sendMessage(msg);
                                Message msg2 = BabylonService.this.msgHandler.obtainMessage();
                                msg2.what = 102;
                                BabylonService.this.msgHandler.sendMessageDelayed(msg2, BabylonService.CLEAR_DATA_INTERVAL);
                            }
                        }
                    }
                }
            };
            this.mClipboardManagerNew.addPrimaryClipChangedListener(this.mClipboardChangeListener);
            return;
        }
        this.mClipboardMgr = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        CharSequence cs = null;
        try {
            cs = this.mClipboardMgr.getText();
        } catch (Exception e) {
        }
        if (cs != null) {
            this.mSavedClipBoardTxt = cs.toString();
        } else {
            this.mSavedClipBoardTxt = Trace.NULL;
        }
        this.mClipBoardCheckTimer = new Timer();
        this.mClipBoardCheckTimer.schedule(new CheckClipboardTask(), 500, 1000);
    }

    @SuppressLint({"NewApi"})
    public void onDestroy() {
        if (this.mClipBoardCheckTimer != null) {
            this.mClipBoardCheckTimer.cancel();
        }
        if (!(VERSION.SDK_INT < 11 || this.mClipboardManagerNew == null || this.mClipboardChangeListener == null)) {
            this.mClipboardManagerNew.removePrimaryClipChangedListener(this.mClipboardChangeListener);
        }
        this.mNotificationManager.cancel(BABYLON_ID);
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    private void PrepareNotifications() {
        this.mDefaultNotification = new Notification(R.drawable.logo_notification, Trace.NULL, System.currentTimeMillis());
        this.mDefaultNotification.flags |= 32;
        this.mDefaultNotification.contentView = new RemoteViews(this.mPackageName, R.layout.default_notification);
        Intent notificationIntent = new Intent(this.mAppContext, BabActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificationIntent.putExtra(getString(R.string.data_param), getString(R.string.empty_param));
        notificationIntent.setData(Uri.parse("foo://" + SystemClock.elapsedRealtime()));
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        this.mDefaultNotification.contentIntent = contentIntent;
        this.mStopped = false;
        this.mNotification = new Notification(R.drawable.transparent, Trace.NULL, System.currentTimeMillis());
        this.mNotification.flags |= 2;
        this.mNotification.contentIntent = contentIntent;
        this.mNotification.contentView = new RemoteViews(this.mPackageName, R.layout.custom_notification);
        this.mDataNotification = new Notification(R.drawable.logo_notification, Trace.NULL, System.currentTimeMillis());
        this.mDataNotification.flags |= 2;
        this.mDataNotification.contentIntent = contentIntent;
        this.mDataNotification.contentView = new RemoteViews(this.mPackageName, R.layout.loading_notification);
        this.mCustomTranslation = new Notification(R.drawable.logo_notification, Trace.NULL, System.currentTimeMillis());
        this.mCustomTranslation.contentIntent = contentIntent;
        this.mCustomTranslation.contentView = new RemoteViews(this.mPackageName, R.layout.custom_translation);
    }

    private void ShowDefaultNotification() {
        this.mStopped = true;
        this.mNotificationManager.notify(BABYLON_ID, this.mDefaultNotification);
    }

    public void ShowNotification(String definition) {
        if (definition == null) {
            ShowDefaultNotification();
            return;
        }
        this.mTerm = definition;
        Intent notificationIntent = new Intent(this.mAppContext, BabActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificationIntent.putExtra(getString(R.string.data_param), definition);
        notificationIntent.setData(Uri.parse("foo://" + SystemClock.elapsedRealtime()));
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        this.mNotification.contentIntent = contentIntent;
        this.mCustomTranslation.contentIntent = contentIntent;
        RemoteViews contentViewData = new RemoteViews(this.mPackageName, R.layout.loading_notification);
        this.mDataNotification.contentView = contentViewData;
        this.mDataNotification.contentIntent = contentIntent;
        StringBuilder sb = new StringBuilder();
        if (BabUtils.isOneWord(definition, this.mPrefs.getSourceFTTLang())) {
            this.mOneWord = true;
            sb.append(getString(R.string.translate)).append(
                    MinimalPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR).append(definition);
            contentViewData.setTextViewText(R.id.loading_text, definition);
        } else {
            this.mOneWord = false;
            sb.append(getString(R.string.full_text));
        }
        this.mNotification.icon = R.drawable.transparent;
        this.mNotification.tickerText = getString(R.string.retrieve_text);
        this.mDataNotification.tickerText = sb;
        this.mNotificationManager.notify(BABYLON_ID, this.mDataNotification);
        GetTranslation();
    }

    private void PrepareHttpParams() {
        HttpParams httpParameters = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParameters, 8000);
        HttpConnectionParams.setSoTimeout(httpParameters, CONNECTION_TIMEOUT);
        this.mHttpClient = new DefaultHttpClient(httpParameters);
        this.mLocalContext = new BasicHttpContext();
    }

    private void GetTranslation() {
        new Thread(new Runnable() {
            public void run() {
                HttpGet httpGet;
                String result = Trace.NULL;
                if (BabApplication.getPersistentPrefs() == null) {
                    BabUtils.initPersistentPrefs();
                }
                if (!BabApplication.InventoryQueryFinished) {
                    try {
                        Log.v(BabylonService.this.TAG, "waiting on billing inventory query  ");
                        synchronized (BabApplication.InventoryQuerySyncObject) {
                            BabApplication.InventoryQuerySyncObject.wait();
                        }
                        Log.v(BabylonService.this.TAG, "release wait for billing inventory query  ");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if (BabActivity.isFttUpgradeCondition(BabylonService.mLastClipboardText, BabylonService.this.mPrefs.getSourceFTTLang())) {
                    result = BabUtils.readFileFromAsset(BabylonService.this.mAppContext, "upgrade_notification.html");
                    BabUtils.checkFirstFttUpgradeDisplay(BabylonService.this.mPrefs);
                } else {
                    try {
                        String targetLang = BabylonService.this.GetTargetLang();
                        boolean bOffline = false;
                        boolean bLicOffline = true;
                        if (bLicOffline) {
                            BabylonService.this.m_offlineManager = OfflineManager.getInstance();
                            bOffline = BabylonService.this.m_offlineManager.isOffline(targetLang);
                        }
                        if (BabUtils.isDeviceOnline(BabApplication.getContext())) {
                            if (!BabylonService.this.mOneWord || !bOffline) {
                                BabPrefs prefs = BabApplication.getPrefs();
                                if (BabylonService.this.mOneWord) {
                                    httpGet = new HttpGet(URLUTF8Encoder.GetUrl(BabylonService.this.mTerm, true, -1, BabylonService.this.mLangs.GetLangNum(targetLang).intValue(), true));
                                 } else {
                                    httpGet = new HttpGet(URLUTF8Encoder.GetUrl(BabylonService.this.mTerm, true, prefs.getSourceFTTLang(), prefs.getTargetFTTLang(), false));
                                 }
                                BufferedReader reader = new BufferedReader(new InputStreamReader(BabylonService.this.mHttpClient.execute(httpGet, BabylonService.this.mLocalContext).getEntity().getContent()));
                                while (true) {
                                    String line = reader.readLine();
                                    if (line == null) {
                                        break;
                                    }
                                    result = new StringBuilder(result).append(line).toString();
                                }
                            } else {
                                result = BabylonService.this.GetOfflineTranslation(BabylonService.this.mTerm, targetLang);
                            }
                        } else if (!BabylonService.this.mOneWord) {
                            String sFTT = BabylonService.this.mTerm;
                            if (sFTT.length() > 40) {
                                sFTT = new StringBuilder(BabylonService.this.mTerm.substring(0, 36)).append("...").toString();
                            }
                            result = BabylonService.this.getString(R.string.bab_notification_device_offline, sFTT, BabylonService.this.mLangs.GetLangFromNum(BabylonService.this.mPrefs.getTargetFTTLang()));
                        } else if (bLicOffline) {
                            result = BabylonService.this.GetOfflineTranslation(BabylonService.this.mTerm, targetLang);
                        } else {
                            result = BabylonService.this.getString(R.string.bab_notification_device_offline, BabylonService.this.mTerm, BabylonService.this.GetTargetLang());
                        }
                    } catch (ConnectTimeoutException e2) {
                        result = BabylonService.this.getString(R.string.no_connection);
                     } catch (SocketTimeoutException e3) {
                        result = BabylonService.this.getString(R.string.no_connection);
                     } catch (Exception e4) {
                        result = "Error getting translation";
                     }
                }
                BabylonService.this.mNotificationManager.cancel(BabylonService.BABYLON_ID);
                RemoteViews contentView = new RemoteViews(BabylonService.this.mPackageName, R.layout.custom_translation);
                contentView.setTextViewText(R.id.txt_trans, Html.fromHtml(result));
                BabylonService.this.mCustomTranslation.contentView = contentView;
                BabylonService.this.mNotificationManager.notify(BabylonService.BABYLON_ID, BabylonService.this.mCustomTranslation);
            }
        }).start();
    }

    public String GetOfflineTranslation(String sTerm, String sLang) {
        return this.m_offlineManager.translateTerm(sTerm, sLang, null, true);
    }

    public String GetTargetLang() {
        FlagList flagList = this.mLangs.GetFlagsList(this.mAppContext);
        List<Integer> listLangs = this.mLangs.GetSelectedLangs();
        int tab = BabApplication.getPrefs().getTargetLangTab();
        if (tab >= listLangs.size()) {
            tab = listLangs.size() - 1;
        }
        return flagList.get(listLangs.get(tab).intValue()).mLanguage;
    }

    public void AnimateNotifty() {
        if (!this.mStopped) {
            this.mDataNotification.iconLevel++;
            if (this.mDataNotification.iconLevel > 16) {
                this.mDataNotification.iconLevel = 0;
                this.mStopped = true;
            }
            this.mNotificationManager.notify(BABYLON_ID, this.mDataNotification);
        }
    }

    static class MsgInnerHandler extends Handler {
        WeakReference<BabylonService> mBabService;

        MsgInnerHandler(BabylonService babService) {
            this.mBabService = new WeakReference<>(babService);
        }

        public void handleMessage(Message message) {
            BabylonService babService = this.mBabService.get();
            switch (message.what) {
                case 100:
                    BabylonService.mLastClipboardText = babService.mSavedClipBoardTxt;
                    babService.ShowNotification(BabylonService.mLastClipboardText);
//                    BabApplication.initBillingService();
                    return;
                case 101:
                    babService.AnimateNotifty();
                    return;
                case 102:
                    if (babService != null && babService.mNotificationManager != null) {
                        babService.mNotificationManager.cancel(BabylonService.BABYLON_ID);
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    class CheckClipboardTask extends TimerTask {
        CheckClipboardTask() {
        }

        public void run() {
            try {
                if (BabylonService.this.mClipboardMgr != null && BabylonService.this.mClipboardMgr.hasText()) {
                    String sText = BabylonService.this.mClipboardMgr.getText().toString().trim();
                    if (!sText.equals(BabylonService.this.mSavedClipBoardTxt)) {
                        BabylonService.this.msgHandler.removeMessages(102);
                        BabylonService.this.mSavedClipBoardTxt = sText;
                        Message msg = BabylonService.this.msgHandler.obtainMessage();
                        msg.what = 100;
                        BabylonService.this.msgHandler.sendMessage(msg);
                        Message msg2 = BabylonService.this.msgHandler.obtainMessage();
                        msg2.what = 102;
                        BabylonService.this.msgHandler.sendMessageDelayed(msg2, BabylonService.CLEAR_DATA_INTERVAL);
                    }
                }
            } catch (Exception e) {
            }
        }
    }
}
