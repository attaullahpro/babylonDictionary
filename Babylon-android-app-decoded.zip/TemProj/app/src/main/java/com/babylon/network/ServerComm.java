package com.babylon.network;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import java.net.URI;
import java.net.URISyntaxException;

import cz.msebera.android.httpclient.Header;

public class ServerComm {
    private static final String FIRST_RUN_URL = "//trck.info-stream.net/antrack/?";
    private static final String INSTALL_URL = "//stat.info-stream.net/an_report.php?";
    private static AsyncHttpClient client = new AsyncHttpClient();

    public void sendInstallMessage(String sPackageName, String sReferrer, String sUserID) {
        sendMessage("//stat.info-stream.net/an_report.php?package=" + sPackageName + "&referrer=" + sReferrer + "&guid=" + sUserID);
    }

    public void sendFirstRunMessage(String sPackageName, String sReferrer, String sUserID) {
        sendMessage("//trck.info-stream.net/antrack/?package=" + sPackageName + "&referrer=" + sReferrer + "&guid=" + sUserID + "&MSG=FIRST");
    }

    private void sendMessage(String sURL) {
        try {
            client.get(new URI("http", sURL, null).toASCIIString(), new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                }
            });
        } catch (URISyntaxException e1) {
            e1.printStackTrace();
        }
    }
}
