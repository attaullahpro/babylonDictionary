package com.babylon.controls;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.babylon.common.Constants;
import com.babylon.translator.R;

public class BabUpgradeActivity extends AppCompatActivity {
    private static int colorDisable = 1073741824;
    /* access modifiers changed from: private */
    public boolean mIsFuture = false;
    /* access modifiers changed from: private */
    public OnDialogResult mResult;
    OnClickListener onMaybeLater = new OnClickListener() {
        public void onClick(View v) {
            if (BabUpgradeActivity.this.mResult != null) {
                BabUpgradeActivity.this.mResult.onResult(false);
            }
//            GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_UPGRADE_BANNER_MAYBE_LATER);
            BabUpgradeActivity.this.setResult(0, new Intent());
            BabUpgradeActivity.this.finish();
        }
    };
    OnClickListener onUpgrade = new OnClickListener() {
        public void onClick(View v) {
            if (!BabUpgradeActivity.this.mIsFuture) {
//                GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_UPGRADE_BANNER_HIT_UPGRADE);
                int selectedId = ((RadioGroup) BabUpgradeActivity.this.findViewById(R.id.RadioGroupOffers)).getCheckedRadioButtonId();
                Intent returnIntent = new Intent();
                switch (selectedId) {
                    case R.id.radio_basic /*2131427482*/:
                        returnIntent.putExtra("result", Constants.IN_APP_PRODUCT_FTT);
                        break;
                    case R.id.radio_basic2 /*2131427483*/:
                        returnIntent.putExtra("result", Constants.IN_APP_PRODUCT_OFFLINE);
                        break;
                    case R.id.radio_basic3 /*2131427484*/:
                        returnIntent.putExtra("result", Constants.IN_APP_PRODUCT_FTT_OFFLINE);
                        break;
                    case R.id.radio_basic4 /*2131427485*/:
                        returnIntent.putExtra("result", Constants.IN_APP_PRODUCT_FUTURE);
                        break;
                }
                BabUpgradeActivity.this.setResult(-1, returnIntent);
                BabUpgradeActivity.this.finish();
                return;
            }
            BabUpgradeActivity.this.setResult(0, new Intent());
            BabUpgradeActivity.this.finish();
        }
    };
    private Button btnUpgrade;
    private TextView mTxtMaybeLater;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.premium_offer);
        this.mTxtMaybeLater = findViewById(R.id.txtMaybeLater);
        this.mTxtMaybeLater.setOnClickListener(this.onMaybeLater);
        this.mTxtMaybeLater.setPaintFlags(this.mTxtMaybeLater.getPaintFlags() | 8);
        this.btnUpgrade = findViewById(R.id.btnUpgrade);
        this.btnUpgrade.setOnClickListener(this.onUpgrade);
        AdjustPackages();
        ActionBar actionbar = getSupportActionBar();
        actionbar.setBackgroundDrawable(new ColorDrawable(-13224386));
        actionbar.setTitle(getString(R.string.premium_packages_title));
//        GoogleAnalyticsAdapter.sendAnalyticsEvent(AnalyticsConstants.CATEGORY_PURCHASE, AnalyticsConstants.EVENT_UPGRADE_BANNER_APPEARS);
    }

    private void AdjustPackages() {
        boolean bFtt = true;//IabHelper.getIsProVersionFtt();
        boolean bOffline = true;//IabHelper.getIsProVersionOffline();
        if (bFtt) {
            RadioButton btn = findViewById(R.id.radio_basic);
            btn.setEnabled(false);
            btn.setTextColor(colorDisable);
        }
        if (bOffline) {
            RadioButton btn2 = findViewById(R.id.radio_basic2);
            btn2.setEnabled(false);
            btn2.setTextColor(colorDisable);
        }
        if (bFtt && bOffline) {
            RadioButton btn3 = findViewById(R.id.radio_basic3);
            btn3.setEnabled(false);
            btn3.setText(R.string.premium_packages_basic3_nocolor);
            btn3.setTextColor(colorDisable);
            RadioButton btn4 = findViewById(R.id.radio_basic4);
            btn4.setChecked(true);
            if (/*IabHelper.getIsProVersionFuture()*/true) {
                this.mIsFuture = true;
                btn4.setTextColor(colorDisable);
                this.btnUpgrade.setEnabled(false);
            }
        }
    }

    public void setOnDialogResult(OnDialogResult dialogResult) {
        this.mResult = dialogResult;
    }

    public interface OnDialogResult {
        void onResult(boolean z);
    }
}
