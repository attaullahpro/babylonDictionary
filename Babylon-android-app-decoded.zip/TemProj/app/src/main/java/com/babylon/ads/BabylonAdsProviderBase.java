package com.babylon.ads;

import android.app.Activity;

public abstract class BabylonAdsProviderBase {
    /* access modifiers changed from: protected */
    public abstract boolean isContinueToNextState();

    /* access modifiers changed from: protected */
    public abstract boolean nextState(Activity activity);

    public void evaluate(Activity parent) {
        do {
        } while (nextState(parent));
    }
}
