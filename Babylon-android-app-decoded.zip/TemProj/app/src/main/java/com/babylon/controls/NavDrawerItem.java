package com.babylon.controls;

public class NavDrawerItem {
    public int icon;
    public String name;

    public NavDrawerItem(String name2, int icon2) {
        this.icon = icon2;
        this.name = name2;
    }
}
