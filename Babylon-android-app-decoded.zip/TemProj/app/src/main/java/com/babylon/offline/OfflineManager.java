package com.babylon.offline;

import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.AsyncTask;
import android.os.Environment;
import com.babylon.common.BabPrefs;
import com.babylon.common.OfflineData;
import com.babylon.common.UnzipUtil;
import com.babylon.translate.BabApplication;
import com.babylon.translator.R;
import com.newrelic.agent.android.instrumentation.Trace;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.codehaus.jackson.util.MinimalPrettyPrinter;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class OfflineManager {
    public static String DOWNLOAD_CANCEL_EVENT = "cancel";
    public static String DOWNLOAD_FINISH_EVENT = "finish";
    /* access modifiers changed from: private */
    public static String DOWNLOAD_URL = "http://dl.babylon.com/files/offline/android/";
    protected static OfflineManager mInstance = null;
    public static String[] mOfflineFiles = {"CSI_names.xml", "metaphone.dat"};
    /* access modifiers changed from: private */
    public Integer mPercentComplete = Integer.valueOf(0);
    BabPrefs mPrefs;
    /* access modifiers changed from: private */
    public ProgressDialog mProgressBar;
    private Transformer mTransformer;
    private Transformer mTransformerOffline;
    private Map<String, OfflineData> m_mapFileNames = new HashMap();
    private String m_sCurrentLang;
    /* access modifiers changed from: private */
    public String m_sDictsPath = null;

    class DownloadData extends AsyncTask<OfflineData[], Integer, Void> {
        private Context mContext;
        private String mMsg;
        private boolean mSuccess = false;

        DownloadData(Context ctx) {
            this.mContext = ctx;
        }

        /* access modifiers changed from: protected */
        public Void doInBackground(OfflineData[]... params) {
            OfflineData[] data = params[0];
            for (int i = 0; i < data.length; i++) {
                this.mMsg = this.mContext.getString(R.string.download_offline, new Object[]{data[i].mSource, data[i].mTarget});
                String sZip = new StringBuilder(String.valueOf(data[i].mZipFileName)).append(".zip").toString();
                if (downloadZipFileHttp(OfflineManager.DOWNLOAD_URL + sZip, new StringBuilder(String.valueOf(OfflineManager.this.m_sDictsPath)).append(sZip).toString())) {
                    this.mMsg = this.mContext.getString(R.string.install_offline, new Object[]{data[i].mSource, data[i].mTarget});
                    this.mSuccess = InstallFromZip(sZip, OfflineManager.this.m_sDictsPath);
                    OfflineManager.this.ChangeOfflineStatus(data[i].mTarget, true);
                }
            }
            return null;
        }

        /* access modifiers changed from: protected */
        public void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            if (OfflineManager.this.mProgressBar != null && OfflineManager.this.mProgressBar.isShowing()) {
                OfflineManager.this.mProgressBar.setMessage(this.mMsg);
                OfflineManager.this.mProgressBar.setProgress(values[0].intValue());
                if (values[0].intValue() == 100) {
                    OfflineManager.this.mProgressBar.setProgress(0);
                }
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            OfflineManager.this.mProgressBar = new ProgressDialog(this.mContext);
            OfflineManager.this.mProgressBar.setCancelable(true);
            OfflineManager.this.mProgressBar.setOnCancelListener(new OnCancelListener() {
                public void onCancel(DialogInterface dialog) {
                    DownloadData.this.cancel(true);
                }
            });
            OfflineManager.this.mProgressBar.setMessage(MinimalPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR);
            OfflineManager.this.mProgressBar.setProgressStyle(1);
            OfflineManager.this.mProgressBar.setProgress(0);
            OfflineManager.this.mProgressBar.setMax(100);
            OfflineManager.this.mProgressBar.show();
        }

        /* access modifiers changed from: protected */
        public void onCancelled() {
            super.onCancelled();
            this.mContext.sendBroadcast(new Intent(OfflineManager.DOWNLOAD_CANCEL_EVENT));
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void v) {
            super.onPostExecute(null);
            try {
                if (OfflineManager.this.mProgressBar != null && OfflineManager.this.mProgressBar.isShowing()) {
                    OfflineManager.this.mProgressBar.dismiss();
                }
            } catch (Exception e) {
            }
            OfflineManager.this.mProgressBar = null;
            if (!this.mSuccess) {
                this.mContext.sendBroadcast(new Intent(OfflineManager.DOWNLOAD_CANCEL_EVENT));
                return;
            }
            OfflineManager.this.UpdateInstalledDicts();
            new File(new StringBuilder(String.valueOf(OfflineManager.this.m_sDictsPath)).append("bdcmpers.dat").toString()).delete();
            this.mContext.sendBroadcast(new Intent(OfflineManager.DOWNLOAD_FINISH_EVENT));
        }

        public boolean installZipFromStream(ZipInputStream fileStream, String destinationDir, int numoffiles) {
            int filenum = 0;
            ZipInputStream inputStream = fileStream;
            try {
                for (ZipEntry entry = inputStream.getNextEntry(); entry != null; entry = inputStream.getNextEntry()) {
                    File destinationFile = new File(destinationDir, entry.getName());
                    filenum++;
                    if (entry.isDirectory()) {
                        destinationFile.mkdirs();
                    } else {
                        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(destinationFile), 8192);
                        long totalSize = entry.getSize();
                        long totalRead = 0;
                        OfflineManager.this.mPercentComplete = Integer.valueOf(0);
                        byte[] data = new byte[8192];
                        while (true) {
                            int count = inputStream.read(data, 0, 8192);
                            if (count == -1 || isCancelled()) {
                                bufferedOutputStream.close();
                            } else {
                                bufferedOutputStream.write(data, 0, count);
                                totalRead += (long) count;
                                OfflineManager.this.mPercentComplete = Integer.valueOf((int) ((((float) totalRead) / ((float) totalSize)) * 100.0f));
                                publishProgress(new Integer[]{OfflineManager.this.mPercentComplete});
                            }
                        }
//                        bufferedOutputStream.close();
                    }
                    inputStream.closeEntry();
                }
                if (filenum == 0 || OfflineManager.this.mPercentComplete.intValue() < 99) {
                    return false;
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        public boolean InstallFromZip(String sourceFilename, String destinationDirIn) {
            boolean retval = false;
            File file = new File(new StringBuilder(String.valueOf(destinationDirIn)).append(sourceFilename).toString());
            try {
                int numoffiles = new ZipFile(file).size();
                InputStream fileStream = new FileInputStream(file);
                ZipInputStream inputStream = new ZipInputStream(fileStream);
                retval = installZipFromStream(inputStream, destinationDirIn, numoffiles);
                inputStream.close();
                fileStream.close();
            } catch (Exception e) {
            }
            file.delete();
            return retval;
        }

        public boolean downloadZipFileHttp(String urlIn, String destinationFile) {
            try {
                File tempFile = new File(destinationFile);
                if (tempFile.exists()) {
                    tempFile.delete();
                }
                HttpURLConnection urlConnection = (HttpURLConnection) new URL(urlIn).openConnection();
                urlConnection.setAllowUserInteraction(false);
                urlConnection.setInstanceFollowRedirects(true);
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                if (urlConnection.getResponseCode() != 200) {
                    return false;
                }
                int iFileSize = urlConnection.getContentLength();
                InputStream inputStream = urlConnection.getInputStream();
                FileOutputStream fileOutputStream = null;
                try {
                    fileOutputStream = new FileOutputStream(tempFile);
                } catch (FileNotFoundException e) {
                }
                int downloaded = 0;
                byte[] buffer = new byte[8192];
                while (true) {
                    int bufferLength = inputStream.read(buffer, 0, 8192);
                    if (bufferLength <= 0 || isCancelled()) {
                        fileOutputStream.close();
                    } else {
                        fileOutputStream.write(buffer, 0, bufferLength);
                        downloaded += bufferLength;
                        OfflineManager.this.mPercentComplete = Integer.valueOf((int) ((((float) downloaded) / ((float) iFileSize)) * 100.0f));
                        publishProgress(new Integer[]{OfflineManager.this.mPercentComplete});
                    }
                }
//                fileOutputStream.close();
//                if (urlConnection != null) {
//                    urlConnection.disconnect();
//                }
//                if (isCancelled()) {
//                    return false;
//                }
//                return true;
            } catch (Exception e2) {
                return true;
            }
        }
    }

    private native String translateFromJNI(String str, String str2, String str3);

    static {
        try {
            System.loadLibrary("iconv");
            System.loadLibrary("translate-jni");
        } catch (ExceptionInInitializerError e) {
        } catch (UnsatisfiedLinkError e2) {
            ExtractSO("libiconv.so");
            ExtractSO("libtranslate-jni.so");
        }
    }

    public OfflineManager() {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            File sExternal = BabApplication.getContext().getExternalFilesDir(null);
            if (sExternal != null) {
                this.m_sDictsPath = sExternal.getAbsolutePath() + "/";
            }
        }
        if (this.m_sDictsPath == null) {
            File sExternal2 = BabApplication.getContext().getFilesDir();
            if (sExternal2 != null) {
                this.m_sDictsPath = sExternal2.getAbsolutePath() + "/";
            }
        }
        this.mPrefs = BabApplication.getPrefs();
        InitFileNamesMap();
        try {
            this.mTransformer = TransformerFactory.newInstance().newTransformer(new StreamSource(BabApplication.getContext().getResources().getAssets().open("TranslationReply.xsl")));
            this.mTransformerOffline = TransformerFactory.newInstance().newTransformer(new StreamSource(BabApplication.getContext().getResources().getAssets().open("transOffline.xsl")));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static OfflineManager getInstance() {
        try {
            if (mInstance == null) {
                mInstance = new OfflineManager();
            }
            return mInstance;
        } catch (Exception e) {
            return null;
        }
    }

    public String GetDictsPath() {
        return this.m_sDictsPath;
    }

    public void DownloadDict(Context ctx, OfflineData[] data) {
        new DownloadData(ctx).execute(new OfflineData[][]{data});
    }

    public boolean IsDictInstalled(String sLang) {
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            OfflineData data = (OfflineData) entry.getValue();
            if (data.mTarget.equals(sLang) && data.mInstalled) {
                return true;
            }
        }
        return false;
    }

    public boolean IsDictSupported(String sTargetLang) {
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            if (((OfflineData) entry.getValue()).mTarget.equals(sTargetLang)) {
                return true;
            }
        }
        return false;
    }

    public boolean isOffline(String sLang) {
        if (this.mPrefs != null) {
            Iterator it = this.mPrefs.getOfflineDicts().iterator();
            while (it.hasNext()) {
                OfflineData data = (OfflineData) this.m_mapFileNames.get((String) it.next());
                if (data != null && data.mTarget.equals(sLang)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void ChangeOfflineStatus(String sLang, boolean bAdd) {
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            OfflineData data = (OfflineData) entry.getValue();
            if (data.mTarget.equals(sLang) && data.mInstalled) {
                this.mPrefs.UpdateOfflineDicts((String) entry.getKey(), bAdd);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void InitFileNamesMap() {
        this.m_mapFileNames.put("EnglishNorwegian", new OfflineData("English", "Norwegian", 9.3f, "dict10F93", false));
        this.m_mapFileNames.put("EnglishDanish", new OfflineData("English", "Danish", 12.5f, "dict10FA8", false));
        this.m_mapFileNames.put("EnglishPolish", new OfflineData("English", "Polish", 2.1f, "dict114BC", false));
        this.m_mapFileNames.put("EnglishCzech", new OfflineData("English", "Czech", 2.1f, "dict114E4", false));
        this.m_mapFileNames.put("PolishEnglish", new OfflineData("Polish", "English", 3.9f, "dict11764", false));
        this.m_mapFileNames.put("CzechEnglish", new OfflineData("Czech", "English", 5.7f, "dict11765", false));
        this.m_mapFileNames.put("EnglishArabic", new OfflineData("English", "Arabic", 14.4f, "dictE99A", false));
        this.m_mapFileNames.put("EnglishEnglish", new OfflineData("English", "English", 15.9f, "dict385", false));
        this.m_mapFileNames.put("EnglishDutch", new OfflineData("English", "Dutch", 11.5f, "dict386", false));
        this.m_mapFileNames.put("EnglishFrench", new OfflineData("English", "French", 14.5f, "dict387", false));
        this.m_mapFileNames.put("EnglishGerman", new OfflineData("English", "German", 13.6f, "dict388", false));
        this.m_mapFileNames.put("EnglishHebrew", new OfflineData("English", "Hebrew", 13.9f, "dict389", false));
        this.m_mapFileNames.put("EnglishChinese (Simplified)", new OfflineData("English", "Chinese (Simplified)", 5.4f, "dict390", false));
        this.m_mapFileNames.put("EnglishChinese (Traditional)", new OfflineData("English", "Chinese (Traditional)", 5.0f, "dict38F", false));
        this.m_mapFileNames.put("EnglishGreek", new OfflineData("English", "Greek", 4.3f, "dictE423", false));
        this.m_mapFileNames.put("EnglishItalian", new OfflineData("English", "Italian", 13.6f, "dict38A", false));
        this.m_mapFileNames.put("EnglishJapanese", new OfflineData("English", "Japanese", 11.9f, "dict38B", false));
        this.m_mapFileNames.put("EnglishKorean", new OfflineData("English", "Korean", 5.7f, "dict399", false));
        this.m_mapFileNames.put("EnglishPortuguese", new OfflineData("English", "Portuguese", 12.4f, "dict38C", false));
        this.m_mapFileNames.put("EnglishRussian", new OfflineData("English", "Russian", 8.2f, "dict39A", false));
        this.m_mapFileNames.put("EnglishSpanish", new OfflineData("English", "Spanish", 14.6f, "dict38D", false));
        this.m_mapFileNames.put("EnglishSwedish", new OfflineData("English", "Swedish", 9.1f, "dict38E", false));
        this.m_mapFileNames.put("EnglishTurkish", new OfflineData("English", "Turkish", 15.5f, "dictDEAA", false));
        this.m_mapFileNames.put("ArabicEnglish", new OfflineData("Arabic", "English", 13.2f, "dictE99B", false));
        this.m_mapFileNames.put("Chinese (Simplified)English", new OfflineData("Chinese (Simplified)", "English", 3.8f, "dict4EE", false));
        this.m_mapFileNames.put("Chinese (Traditional)English", new OfflineData("Chinese (Traditional)", "English", 3.9f, "dict4ED", false));
        this.m_mapFileNames.put("DutchEnglish", new OfflineData("Dutch", "English", 4.9f, "dictBD54", false));
        this.m_mapFileNames.put("FrenchEnglish", new OfflineData("French", "English", 11.1f, "dict4E5", false));
        this.m_mapFileNames.put("GreekEnglish", new OfflineData("Greek", "English", 4.3f, "dictE422", false));
        this.m_mapFileNames.put("GermanEnglish", new OfflineData("German", "English", 24.2f, "dict9DA", false));
        this.m_mapFileNames.put("HebrewEnglish", new OfflineData("Hebrew", "English", 7.0f, "dict4E7", false));
        this.m_mapFileNames.put("HebrewHebrew", new OfflineData("Hebrew", "Hebrew", 8.0f, "dict645", false));
        this.m_mapFileNames.put("ItalianEnglish", new OfflineData("Italian", "English", 11.1f, "dict4E8", false));
        this.m_mapFileNames.put("JapaneseEnglish", new OfflineData("Japanese", "English", 25.4f, "dict4E9", false));
        this.m_mapFileNames.put("KoreanEnglish", new OfflineData("Korean", "English", 14.0f, "dict4F7", false));
        this.m_mapFileNames.put("PortugueseEnglish", new OfflineData("Portuguese", "English", 24.1f, "dict4EA", false));
        this.m_mapFileNames.put("RussianEnglish", new OfflineData("Russian", "English", 20.0f, "dict4F8", false));
        this.m_mapFileNames.put("SpanishEnglish", new OfflineData("Spanish", "English", 26.8f, "dict4EB", false));
        this.m_mapFileNames.put("TurkishEnglish", new OfflineData("Turkish", "English", 27.3f, "dictDE96", false));
        UpdateInstalledDicts();
    }

    /* access modifiers changed from: private */
    public void UpdateInstalledDicts() {
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            String key = (String) entry.getKey();
            if (new File(this.m_sDictsPath + new StringBuilder(String.valueOf(((OfflineData) this.m_mapFileNames.get(key)).mZipFileName)).append(".bdc").toString()).exists()) {
                OfflineData data = (OfflineData) entry.getValue();
                if (!data.mInstalled) {
                    this.mPrefs.UpdateOfflineDicts(key, true);
                }
                data.mInstalled = true;
                entry.setValue(data);
            } else {
                this.mPrefs.UpdateOfflineDicts(key, false);
            }
        }
    }

    public Map<String, OfflineData> GetOfflineMap() {
        return this.m_mapFileNames;
    }

    public boolean IsTargetLangSupported(String sLang) {
        if (sLang == "English") {
            return true;
        }
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            if (((OfflineData) entry.getValue()).mTarget == sLang) {
                return true;
            }
        }
        return false;
    }

    public void DeleteDict(String sFileName) {
        new File(this.m_sDictsPath + sFileName).delete();
        for (Entry<String, OfflineData> entry : this.m_mapFileNames.entrySet()) {
            OfflineData data = (OfflineData) entry.getValue();
            if (sFileName.startsWith(data.mZipFileName)) {
                this.mPrefs.UpdateOfflineDicts((String) entry.getKey(), false);
                data.mInstalled = false;
                return;
            }
        }
    }

    public String translateTerm(String sTerm, String sTargetLang, Context ctx, boolean bOffline) {
        for (String filename : mOfflineFiles) {
            if (!new File(this.m_sDictsPath, filename).exists()) {
                if (ctx != null) {
                    Builder builder = new Builder(ctx);
                    builder.setMessage("Can't get offline translation. Please restart the application and try again.").setCancelable(false).setPositiveButton("OK", new OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
                    builder.create().show();
                }
                return "No results";
            }
        }
        try {
            return parseContentServerResult(translateFromJNI(sTerm, sTargetLang, this.m_sDictsPath), sTerm, bOffline);
        } catch (Exception e) {
            //BugSenseHandler.sendEvent(String.format("Error in offline translate: %s. offline path:%s. lang:", new Object[]{e.getMessage(), this.m_sDictsPath, sTargetLang}));
            return "No results";
        }
    }

    private String parseContentServerResult(String xmlInput, String sTerm, boolean bOffline) {
        String sRes = Trace.NULL;
        try {
            String sResultOffline = convertResultOffline(xmlInput, sTerm);
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.setOutputProperty("omit-xml-declaration", "yes");
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            StringReader stringReader = new StringReader(sResultOffline);
            NodeList glossList = builder.parse(new InputSource(stringReader)).getElementsByTagName("bab:Glossary");
            int iLength = glossList.getLength();
            for (int i = 0; i < iLength; i++) {
                Node node = glossList.item(i);
                StreamResult result = new StreamResult(new StringWriter());
                xformer.transform(new DOMSource(node), result);
                sRes = new StringBuilder(String.valueOf(sRes)).append(TransformXML(result.getWriter().toString(), bOffline)).toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (sRes == Trace.NULL) {
            return BabApplication.getContext().getString(R.string.no_results).replace("\n", "<br>");
        }
        return sRes;
    }

    private String convertResultOffline(String xmlInput, String sTerm) {
        XPath xPath = XPathFactory.newInstance().newXPath();
        String results = "<bab:OfflineReply xmlns:bab=\"urn:schemas-babylon-com:bab\">";
        String str = "DOM_ServerMessage/CSI_ReplyGroup/CSI_GlossReplyList/CSI_GlossReply";
        try {
            StringReader stringReader = new StringReader(xmlInput);
            NodeList headers = (NodeList) xPath.evaluate(str, new InputSource(stringReader), XPathConstants.NODESET);
            int iLength = headers.getLength();
            for (int i = 0; i < iLength; i++) {
                Element el = (Element) headers.item(i);
                Node nHeaderXML = el.getElementsByTagName("CSI_Headers").item(0);
                if (nHeaderXML != null) {
                    StringBuffer stringBuffer = new StringBuffer(URLDecoder.decode(nHeaderXML.getTextContent().trim(), "UTF-8").replace("bab:Headers", "bab:GlossaryHeaders").replace("bab:GlossaryIcon", "bab:Icon"));
                    stringBuffer.deleteCharAt(0);
                    stringBuffer.deleteCharAt(stringBuffer.length() - 1);
                    StringBuffer stringBuffer2 = new StringBuffer(sRemoveXMLHeader(stringBuffer.toString()));
                    Element el2 = (Element) el.getElementsByTagName("CSI_ResultReply").item(0);
                    String sLength = "<bab:TermLength>" + sTerm.length() + "</bab:TermLength>";
                    String sDisplay = "<bab:DisplayText>" + sTerm + "</bab:DisplayText>";
                    StringBuffer stringBuffer3 = new StringBuffer(URLDecoder.decode(el2.getElementsByTagName("CSI_ResultText").item(0).getTextContent().trim(), "UTF-8"));
                    stringBuffer3.deleteCharAt(0);
                    stringBuffer3.deleteCharAt(stringBuffer3.length() - 1);
                    StringBuffer stringBuffer4 = new StringBuffer(sRemoveXMLHeader(stringBuffer3.toString()));
                    stringBuffer4.insert(stringBuffer4.indexOf("<bab:Terms>"), stringBuffer2);
                    int iFind = stringBuffer4.indexOf("</bab:Term>");
                    stringBuffer4.insert(iFind, sLength);
                    stringBuffer4.insert(iFind, sDisplay);
                    results = new StringBuilder(String.valueOf(results)).append(stringBuffer4).toString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new StringBuilder(String.valueOf(results)).append("</bab:OfflineReply>").toString();
    }

    private String sRemoveXMLHeader(String sData) {
        if (!sData.startsWith("<?")) {
            return sData;
        }
        int iStart = sData.indexOf(">");
        if (iStart != -1) {
            return sData.substring(iStart + 1);
        }
        return sData;
    }

    private String TransformXML(String strXml, boolean bOffline) {
        String html = Trace.NULL;
        try {
            InputStream ds = new ByteArrayInputStream(strXml.getBytes("UTF-8"));
            Source xmlSource = new StreamSource(ds);
            StringWriter writer = new StringWriter();
            Result result = new StreamResult(writer);
            if (bOffline) {
                this.mTransformerOffline.transform(xmlSource, result);
            } else {
                this.mTransformer.transform(xmlSource, result);
            }
            String html2 = writer.toString();
            ds.close();
            return html2;
        } catch (Exception e) {
            e.printStackTrace();
            return html;
        }
    }

    private static void ExtractSO(String libName) {
//        Context context = BabApplication.getContext();
//        ApplicationInfo appInfo = context.getApplicationInfo();
//        String destPath = context.getFilesDir().toString();
//        try {
//            String soName = new StringBuilder(String.valueOf(destPath)).append(File.separator).append(libName).toString();
//            new File(soName).delete();
//            UnzipUtil.extractFile(appInfo.sourceDir, "lib/armeabi/" + libName, destPath);
//            System.load(soName);
//        } catch (IOException e) {
//            String destPath2 = context.getExternalCacheDir().toString();
//            String soName2 = new StringBuilder(String.valueOf(destPath2)).append(File.separator).append(libName).toString();
//            new File(soName2).delete();
//            try {
//                UnzipUtil.extractFile(appInfo.sourceDir, "lib/armeabi/" + libName, destPath2);
//                System.load(soName2);
//            } catch (IOException e2) {
//                e.printStackTrace();
//            }
//        }
    }
}
