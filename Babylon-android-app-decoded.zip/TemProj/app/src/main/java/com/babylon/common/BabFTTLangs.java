package com.babylon.common;

import android.content.Context;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Vector;

public class BabFTTLangs {
    private static final String[] mLangs = {"English", "Arabic", "Bulgarian", "Chinese (Simplified)", "Chinese (Traditional)", "Czech", "Danish", "Dutch", "Farsi", "Finnish", "French", "German", "Greek", "Hebrew", "Hindi", "Hungarian", "Italian", "Japanese", "Norwegian", "Korean", "Pashto", "Polish", "Portuguese", "Romanian", "Russian", "Serbian", "Spanish", "Swedish", "Thai", "Turkish", "Ukrainian", "Urdu"};
    public Hashtable<String, Vector<String>> mTransTable = new Hashtable<>();

    BabFTTLangs(Context context) {
    }

    public Vector<String> getSourceLanguages() {
        return new Vector<>(Arrays.asList(mLangs));
    }

    public Vector<String> getTargetLanguages(String sLang) {
        Vector<String> v = new Vector<>(Arrays.asList(mLangs));
        v.remove(sLang);
        return v;
    }
}
