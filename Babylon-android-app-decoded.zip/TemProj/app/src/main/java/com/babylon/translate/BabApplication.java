package com.babylon.translate;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import com.babylon.common.ACDatabaseHandler;
import com.babylon.common.BabPrefs;
import com.babylon.common.Constants;
import com.babylon.common.PersistentPrefs;

public class BabApplication extends Application {
    public static boolean InventoryQueryFinished = false;
    public static Object InventoryQuerySyncObject = new Object();
    /* access modifiers changed from: private */
    public static String TAG = "babylon application context";
    public static ACDatabaseHandler mACDatabase;
    private static PersistentPrefs mPersistencePrefs;
    private static BabPrefs mPrefs;
    private static Context sContext;

    public void onCreate() {
        super.onCreate();
        try {
            Class.forName("android.os.AsyncTask");
        } catch (Throwable th) {
        }
        sContext = getApplicationContext();
    }

    public static Context getContext() {
        return sContext;
    }

    public static void InitDatabase() {
        mACDatabase = new ACDatabaseHandler(sContext);
        new Thread(new Runnable() {
            public void run() {
                BabApplication.mACDatabase.CheckSize();
            }
        }).start();
    }

    public static void incrementFtt() {
        if (mPersistencePrefs != null) {
            mPersistencePrefs.incrementFtt();
        }
    }

    public static boolean fttCapReached() {
        if (mPersistencePrefs != null) {
            return mPersistencePrefs.fttCapReached();
        }
        return false;
    }

    public static PersistentPrefs getPersistentPrefs() {
        return mPersistencePrefs;
    }

    public static void setPersistentPrefs(PersistentPrefs prefs) {
        mPersistencePrefs = prefs;
    }



    public static BabPrefs getPrefs() {
        if (mPrefs == null) {
            mPrefs = new BabPrefs(sContext);
        }
        return mPrefs;
    }
}
