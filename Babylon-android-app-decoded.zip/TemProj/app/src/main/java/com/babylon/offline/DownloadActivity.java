package com.babylon.offline;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.babylon.common.BabUtils;
import com.babylon.common.FlagData;
import com.babylon.common.FlagList;
import com.babylon.common.OfflineData;
import com.babylon.translate.BabActivity;
import com.babylon.translate.BabApplication;
import com.babylon.translator.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class DownloadActivity extends AppCompatActivity {
    int mDeleteIndex = -1;
    ListView mListviewDicts;
    OfflineAdapter mOfflineAdapter;
    OfflineManager mOfflineMgr = OfflineManager.getInstance();
    BroadcastReceiver mReceiver;
    ArrayList<OfflineData> m_arrData;
    ArrayList<Integer> m_arrNeedToInstall;
    int m_iSelected = 0;
    private Toolbar _toolbar;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.download_dicts);
        this._toolbar = findViewById(R.id.abp__toolbar);
        InitDataArray();
        this.mListviewDicts = findViewById(R.id.listviewDicts);
        this.mOfflineAdapter = new OfflineAdapter(this, R.layout.offline_row, this.m_arrData, this.m_iSelected);
        this.mListviewDicts.setAdapter(this.mOfflineAdapter);
        findViewById(R.id.btnDownloadOffline).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (BabUtils.isDeviceOnline(BabApplication.getContext())) {
                    DownloadActivity.this.InstallDicts();
                    return;
                }
                Builder builder = new Builder(DownloadActivity.this);
                builder.setMessage(R.string.cant_download_offline).setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.create().show();
            }
        });
        this.mReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(OfflineManager.DOWNLOAD_FINISH_EVENT)) {
                    DownloadActivity.this.m_arrNeedToInstall.clear();
                    DownloadActivity.this.InitDataArray();
                    DownloadActivity.this.mOfflineAdapter.updateDictsList(DownloadActivity.this.m_arrData, DownloadActivity.this.m_iSelected);
                    Builder builder = new Builder(context);
                    builder.setMessage(R.string.download_finished_success).setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            DownloadActivity.this.finish();
                        }
                    });
                    builder.create().show();
                } else if (intent.getAction().equals(OfflineManager.DOWNLOAD_CANCEL_EVENT)) {
                    Builder builder2 = new Builder(context);
                    builder2.setMessage(R.string.download_cancelled).setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            DownloadActivity.this.InstallDicts();
                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
                    builder2.create().show();
                }
            }
        };
        registerReceiver(this.mReceiver, new IntentFilter(OfflineManager.DOWNLOAD_FINISH_EVENT));
        registerReceiver(this.mReceiver, new IntentFilter(OfflineManager.DOWNLOAD_CANCEL_EVENT));
        this._toolbar.setTitle(getString(R.string.settings_Download_Offline));
        this._toolbar.setNavigationIcon(R.drawable.back);
        this._toolbar.setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                DownloadActivity.this.finish();
            }
        });
    }

    /* access modifiers changed from: private */
    public void InitDataArray() {
        this.m_iSelected = 0;
        this.m_arrData = new ArrayList<>();
        Map<String, OfflineData> map = new HashMap<>(this.mOfflineMgr.GetOfflineMap());
        ArrayList<Integer> arrSelectedLangs = BabActivity.mLangs.GetSelectedLangs();
        FlagList arrFlags = BabActivity.mFlagList;
        for (Entry<String, OfflineData> entry : this.mOfflineMgr.GetOfflineMap().entrySet()) {
            if (entry.getValue().mInstalled) {
                this.m_arrData.add(entry.getValue());
                map.remove(entry.getKey());
            }
        }
        Collections.sort(this.m_arrData, new DictComparator());
        int iInstalled = this.m_arrData.size();
        ArrayList<OfflineData> arrTemp = new ArrayList<>();
        if (arrSelectedLangs != null) {
            Iterator it = arrSelectedLangs.iterator();
            while (it.hasNext()) {
                String sTarget = arrFlags.get(((Integer) it.next()).intValue()).mLanguage;
                if (!sTarget.equals("English")) {
                    OfflineData data = map.get("English" + sTarget);
                    if (data != null) {
                        arrTemp.add(data);
                    }
                    map.remove("English" + sTarget);
                }
            }
        }
        Collections.sort(arrTemp, new DictComparator());
        this.m_arrData.addAll(arrTemp);
        arrTemp.clear();
        if (arrSelectedLangs != null) {
            Iterator it2 = arrSelectedLangs.iterator();
            while (it2.hasNext()) {
                String sTarget2 = arrFlags.get(((Integer) it2.next()).intValue()).mLanguage;
                if (!sTarget2.equals("English")) {
                    OfflineData data2 = map.get(new StringBuilder(sTarget2).append("English").toString());
                    if (data2 != null) {
                        arrTemp.add(data2);
                    }
                    map.remove(sTarget2);
                }
            }
        }
        Collections.sort(arrTemp, new DictComparator());
        this.m_arrData.addAll(arrTemp);
        OfflineData dataHebHeb = map.get("HebrewHebrew");
        if (dataHebHeb != null && arrSelectedLangs != null) {
            Iterator it3 = arrSelectedLangs.iterator();
            while (true) {
                if (it3.hasNext()) {
                    if (arrFlags.get(((Integer) it3.next()).intValue()).mLanguage.equals("Hebrew")) {
                        this.m_arrData.add(dataHebHeb);
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        OfflineData dataEngEng = map.get("EnglishEnglish");
        if (dataEngEng != null && !dataEngEng.mInstalled) {
            this.m_arrData.add(map.get("EnglishEnglish"));
        }
        map.remove("EnglishEnglish");
        this.m_iSelected = this.m_arrData.size();
        arrTemp.clear();
        for (Entry<String, OfflineData> entry2 : map.entrySet()) {
            if (!entry2.getValue().mTarget.equals("English")) {
                arrTemp.add(entry2.getValue());
            }
        }
        Collections.sort(arrTemp, new DictComparator());
        this.m_arrData.addAll(arrTemp);
        arrTemp.clear();
        for (Entry<String, OfflineData> entry3 : map.entrySet()) {
            if (!entry3.getValue().mSource.equals("English")) {
                arrTemp.add(entry3.getValue());
            }
        }
        Collections.sort(arrTemp, new DictComparator());
        this.m_arrData.addAll(arrTemp);
        this.m_arrNeedToInstall = new ArrayList<>();
        for (int i = 0; i < this.m_iSelected - iInstalled; i++) {
            OnAddInstall(Integer.valueOf(i + iInstalled));
        }
    }

    public void OnDeleteDictionary(int position) {
        this.mDeleteIndex = position;
        ConfirmDelete().show();
    }

    public void OnAddInstall(Integer position) {
        if (!this.m_arrNeedToInstall.contains(position)) {
            this.m_arrNeedToInstall.add(position);
        }
    }

    public void OnRemoveInstall(Integer position) {
        this.m_arrNeedToInstall.remove(position);
    }

    private AlertDialog ConfirmDelete() {
        return new Builder(this).setTitle(R.string.offline_confirm_delete_title).setMessage(R.string.offline_confirm_delete).setPositiveButton(R.string.offline_delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                OfflineData data = DownloadActivity.this.m_arrData.get(DownloadActivity.this.mDeleteIndex);
                DownloadActivity.this.mDeleteIndex = -1;
                DownloadActivity.this.mOfflineMgr.DeleteDict(data.mZipFileName + ".bdc");
                DownloadActivity.this.InitDataArray();
                DownloadActivity.this.mOfflineAdapter.updateDictsList(DownloadActivity.this.m_arrData, DownloadActivity.this.m_iSelected);
                dialog.dismiss();
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }).create();
    }

    /* access modifiers changed from: private */
    public void InstallDicts() {
        int iSize = this.m_arrNeedToInstall.size();
        if (iSize > 0) {
            OfflineData[] data = new OfflineData[iSize];
            for (int i = 0; i < iSize; i++) {
                data[i] = this.m_arrData.get(this.m_arrNeedToInstall.get(i).intValue());
            }
            this.mOfflineMgr.DownloadDict(this, data);
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        unregisterReceiver(this.mReceiver);
        super.onDestroy();
    }
}
