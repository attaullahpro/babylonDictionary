package com.babylon.controls;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.List;

public class AutocompleteAdapter extends ArrayAdapter<AutocompleteListItem> {
    boolean mHandleDivider = false;
    private LayoutInflater mInflater;
    public List<AutocompleteListItem> mItems;
    boolean m_bSetSelector = false;

    public enum RowType {
        LIST_ITEM,
        HEADER_ITEM
    }

    public AutocompleteAdapter(Context context, List<AutocompleteListItem> items) {
        super(context, 0, items);
        this.mInflater = LayoutInflater.from(context);
        this.mItems = items;
    }

    public String getTerm(int position) {
        return ((AutocompleteListItem) getItem(position)).mText;
    }

    public int getViewTypeCount() {
        return RowType.values().length;
    }

    public int getItemViewType(int position) {
        return ((AutocompleteListItem) getItem(position)).getViewType();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (!this.mHandleDivider) {
            ((ListView) parent).setDivider(null);
            this.mHandleDivider = true;
        }
        return ((AutocompleteListItem) getItem(position)).getView(this.mInflater, convertView);
    }
}
